<?php require __DIR__.'/includes/functions.php';
http_response_code(404);$page='';$pageTitle='Page not found';require 'includes/header.php';?>
<section class="wrap page"><h1>Page not found</h1><p class="lead">That page does not exist. See upcoming events or browse the network.</p><a class="btn" href="<?=u('events')?>">View events</a></section>
<?php require 'includes/footer.php';
