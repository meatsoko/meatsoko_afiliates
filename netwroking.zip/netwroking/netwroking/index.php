<?php require __DIR__.'/includes/functions.php';
$page='index';$pageTitle='A Serene Place for Livestock Partnerships';
$ev=array_values(array_filter(events(),fn($x)=>$x['date']>=date('Y-m-d')));
$mb=load('members');
$cats=array_unique(array_column($mb,'category'));
require 'includes/header.php';?>

<!-- Hero Section -->
<section class="hero" style="--img:url('<?=IMG['hero']?>')">
  <div class="hwrap">
    <p class="chip"><i class="fa-solid fa-cow"></i> Pan-African Livestock Industry Events & Partnerships</p>
    <h1>Where Africa's Livestock Leaders Meet, Calmly</h1>
    <p class="lead"><?=e(SITE_SHORT)?> creates a serene, hosted environment for strategic livestock partnerships. Connect cattle ranchers, commercial goat breeders, meat processors, and investors across Africa.</p>
    <div style="display:flex;gap:1rem;flex-wrap:wrap;margin-top:1.5rem">
      <a class="btn" href="<?=u('events')?>"><i class="fa-solid fa-calendar-days"></i> Explore upcoming events</a>
      <a class="btn alt" href="<?=u('network')?>"><i class="fa-solid fa-people-group"></i> Browse member directory</a>
      <a class="btn alt" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call <?=e(SITE_PHONE_DISPLAY)?></a>
    </div>
  </div>
  <div class="ticker">
    <div class="track">
      <?php for($k=0;$k<2;$k++): foreach($cats as $c): ?>
        <span><i><i class="fa-solid fa-circle-nodes"></i> <?=e($c)?></i></span>
      <?php endforeach; endfor; ?>
    </div>
  </div>
</section>

<!-- Direct Contact Strip -->
<div style="background:var(--sf);border-bottom:1px solid var(--ln);padding:1rem 5vw">
  <div class="wrap" style="padding:0;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:1rem">
    <div style="display:flex;align-items:center;gap:.8rem">
      <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:50%;background:var(--tg);color:#fff"><i class="fa-solid fa-phone"></i></span>
      <div>
        <small style="color:var(--mu);display:block">Direct Partnerships Hotline</small>
        <strong><a href="tel:<?=e(SITE_PHONE)?>" style="color:var(--tx)"><?=e(SITE_PHONE_DISPLAY)?></a></strong>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:.8rem">
      <span style="display:grid;place-items:center;width:38px;height:38px;border-radius:50%;background:var(--ac);color:#fff"><i class="fa-solid fa-envelope"></i></span>
      <div>
        <small style="color:var(--mu);display:block">Official Desk</small>
        <strong><a href="mailto:<?=e(SITE_EMAIL)?>" style="color:var(--tx)"><?=e(SITE_EMAIL)?></a></strong>
      </div>
    </div>
    <div>
      <a class="btn" style="padding:.5rem 1.2rem;font-size:.9rem" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
    </div>
  </div>
</div>

<!-- Stats Counter -->
<section class="wrap stats">
  <div class="rv"><i class="fa-solid fa-calendar-days"></i><b data-count="<?=count($ev)?>">0</b><span>Upcoming Summits</span></div>
  <div class="rv"><i class="fa-solid fa-id-card"></i><b data-count="<?=count($mb)?>">0</b><span>Vetted Members</span></div>
  <div class="rv"><i class="fa-solid fa-layer-group"></i><b data-count="<?=count($cats)?>">0</b><span>Value Chain Sectors</span></div>
</section>

<!-- Split Overview Section with Cattle Photo -->
<section class="wrap split">
  <img class="rv" loading="lazy" alt="High-grade cattle grazing on serene rangeland" src="<?=IMG['about']?>">
  <div class="rv">
    <b class="kind">Calm Environments, Serious Deals</b>
    <h2>Productive Agribusiness Growth Needs Space & Clarity</h2>
    <p>Good commercial partnerships flourish when cattle ranchers, goat multipliers, and meat processors have space to communicate openly. Our retreats and roundtables are small, hosted, and private—ensuring concrete agreements, structured off-take deals, and lasting alliances.</p>
    <ul class="ticks">
      <li><i class="fa-solid fa-circle-check"></i> <strong>Curated, high-level gatherings:</strong> Ranch owners, processors, and investors.</li>
      <li><i class="fa-solid fa-circle-check"></i> <strong>Deep livestock focus:</strong> Cattle ranches, dairy farms, goats & sheep value chains.</li>
      <li><i class="fa-solid fa-circle-check"></i> <strong>Warm personal introductions:</strong> Verified counterparts with aligned objectives.</li>
      <li><i class="fa-solid fa-circle-check"></i> <strong>Confidentiality guaranteed:</strong> Respect for private negotiations and contracts.</li>
    </ul>
    <div style="margin-top:1.5rem">
      <a class="btn dark" href="<?=u('about')?>"><i class="fa-solid fa-circle-info"></i> Learn more about us</a>
    </div>
  </div>
</section>

<!-- Livestock Sectors We Connect -->
<section class="wrap">
  <div style="text-align:center;max-width:700px;margin:0 auto 2.5rem" class="rv">
    <b class="kind">Cross-Sector Livestock Synergies</b>
    <h2>Value Chains We Facilitate</h2>
    <p class="lead" style="margin:auto">From pasture and breeding genetics to abattoir cold chains and consumer tables across Africa.</p>
  </div>
  <div class="grid three">
    <div class="pill rv">
      <h3><i class="fa-solid fa-cow"></i> Commercial Cattle & Beef</h3>
      <p>Boran, Zebu, Sahiwal, and exotic cross beef cattle producers linking directly with feedlots, commercial abattoirs, and regional export buyers.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-paw"></i> Goats & Small Ruminants</h3>
      <p>Highland and arid Galla goat breeders, Boer goat studs, and Dorper sheep ranches securing commercial breeding and carcass supply agreements.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-blender"></i> Dairy & Pasture Management</h3>
      <p>Commercial dairy cooperatives, fodder producers, silage experts, and cooling equipment providers scaling daily milk yields.</p>
    </div>
    <div class="pill green rv">
      <h3><i class="fa-solid fa-industry"></i> Abattoirs & Meat Processing</h3>
      <p>Modern slaughterhouses, Halal certification boards, packaging specialists, and frozen meat distribution logistics.</p>
    </div>
    <div class="pill green rv">
      <h3><i class="fa-solid fa-truck-moving"></i> Cold Chain & Cross-Border Logistics</h3>
      <p>Refrigerated transport, livestock quarantine stations, and border corridor facilitation under AfCFTA guidelines.</p>
    </div>
    <div class="pill green rv">
      <h3><i class="fa-solid fa-coins"></i> Livestock Financing & Advisory</h3>
      <p>Agribusiness venture capital, development finance institutions, and asset lenders backing rangeland and processing infrastructure.</p>
    </div>
  </div>
</section>

<!-- Upcoming Events Grid -->
<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem" class="rv">
    <div>
      <b class="kind">Scheduled Gatherings</b>
      <h2>Upcoming Industry Events</h2>
    </div>
    <a class="btn alt" style="background:var(--ac);box-shadow:none" href="<?=u('events')?>">View all events <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="grid">
    <?php 
    foreach(array_slice($ev,0,3) as $x) echo ecard($x);
    if(!$ev) echo '<p>New retreats and summits are being scheduled. Check back soon or call us on '.e(SITE_PHONE_DISPLAY).'.</p>';
    ?>
  </div>
</section>

<!-- Featured Members -->
<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem" class="rv">
    <div>
      <b class="kind">Vetted Directory</b>
      <h2>From the Livestock Network</h2>
    </div>
    <a class="btn alt" style="background:var(--ac);box-shadow:none" href="<?=u('network')?>">Browse all members <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="grid">
    <?php foreach(array_slice($mb,0,4) as $x) echo pcard($x); ?>
  </div>
</section>

<!-- Featured Products -->
<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem" class="rv">
    <div>
      <b class="kind">Meat &amp; Commercial Products</b>
      <h2>Featured Products</h2>
    </div>
    <div style="display:flex;gap:.6rem;flex-wrap:wrap">
      <a class="btn alt" style="background:var(--ac);box-shadow:none" href="<?=u('products')?>">View all (<?=count(products())?>) <i class="fa-solid fa-arrow-right"></i></a>
      <a class="btn" style="background:var(--tg);box-shadow:none" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-cart-shopping"></i> shop.meatsokogroup.com</a>
      <a class="btn alt" style="background:var(--dk);color:#ffffff;box-shadow:none" href="https://meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> meatsokogroup.com</a>
    </div>
  </div>
  <div class="grid three">
    <?php foreach(array_slice(products(),0,3) as $p) echo product_card($p); ?>
  </div>
</section>


<!-- Call to Action Banner -->
<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Join Africa's Foremost Livestock Network</h2>
      <p>List your ranch, processing facility, or investment fund. We personally facilitate your next strategic alliance.</p>
      <p style="margin-top:.4rem">Direct Desk: <strong><?=e(SITE_PHONE_DISPLAY)?></strong> &nbsp;|&nbsp; <strong><?=e(SITE_EMAIL)?></strong></p>
    </div>
    <div class="cta-btns">
      <a class="btn white" href="<?=u('contact')?>?topic=join"><i class="fa-solid fa-user-plus"></i> Create your profile</a>
      <a class="btn alt" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call directly</a>
      <?=partner('dark')?>
    </div>
  </div>
</section>

<?php require 'includes/footer.php';
