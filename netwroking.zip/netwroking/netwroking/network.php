<?php require __DIR__.'/includes/functions.php';
$page='network';$pageTitle='Vetted Livestock Network Directory';$mb=load('members');$cats=array_values(array_unique(array_column($mb,'category')));require 'includes/header.php';?>
<section class="wrap page">
  <h1>The Livestock Network Directory</h1>
  <p class="lead">Discover commercial cattle ranchers, goat and sheep breeders, processors, veterinarians, and investors across Africa. Request a confidential, warm introduction through our partnerships team.</p>

  <!-- Filter and Search -->
  <div style="background:var(--sf);border:1px solid var(--ln);border-radius:20px;padding:1.4rem;margin:2rem 0">
    <label style="margin-bottom:.6rem;font-weight:600"><i class="fa-solid fa-magnifying-glass"></i> Search Network Members</label>
    <input id="qn" type="search" placeholder="Type a name, role, organisation, or what they are seeking..." aria-label="Search members">
    
    <div style="margin-top:1rem">
      <small style="color:var(--mu);display:block;margin-bottom:.5rem;font-weight:600">Filter by Value Chain Sector:</small>
      <div class="chips" style="margin-bottom:0">
        <button class="chip-btn on" data-c="all">All Sectors (<?=count($mb)?>)</button>
        <?php foreach($cats as $c): 
          $count = count(array_filter($mb, fn($x)=>$x['category']===$c));
          echo '<button class="chip-btn" data-c="'.e($c).'">'.e($c).' ('.$count.')</button>';
        endforeach;?>
      </div>
    </div>
  </div>

  <div class="grid" id="people">
    <?php foreach($mb as $x) echo pcard($x); ?>
  </div>

  <!-- How Introductions Work -->
  <div class="grid" style="margin-top:3.5rem;grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
    <div class="pill rv">
      <h3><i class="fa-solid fa-handshake"></i> How We Facilitate Introductions</h3>
      <p>Click "Request intro" on any member profile to submit your introductory brief. Our team evaluates synergy and introduces both parties directly over phone, email, or a dedicated retreat session.</p>
    </div>
    <div class="pill green rv">
      <h3><i class="fa-solid fa-phone"></i> Prefer Direct Telephone Assistance?</h3>
      <p>Have an immediate cattle off-take need or goat breeding inquiry? Speak to our team at <strong><a href="tel:<?=e(SITE_PHONE)?>"><?=e(SITE_PHONE_DISPLAY)?></a></strong> or WhatsApp us directly.</p>
    </div>
  </div>

  <p class="note" style="text-align:center;margin-top:2.5rem"><i class="fa-solid fa-lock"></i> All member profiles are published solely with mutual commercial consent. Interested in listing your ranch or agribusiness? <a href="<?=u('contact')?>?topic=join" style="font-weight:600;text-decoration:underline">Create your member profile here</a>.</p>
</section>
<?php require 'includes/footer.php';
