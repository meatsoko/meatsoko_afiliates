<?php require __DIR__.'/includes/functions.php';
$page='events';$pageTitle='Livestock Industry Summits, Retreats & Roundtables';require 'includes/header.php';?>
<section class="wrap page">
  <h1>Livestock Summits & Closed-Door Retreats</h1>
  <p class="lead">We curate small, hosted gatherings for serious commercial partnerships across the livestock economy. Every session is designed with ample time for dialogue, unhurried negotiation, and tangible memorandums of understanding.</p>

  <!-- Quick Event Hotline -->
  <div class="pill" style="margin:2rem 0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1.5rem">
    <div>
      <b class="kind">Need assistance or group delegate reservations?</b>
      <h3 style="margin:.2rem 0">Speak directly with our Events Desk</h3>
      <p>Reach us at <strong><a href="tel:<?=e(SITE_PHONE)?>"><?=e(SITE_PHONE_DISPLAY)?></a></strong> or email <strong><a href="mailto:<?=e(SITE_EMAIL)?>"><?=e(SITE_EMAIL)?></a></strong>.</p>
    </div>
    <div style="display:flex;gap:.8rem;flex-wrap:wrap">
      <a class="btn" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call <?=e(SITE_PHONE_DISPLAY)?></a>
      <a class="btn alt" style="background:var(--ac);box-shadow:none" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
    </div>
  </div>

  <h2 style="margin-top:2.5rem">All Scheduled Gatherings</h2>
  <div class="grid">
    <?php 
    $l=events();
    foreach($l as $x) echo ecard($x);
    if(!$l) echo '<p>No scheduled events found at this time. Please contact us at '.e(SITE_EMAIL).' to inquire about upcoming dates.</p>';
    ?>
  </div>

  <div class="pill green" style="margin-top:3.5rem">
    <h3><i class="fa-solid fa-handshake"></i> How Our Event Reservations Work</h3>
    <p>To preserve high-quality conversations and strict commercial focus, attendance is capped between 20 to 50 leaders per session. Once you reserve your seat, our coordinator confirms your profile alignment and delivers your personalized itinerary, dietary choices, and bilateral meeting schedule.</p>
  </div>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Propose or Sponsor an Event</h2>
      <p>Would your institution or cooperative like to host a custom livestock roundtable in your region?</p>
    </div>
    <div class="cta-btns">
      <a class="btn white" href="<?=u('contact')?>?topic=partner"><i class="fa-solid fa-handshake"></i> Partner with us</a>
      <a class="btn alt" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call <?=e(SITE_PHONE_DISPLAY)?></a>
    </div>
  </div>
</section>
<?php require 'includes/footer.php';
