<?php
require __DIR__.'/includes/functions.php';

$page = 'products';
$pageTitle = 'Products';
$prods = products();
$categories = ['All'];
foreach ($prods as $p) {
  if (!empty($p['category']) && !in_array($p['category'], $categories)) {
    $categories[] = $p['category'];
  }
}

require 'includes/header.php';
?>

<section class="wrap page">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;margin-bottom:1.2rem">
    <div>
      <span class="kind"><i class="fa-solid fa-store"></i> Products</span>
      <h1 style="margin:0">Products</h1>
    </div>
    <div style="display:flex;gap:.8rem;flex-wrap:wrap;align-items:center">
      <a class="btn" style="background:var(--tg);box-shadow:none;padding:.5rem 1.2rem;font-size:.9rem" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-cart-shopping"></i> shop.meatsokogroup.com</a>
      <a class="btn alt" style="background:var(--ac);box-shadow:none;padding:.5rem 1.2rem;font-size:.9rem" href="https://meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> Show more on meatsokogroup.com</a>
    </div>
  </div>

  <!-- Search Input -->
  <div style="margin:1rem 0">
    <input id="pq" type="search" placeholder="Search products (e.g. goat meat, beef, POS)..." aria-label="Search products">
  </div>

  <!-- Category Filter Buttons -->
  <div class="prod-filter-bar">
    <?php foreach ($categories as $cat): ?>
      <button type="button" class="cat-chip <?=($cat === 'All' ? 'active' : '')?>" data-cat="<?=e(strtolower($cat))?>">
        <?=e($cat)?>
      </button>
    <?php endforeach; ?>
  </div>

  <!-- Products Grid -->
  <div class="grid three" id="prodCards" style="margin-top:1.5rem">
    <?php foreach ($prods as $p) echo product_card($p); ?>
  </div>

  <!-- Show More Bar -->
  <div style="margin:2.5rem 0 1rem;padding:1.4rem 1.8rem;background:var(--sf);border:1px solid var(--ln);border-radius:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1.2rem" class="rv">
    <div>
      <strong style="font-size:1.05rem;display:block">Looking for more products &amp; solutions?</strong>
      <span style="color:var(--mu);font-size:.92rem">Meat orders pushed to shop.meatsokogroup.com &middot; Enterprise and other solutions on meatsokogroup.com</span>
    </div>
    <div style="display:flex;gap:.8rem;flex-wrap:wrap">
      <a class="btn" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-cart-shopping"></i> shop.meatsokogroup.com</a>
      <a class="btn alt" style="background:var(--ac);box-shadow:none" href="https://meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> Show more on meatsokogroup.com</a>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
