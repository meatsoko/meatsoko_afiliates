<?php
require_once __DIR__.'/../config.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
const IMG=[
 'hero'=>'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1800&q=75',
 'about'=>'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=1200&q=75',
 'event'=>'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=1200&q=75'
];
function partner($c=''){
 $x=PARTNER_URL;$ext=preg_match('#^https?://#i',$x);
 return '<a class="btn pulse '.e($c).'" href="'.($ext?e($x):u($x)).'"'.($ext?' target="_blank" rel="noopener"':'').'><i class="fa-solid fa-handshake"></i> '.e(PARTNER_LABEL).' <i class="fa-solid fa-arrow-right go"></i></a>';
}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function load($n){$f=__DIR__."/../data/$n.json";return is_file($f)?(json_decode(file_get_contents($f),true)?:[]):[];}
function save($n,$d){file_put_contents(__DIR__."/../data/$n.json",json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);}
function u($f){if($f==='index')return CLEAN_URLS?'./':'index.php';return CLEAN_URLS?$f:$f.'.php';}
function csrf(){if(empty($_SESSION['t']))$_SESSION['t']=bin2hex(random_bytes(16));return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">';}
function ok(){return isset($_POST['t'],$_SESSION['t'])&&hash_equals($_SESSION['t'],$_POST['t']);}
function go($f){header('Location: '.u($f));exit;}
function flash(){$m=$_SESSION['flash']??'';unset($_SESSION['flash']);return $m?'<p class="flash" role="status">'.e($m).'</p>':'';}
function events(){$p=load('events');usort($p,fn($a,$b)=>strcmp($a['date'],$b['date']));return $p;}
function ecard($x){
 $past=$x['date']<date('Y-m-d');
 $img=!empty($x['image'])?$x['image']:IMG['event'];
 return '<div class="card rv'.($past?' past':'').'"><img loading="lazy" alt="'.e($x['title']).'" src="'.e($img).'"><div><b>'.e($x['format']).($past?' (past)':'').'</b><h3>'.e($x['title']).'</h3><p>'.e($x['summary']).'</p><time><i class="fa-regular fa-calendar"></i> '.e($x['date']).' &middot; <i class="fa-solid fa-location-dot"></i> '.e($x['place']).'</time>'.($past?'':'<p><a class="btn" href="'.u('contact').'?topic=event&amp;ref='.e($x['slug']).'"><i class="fa-solid fa-ticket"></i> Reserve a seat</a></p>').'</div></div>';
}
function initials($n){preg_match_all('/\b\w/u',$n,$m);return strtoupper(implode('',array_slice($m[0],0,2)));}
function pcard($x){
 return '<div class="card person rv" data-c="'.e($x['category']).'" data-s="'.e(strtolower($x['name'].' '.$x['role'].' '.$x['org'].' '.$x['category'].' '.$x['seeking'])).'"><div><span class="av">'.e(initials($x['name'])).'</span><h3>'.e($x['name']).'</h3><b>'.e($x['role']).', '.e($x['org']).'</b><p><i class="fa-solid fa-magnifying-glass"></i> Looking for: '.e($x['seeking']).'</p><a class="btn" href="'.u('contact').'?topic=intro&amp;ref='.e($x['slug']).'"><i class="fa-solid fa-handshake"></i> Request intro</a></div></div>';
}
function products(){return load('products');}
function product_card($p){
 $badge=!empty($p['badge'])?'<span class="prod-badge">'.e($p['badge']).'</span>':'';
 $img=!empty($p['image'])?e($p['image']):IMG['event'];
 $cat=!empty($p['category'])?'<b class="kind">'.e($p['category']).'</b>':'';
 $link=!empty($p['link'])?e($p['link']):'https://shop.meatsokogroup.com';
 $tgt=(strpos($link,'http')===0)?' target="_blank" rel="noopener"':'';
 return '<div class="prod-card card rv" data-s="'.e(strtolower(($p['title']??'').' '.($p['category']??''))).'" data-cat="'.e(strtolower($p['category']??'')).'">'
  .'<div class="prod-img-wrap"><img loading="lazy" alt="'.e($p['title']??'').'" src="'.$img.'">'.$badge.'</div>'
  .'<div class="prod-body">'.$cat.'<h3 class="prod-title">'.e($p['title']??'').'</h3>'
  .'<div class="prod-foot">'
  .'<a class="btn prod-btn" href="'.$link.'"'.$tgt.'><i class="fa-solid fa-cart-shopping"></i> Shop Now</a></div>'
  .'</div></div>';
}

