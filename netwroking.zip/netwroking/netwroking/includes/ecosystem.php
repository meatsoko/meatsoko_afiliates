<?php
// Shared "MeatSoko ecosystem" section. Content comes from data/ecosystem.json
function ecosystem_section(){
$eco=load('ecosystem');if(!$eco)return;$me=defined('ECO_PILLAR')?ECO_PILLAR:'';
echo '<h2 style="margin-top:3rem">Part of the MeatSoko ecosystem</h2><p class="lead">'.e($eco['intro']??'').'</p>';
echo '<div class="pill rv" style="margin:1.5rem 0"><h3><i class="fa-solid fa-key"></i> One membership, full access</h3><p>'.e($eco['access']['text']??'').'</p></div>';
echo '<div class="grid three">';
foreach($eco['pillars']??[] as $p){$mine=($p['name']===$me);
 echo '<div class="pill rv'.($mine?' me':'').'"><h3><i class="fa-solid fa-'.e($p['icon']).'"></i> '.e($p['name']).'</h3>'.($mine?'<b class="kind">This company</b>':'').'<ul class="ticks">';
 foreach($p['items'] as $li)echo '<li>'.e($li).'</li>';echo '</ul></div>';}
echo '</div><p class="lead" style="margin-top:1.5rem">'.e($eco['marketplace_note']??'').' '.e($eco['external_services']??'').'</p>';
echo '<h2 style="margin-top:3rem">How an idea becomes a product</h2><div class="grid three">';
foreach($eco['flow']??[] as $f)echo '<div class="pill rv"><b class="kind">Step '.(int)$f['step'].'</b><h3>'.e($f['title']).'</h3><p>'.e($f['text']).'</p></div>';
echo '</div>';}
