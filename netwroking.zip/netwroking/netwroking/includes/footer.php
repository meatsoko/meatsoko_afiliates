</main>
<footer class="foot"><div class="fwrap">
<div>
<b><?=e(SITE_SHORT)?></b>
<p><?=e(SITE_TAG)?>. Strategic partnerships and serene retreats for Africa's livestock economy.</p>
<small><i class="fa-solid fa-shield-halved"></i> Member profiles and trade negotiations are conducted with strict confidentiality.</small>
</div>
<nav aria-label="Footer">
<?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'">'.$n[0].'</a>';?>
<a href="api.php">API</a>
</nav>
<div class="fr">
<div class="foot-contacts">
<a href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE_DISPLAY)?></a>
<a href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp Chat</a>
<a href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a>
</div>
<small style="display:block;margin-top:.8rem;color:#ffffff;opacity:.8">&copy; <?=date('Y')?> <?=e(SITE_SHORT)?> &middot; Part of MeatSoko Group</small>
</div>
</div></footer>
<nav class="bnav" aria-label="Mobile"><?php foreach($BOT as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?></nav></body></html>
