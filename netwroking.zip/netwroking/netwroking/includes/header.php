<?php
require_once __DIR__.'/functions.php';
$page=$page??'';$pageTitle=$pageTitle??'A serene place for livestock partnerships';
$NAV=['index'=>['Home','house'],'about'=>['About','circle-info'],'events'=>['Events','calendar-days'],'network'=>['Network','people-group'],'products'=>['Products','cart-shopping'],'contact'=>['Contact','envelope']];
$BOT=array_intersect_key($NAV,array_flip(['index','events','network','products','contact']));

?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($pageTitle)?> | <?=e(SITE_SHORT)?></title>
<meta name="description" content="<?=e(SITE_SHORT)?>: Livestock industry events and strategic partnerships across Africa. Call <?=e(SITE_PHONE_DISPLAY)?> or email <?=e(SITE_EMAIL)?>.">
<script>try{document.documentElement.dataset.theme=localStorage.theme||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light')}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700;800&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer"><link rel="stylesheet" href="assets/css/style.css"><script src="assets/js/main.js" defer></script></head><body>
<header class="top" id="top"><a class="logo" href="<?=u('index')?>"><span class="tagmark"></span><span><?=e(SITE_SHORT)?><small><?=e(SITE_TAG)?></small></span></a>
<nav class="dnav" aria-label="Main"><?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'>'.$n[0].'</a>';?></nav>
<div class="acts">
<a class="acts-contact" href="tel:<?=e(SITE_PHONE)?>" title="Call 0715097128"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE_DISPLAY)?></a>
<button class="ic theme-btn" aria-label="Toggle light or dark theme"><i class="fa-solid fa-moon t-moon"></i><i class="fa-solid fa-sun t-sun"></i></button>
<button class="ic menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="side"><i class="fa-solid fa-bars"></i></button></div></header>
<div class="veil" id="veil"></div>
<aside class="side" id="side" aria-label="Menu"><div class="sidehead"><b><?=e(SITE_SHORT)?></b><button class="ic" id="closeBtn" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button></div>
<?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?>
<div style="margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--ln);">
<a href="tel:<?=e(SITE_PHONE)?>"><span><i class="fa-solid fa-phone"></i></span> <?=e(SITE_PHONE_DISPLAY)?></a>
<a href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><span><i class="fa-brands fa-whatsapp"></i></span> WhatsApp Chat</a>
<a href="mailto:<?=e(SITE_EMAIL)?>"><span><i class="fa-solid fa-envelope"></i></span> <?=e(SITE_EMAIL)?></a>
</div>
<button class="theme-btn wide"><i class="fa-solid fa-circle-half-stroke"></i> Switch light / dark</button>
<p class="sidenote"><i class="fa-solid fa-location-dot"></i> <?=e(SITE_LOCATION)?><br><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></p></aside><main>
