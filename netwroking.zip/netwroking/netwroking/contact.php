<?php require __DIR__.'/includes/functions.php';
$T=[
  'event'=>'Reserve an event seat',
  'join'=>'Create my member profile',
  'intro'=>'Request an introduction to a member',
  'product'=>'Order or inquire about a product / POS / class',
  'partner'=>'Partner or sponsor an event',
  'call'=>'Request a direct callback (0715097128)',
  'other'=>'Something else'
];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $n=trim($_POST['name']??'');
  $m=trim($_POST['email']??'');
  $p=trim($_POST['phone']??'');
  $b=trim($_POST['msg']??'');
  $o=trim($_POST['org']??'');
  $tp=$T[$_POST['topic']??'']??'Other';
  if(ok()&&($_POST['website']??'')===''&&$n&&filter_var($m,FILTER_VALIDATE_EMAIL)&&$b){
    $a=load('messages');
    $a[]=['date'=>date('Y-m-d H:i'),'name'=>$n,'email'=>$m,'phone'=>$p,'org'=>$o,'topic'=>$tp,'msg'=>$b];
    save('messages',$a);
    $body="From: $n ($o)\nEmail: $m\nPhone: $p\nTopic: $tp\n\n$b";
    @mail(SITE_EMAIL,"$tp: $n",$body,"Reply-To: $m\r\nFrom: no-reply@meatsokogroup.com");
    $_SESSION['flash']='Thank you! Your message has been received. Our team will contact you directly via email or call on '.SITE_PHONE_DISPLAY.'.';
  } else {
    $_SESSION['flash']='Please enter your name, a valid email address and your message.';
  }
  go('contact');
}
$sel=$_GET['topic']??'';
$ref=$_GET['ref']??'';
$pre='';
foreach(events() as $x)if($x['slug']===$ref)$pre="I would like to reserve a seat for: ".$x['title']." (Date: ".$x['date'].", Venue: ".$x['place'].")";
foreach(load('members') as $x)if($x['slug']===$ref)$pre="Please introduce me to: ".$x['name']." in ".$x['category']." (".$x['role'].", ".$x['org'].")";
foreach(load('products') as $x)if(($x['id']??'')===$ref)$pre="I would like to order / inquire about: ".$x['title']."\nDelivery / Setup Location:\nOrganisation:\nQuestions:";
if($sel==='product'&&!$pre)$pre="I would like to inquire about your commercial products / POS / masterclasses.\nProduct(s) of interest:\nMy questions:";
if($sel==='join')$pre="I would like to create a member profile in the MeatSoko Network.\nLivestock Category (Cattle / Goats / Sheep / Processing / Feeds):\nOrganisation:\nRole:\nWhat I am looking for:";

$page='contact';$pageTitle='Contact & Partnership Enquiries';require 'includes/header.php';?>
<section class="wrap page">
<div class="narrow" style="margin:0 auto">
<h1>Get in touch with us</h1>
<p class="lead">Connect directly with the MeatSoko Networking Playground team. We facilitate strategic livestock alliances, closed-door retreats, and direct producer-to-buyer introductions.</p>

<?=flash()?>

<!-- Direct Contact Details Grid -->
<div class="contact-grid">
  <a class="c-box highlight" href="tel:<?=e(SITE_PHONE)?>">
    <i class="fa-solid fa-phone-volume"></i>
    <h3>Call directly</h3>
    <p>Talk with our partnerships desk</p>
    <b><?=e(SITE_PHONE_DISPLAY)?></b>
  </a>
  <a class="c-box" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener">
    <i class="fa-brands fa-whatsapp"></i>
    <h3>WhatsApp chat</h3>
    <p>Quick responses & updates</p>
    <b><?=e(SITE_PHONE_DISPLAY)?></b>
  </a>
  <a class="c-box" href="mailto:<?=e(SITE_EMAIL)?>">
    <i class="fa-solid fa-envelope-open-text"></i>
    <h3>Email enquiries</h3>
    <p>Official partnership proposals</p>
    <b><?=e(SITE_EMAIL)?></b>
  </a>
  <div class="c-box green-icon">
    <i class="fa-solid fa-location-dot"></i>
    <h3>Headquarters</h3>
    <p>East Africa Livestock Network Hub</p>
    <b><?=e(SITE_LOCATION)?></b>
  </div>
</div>

<div class="pill" style="margin-bottom:2.5rem">
  <h3><i class="fa-solid fa-clock"></i> Office & Desk Hours</h3>
  <p><strong>Monday – Friday:</strong> 8:00 AM – 5:00 PM EAT &nbsp;|&nbsp; <strong>Saturday:</strong> 9:00 AM – 1:00 PM EAT.<br>
  For urgent event confirmations or weekend pastoral delegations, phone support is accessible at <strong><?=e(SITE_PHONE_DISPLAY)?></strong>.</p>
</div>

<h2>Send us a message</h2>
<form method="post">
  <?=csrf()?>
  <label>Your full name<input name="name" placeholder="e.g. Samuel Ole Kaelo" required></label>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem">
    <label>Email address<input type="email" name="email" placeholder="e.g. name@company.com" required></label>
    <label>Phone number (optional)<input type="tel" name="phone" placeholder="e.g. 0715097128"></label>
  </div>
  <label>Organisation / Ranch / Farm (optional)<input name="org" placeholder="e.g. Laikipia Livestock Cooperative"></label>
  <label>Topic
    <select name="topic">
      <?php foreach($T as $k=>$v)echo '<option value="'.$k.'"'.($sel===$k?' selected':'').'>'.e($v).'</option>';?>
    </select>
  </label>
  <label>Your message or requirements
    <textarea name="msg" rows="6" placeholder="Describe your interest, prospective partnership, or the livestock sector you represent..." required><?=e($pre)?></textarea>
  </label>
  <input name="website" value="" style="display:none" tabindex="-1" autocomplete="off">
  <button class="btn"><i class="fa-solid fa-paper-plane"></i> Send enquiry</button>
</form>

<p class="note"><i class="fa-solid fa-shield-halved"></i> Your information is kept strictly confidential. Member profiles and partnership introductions are shared solely upon mutual written agreement.</p>
</div>
</section>
<?php require 'includes/footer.php';
