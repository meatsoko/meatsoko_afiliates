NETWORKING PLAYGROUND - PHP website (PHP 7.4+, no database, no login). 6 pages: Home, About, Events, Network, Products, Contact.
1. Upload everything to public_html.
2. Edit config.php: name, SITE_EMAIL (enquiries are emailed here), CLEAN_URLS.
3. Make data/ writable (755/775) so messages are saved to data/messages.json.
4. Edit content in data/*.json: events, members (profiles), team, products. Easily edit or add commercial products, POS systems, courses and prices in data/products.json without any database.
5. Replace images in includes/functions.php (IMG) and the gallery links in about.php.

UPDATE: MeatSoko ecosystem section (About page) reads data/ecosystem.json. 'Partner with us' button: set PARTNER_URL / PARTNER_LABEL in config.php.
PRODUCTS: Dedicated products page (products.php) & featured products section on Home page. Fully customizable in data/products.json.
API: api.php returns the site's content as JSON (including ?section=products). Messages and subscribers are never exposed.

