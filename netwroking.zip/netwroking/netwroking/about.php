<?php require __DIR__.'/includes/functions.php';
$page='about';$pageTitle='About Us & Our Vision';$team=load('team');require 'includes/header.php';?>
<section class="wrap page">
  <h1>About <?=e(SITE_SHORT)?></h1>
  <p class="lead"><?=e(SITE_SHORT)?> is the premier livestock industry events and strategic facilitation company across East Africa and the continent. We design serene, unhurried environments where ranch owners, meat processors, pastoral leaders, and institutional investors formulate durable commercial partnerships.</p>

  <!-- Core Pillars -->
  <div class="grid three" style="margin-top:2.5rem">
    <div class="pill rv">
      <h3><i class="fa-solid fa-bullseye"></i> Our Mission</h3>
      <p>Bridge the gap between African livestock producers—including smallholder pastoralists—and major commercial meat processors, abattoirs, and regional export buyers.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-seedling"></i> Serene & Discreet</h3>
      <p>Serious agribusiness deals require calm, contemplative spaces away from busy trade expos. We curate private, hosted settings where leaders genuinely listen.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-handshake-angle"></i> High-Trust Introductions</h3>
      <p>Every introduction is personally facilitated by our partnerships team, backed by vetted member profiles and mutual commercial objectives.</p>
    </div>
  </div>

  <!-- Key Sectors Covered -->
  <h2 style="margin-top:3.5rem" class="rv">Livestock Value Chains We Connect</h2>
  <div class="grid three">
    <div class="pill green rv">
      <h3><i class="fa-solid fa-cow"></i> Beef & Dairy Cattle</h3>
      <p>Facilitating off-take agreements, feedlot financing, rangeland management, and cold chain distribution for prime beef cattle and high-yielding dairy herds.</p>
    </div>
    <div class="pill green rv">
      <h3><i class="fa-solid fa-paw"></i> Goats & Small Ruminants</h3>
      <p>Connecting commercial Galla goat breeders, Dorper sheep multipliers, and export abattoirs to serve rising domestic and Middle Eastern meat demand.</p>
    </div>
    <div class="pill green rv">
      <h3><i class="fa-solid fa-scale-balanced"></i> Trade, Tech & Policy</h3>
      <p>Uniting veterinarians, transport corridors, logistics providers, and AfCFTA trade facilitators to streamline livestock border crossings.</p>
    </div>
  </div>

  <!-- Real Leadership Team -->
  <h2 style="margin-top:3.5rem" class="rv">Our Leadership Team</h2>
  <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(250px,1fr))">
    <?php foreach($team as $t): ?>
      <div class="pill rv">
        <h3><i class="fa-solid fa-user-tie"></i> <?=e($t['name'])?></h3>
        <b class="kind"><?=e($t['role'])?></b>
        <p><?=e($t['bio'])?></p>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Moments Gallery with Real Cattle, Goats & Networking Images -->
  <h2 style="margin-top:3.5rem" class="rv">Moments Across Our Network</h2>
  <p class="lead">Real moments from our industry summits, pastoral rangelands, cattle ranches, and goat farming cooperatives.</p>
  
  <div class="gal">
    <?php 
    $gallery = [
      ['https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=75', 'Pan-African Livestock Strategic Summit & Networking Hall'],
      ['https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=75', 'Executive Livestock Keynote & Delegate Conference'],
      ['https://images.unsplash.com/photo-1524024973431-2ad916746881?auto=format&fit=crop&w=1200&q=75', 'Commercial meat goats browsing on highland rangeland'],
      ['https://images.unsplash.com/photo-1533318087102-b3ad366ed041?auto=format&fit=crop&w=1200&q=75', 'Pastoral goat flock on verdant meadow pasture'],
      ['https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=1200&q=75', 'Grazing beef cattle on serene green meadow'],
      ['https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1200&q=75', 'Strategic partnership agreement & off-take contract handshake']
    ];
    foreach($gallery as $g): ?>
      <figure class="rv">
        <img loading="lazy" src="<?=e($g[0])?>" alt="<?=e($g[1])?>">
        <figcaption><?=e($g[1])?></figcaption>
      </figure>
    <?php endforeach; ?>
  </div>
</section>

<dialog id="lb"><img alt=""><p></p><button class="btn" onclick="lb.close()">Close</button></dialog>

<section class="wrap page" style="padding-top:0">
  <?php require __DIR__.'/includes/ecosystem.php';ecosystem_section();?>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Host or join an upcoming event</h2>
      <p>Have an event idea or want to co-host an executive livestock roundtable? Reach out to our team directly.</p>
      <p style="margin-top:.4rem"><strong>Phone:</strong> <?=e(SITE_PHONE_DISPLAY)?> &nbsp;|&nbsp; <strong>Email:</strong> <?=e(SITE_EMAIL)?></p>
    </div>
    <div class="cta-btns">
      <a class="btn white" href="<?=u('contact')?>"><i class="fa-solid fa-phone"></i> Contact us</a>
      <?=partner('dark')?>
    </div>
  </div>
</section>
<?php require 'includes/footer.php';
