<?php require __DIR__.'/includes/functions.php';header('Content-Type: application/xml');
$b=(isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['SCRIPT_NAME']),'/').'/';
echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
foreach(['','news','analysis','publications','about','contact'] as $p)echo '<url><loc>'.e($b.$p).'</loc></url>';
foreach(posts() as $x)echo '<url><loc>'.e($b.u('post').'?id='.$x['id']).'</loc><lastmod>'.e($x['date']).'</lastmod></url>';
echo '</urlset>';
