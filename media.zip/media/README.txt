MSL MEDIA GROUP - PHP website (PHP 7.4+, no database, no login). 6 pages + article pages: Home, News, Analysis, Publications, About, Contact.
1. Upload everything to public_html.
2. Edit config.php: name, SITE_EMAIL, CLEAN_URLS.
3. Make data/ writable (755/775): messages go to data/messages.json, subscribers to data/subscribers.json.
4. Publish by editing data/articles.json (type News or Analysis; id, category, title, summary, body, date, author, optional "image" URL).
   The six articles are SAMPLES: replace them with real reporting. Edit data/publications.json (add "file":"x.pdf" for a download) and data/team.json.
5. Replace images in includes/functions.php (IMG).

UPDATE: MeatSoko ecosystem section (About page) reads data/ecosystem.json. 'Partner with us' button: set PARTNER_URL / PARTNER_LABEL in config.php.
API: api.php returns the site's content as JSON (see comments at the top of api.php). Messages and subscribers are never exposed.
