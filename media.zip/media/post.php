<?php
require __DIR__.'/includes/functions.php';

$id = $_GET['id'] ?? '';
$post = null;
foreach(posts() as $x){
  if($x['id'] === $id){
    $post = $x;
    break;
  }
}

if(!$post){
  http_response_code(404);
  $page = 'news';
  $pageTitle = 'Article Not Found';
  require 'includes/header.php';
  echo '<section class="wrap page"><h1>Article Not Found</h1><p class="lead">The livestock intelligence report you requested could not be located.</p><a class="btn" href="'.u('news').'"><i class="fa-solid fa-arrow-left"></i> Latest News</a></section>';
  require 'includes/footer.php';
  exit;
}

$page = strtolower($post['type']);
$pageTitle = $post['title'];
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$uri = $_SERVER['REQUEST_URI'] ?? '';
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$url = $scheme.'://'.$host.$uri;

$rel = array_slice(array_values(array_filter(posts($post['type']), fn($x)=>$x['id'] !== $post['id'])), 0, 2);

require 'includes/header.php';
?>
<article class="wrap page narrow">
  <img class="banner" src="<?=pic($post)?>" alt="<?=e($post['title'])?>">
  <b class="kind"><?=e($post['type'])?> &middot; <?=e($post['category'])?></b>
  <h1><?=e($post['title'])?></h1>
  <p class="byline">
    <i class="fa-solid fa-pen-nib"></i> <?=e($post['author'] ?? 'MeatSoko Editorial Desk')?> &middot;
    <time><i class="fa-regular fa-calendar"></i> <?=e($post['date'])?></time> &middot;
    <?=mins($post)?> min read
  </p>
  <p class="lead"><?=e($post['summary'])?></p>
  <div class="article-body">
    <?php foreach(preg_split('/\n\s*\n/', $post['body']) as $p): ?>
      <p><?=nl2br(e($p))?></p>
    <?php endforeach; ?>
  </div>
  <div class="article-contact-box pill">
    <h3><i class="fa-solid fa-headset"></i> Need More Industry Intelligence?</h3>
    <p>Contact MeatSoko Media intelligence team directly for bespoke livestock price data, custom supply chain consulting, or advertising opportunities.</p>
    <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:0.8rem">
      <a class="btn" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a>
      <a class="btn green" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
      <a class="btn dark" href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a>
    </div>
  </div>
  <p class="share">
    Share report:
    <a aria-label="Share on WhatsApp" href="https://wa.me/?text=<?=urlencode($post['title'].' '.$url)?>"><i class="fa-brands fa-whatsapp"></i></a>
    <a aria-label="Share on X" href="https://twitter.com/intent/tweet?text=<?=urlencode($post['title'])?>&url=<?=urlencode($url)?>"><i class="fa-brands fa-x-twitter"></i></a>
    <a aria-label="Share on LinkedIn" href="https://www.linkedin.com/sharing/share-offsite/?url=<?=urlencode($url)?>"><i class="fa-brands fa-linkedin"></i></a>
    <a aria-label="Share by email" href="mailto:?subject=<?=rawurlencode($post['title'])?>&body=<?=rawurlencode($url)?>"><i class="fa-solid fa-envelope"></i></a>
  </p>
</article>

<?php if($rel): ?>
  <section class="wrap">
    <h2>Related Intelligence &amp; Analysis</h2>
    <div class="grid">
      <?php foreach($rel as $x) echo card($x); ?>
    </div>
  </section>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>
