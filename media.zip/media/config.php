<?php
// === MeatSoko Media Group Configuration ===
const SITE_SHORT = 'MeatSoko Media';
const SITE_TAG   = 'Livestock & Meat Industry Intelligence';
const SITE_EMAIL = 'info@meatsokogroup.com';   // messages and subscriptions are emailed here
const SITE_PHONE = '0715097128';
const SITE_PHONE_INTL = '+254715097128';
const SITE_WHATSAPP = 'https://wa.me/254715097128';
const SITE_LOCATION = 'Nairobi, Kenya';
const ECO_PILLAR    = 'Tech & Media';   // this company's place in the MeatSoko ecosystem
const PARTNER_URL   = 'contact';       // page name (e.g. 'contact') or a full link (https://...)
const PARTNER_LABEL = 'Partner with us';
const CLEAN_URLS = true;                 // set false if your host has no mod_rewrite

// Admin Credentials
const ADMIN_USER      = 'admin';
const ADMIN_PASS_HASH = '$2y$10$jOKHF36aRGp5Ft.CN1lyXeEC.3sqC91M64ndgPDKwWSmBB8YIVrGu';

// Hub and Ecosystem URLs
define('URL_MAIN',        'https://meatsokogroup.com/');
define('URL_RESEARCH',    'https://research.meatsokogroup.com/');
define('URL_SHOP',        'https://shop.meatsokogroup.com/');
define('URL_EVENTS',      'https://event.meatsokogroup.com/');
define('URL_MEDIA',       'https://media.meatsokogroup.com/');
define('URL_LOGISTICS',   'https://logistics.meatsokogroup.com/');
define('URL_BRANDS',      'https://brand.meatsokogroup.com/');
define('URL_TECH',        'https://tech.meatsokogroup.com/');
define('URL_NETWORKING',  'https://networking.meatsokogroup.com/');
define('URL_LEGALITIES',  'https://legalities.meatsokogroup.com/');
define('URL_ENERGY',      'https://energy.meatsokogroup.com/');
define('URL_INVESTMENTS', 'https://investments.meatsokogroup.com/');

// Load Environment Secrets (AI keys, etc.)
if (file_exists(__DIR__ . '/env.php')) {
    require_once __DIR__ . '/env.php';
}
