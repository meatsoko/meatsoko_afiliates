<?php
require __DIR__.'/includes/functions.php';

$page = 'index';
$pageTitle = 'African Livestock & Meat Industry Intelligence';
$ps = posts();
$pb = load('publications');
$cats = array_unique(array_column($ps, 'category'));
$an = posts('Analysis');
$nw = posts('News');
$featured = $an[0] ?? ($ps[0] ?? null);

require 'includes/header.php';
?>

<!-- ==========================================================================
     SECTION 1: HERO & REAL-TIME INTELLIGENCE TICKER
     ========================================================================== -->
<section class="hero" style="--img:url('<?=IMG['hero']?>')">
  <div class="hwrap">
    <p class="chip"><i class="fa-solid fa-cow"></i> Livestock Media &middot; MeatSoko Group &middot; Publishing</p>
    <h1>Insight and Intelligence for the African Livestock Industry</h1>
    <p class="lead"><?=e(SITE_SHORT)?> publishes verified live cattle and goat market benchmarks, veterinary developments, cold-chain supply chain analysis, and intra-Africa red meat trade insights.</p>
    <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:1.2rem">
      <a class="btn green" href="#products"><i class="fa-solid fa-store"></i> Shop Verified Livestock</a>
      <a class="btn alt" href="#services"><i class="fa-solid fa-gear"></i> Ecosystem Services</a>
      <a class="btn" href="<?=u('news')?>"><i class="fa-solid fa-newspaper"></i> Latest News</a>
      <a class="btn alt-green" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call: <?=e(SITE_PHONE)?></a>
    </div>
  </div>
  <div class="ticker" aria-label="Latest headlines">
    <div class="track">
      <?php for($k=0; $k<2; $k++): ?>
        <?php foreach(array_slice($ps, 0, 6) as $x): ?>
          <span>
            <i><?=e($x['category'])?></i>
            <a href="<?=u('post')?>?id=<?=e($x['id'])?>" style="color:inherit;text-decoration:none">
              <?=e($x['title'])?>
            </a>
          </span>
        <?php endforeach; ?>
      <?php endfor; ?>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION 2: SECTOR KEY METRICS & BENCHMARKS
     ========================================================================== -->
<section class="wrap stats">
  <div class="rv">
    <i class="fa-solid fa-newspaper"></i>
    <b data-count="<?=count($ps)?>">0</b>
    <span>published intelligence reports</span>
  </div>
  <div class="rv">
    <i class="fa-solid fa-book-open"></i>
    <b data-count="<?=count($pb)?>">0</b>
    <span>industry publications</span>
  </div>
  <div class="rv">
    <i class="fa-solid fa-tags"></i>
    <b data-count="<?=count($cats)?>">0</b>
    <span>livestock value categories</span>
  </div>
  <div class="rv">
    <i class="fa-solid fa-scale-balanced"></i>
    <b data-count="14">0</b>
    <span>regional markets monitored</span>
  </div>
</section>

<!-- ==========================================================================
     SECTION 3: LIVE LIVESTOCK MARKET WATCH (PRICE DISCOVERY)
     ========================================================================== -->
<section class="wrap">
  <div class="market-watch-card rv">
    <div class="mw-head">
      <div>
        <b class="kind"><i class="fa-solid fa-chart-simple"></i> Price Discovery</b>
        <h2>Live Livestock Market Watch</h2>
        <p class="lead" style="font-size:0.98rem;margin:0">Verified indicative live weight and carcass prices across key regional trading terminals.</p>
      </div>
      <div style="display:flex;gap:0.6rem;flex-wrap:wrap">
        <a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-cart-shopping"></i> Order Animals on Shop</a>
        <a class="btn alt-green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> Live Shop Rates <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
      </div>
    </div>
    <div class="scroll" style="margin-top:1.2rem">
      <table>
        <thead>
          <tr>
            <th>Livestock Category</th>
            <th>Breed / Class</th>
            <th>Primary Terminal</th>
            <th>Avg Live Weight</th>
            <th>Live Market Rates</th>
            <th>Trend</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Prime Beef Steer</strong></td>
            <td>Boran / Zebu Cross</td>
            <td>Nairobi / Dagoretti</td>
            <td>380 &ndash; 420 kg</td>
            <td><a class="price-tag" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> Live on Shop <i class="fa-solid fa-arrow-up-right-from-square"></i></a></td>
            <td><span class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> +3.5%</span></td>
            <td><a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="padding:0.35rem 0.8rem;font-size:0.8rem"><i class="fa-solid fa-cart-shopping"></i> Order on Shop</a></td>
          </tr>
          <tr>
            <td><strong>Breeding Bull</strong></td>
            <td>Sahiwal Pedigree</td>
            <td>Naivasha / Central Hub</td>
            <td>450 &ndash; 520 kg</td>
            <td><a class="price-tag" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> Live on Shop <i class="fa-solid fa-arrow-up-right-from-square"></i></a></td>
            <td><span class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> +1.8%</span></td>
            <td><a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="padding:0.35rem 0.8rem;font-size:0.8rem"><i class="fa-solid fa-cart-shopping"></i> Order on Shop</a></td>
          </tr>
          <tr>
            <td><strong>Prime Meat Goat</strong></td>
            <td>Galla Indigenous Buck</td>
            <td>Garissa / Isiolo</td>
            <td>38 &ndash; 46 kg</td>
            <td><a class="price-tag" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> Live on Shop <i class="fa-solid fa-arrow-up-right-from-square"></i></a></td>
            <td><span class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> +4.2%</span></td>
            <td><a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="padding:0.35rem 0.8rem;font-size:0.8rem"><i class="fa-solid fa-cart-shopping"></i> Order on Shop</a></td>
          </tr>
          <tr>
            <td><strong>Commercial Meat Goat</strong></td>
            <td>Boer Cross Billy</td>
            <td>Rift Valley / Machakos</td>
            <td>35 &ndash; 42 kg</td>
            <td><a class="price-tag" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> Live on Shop <i class="fa-solid fa-arrow-up-right-from-square"></i></a></td>
            <td><span class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> +2.0%</span></td>
            <td><a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="padding:0.35rem 0.8rem;font-size:0.8rem"><i class="fa-solid fa-cart-shopping"></i> Order on Shop</a></td>
          </tr>
          <tr>
            <td><strong>Fat-Tailed Sheep</strong></td>
            <td>Red Maasai Lamb</td>
            <td>Kajiado / Narok</td>
            <td>28 &ndash; 34 kg</td>
            <td><a class="price-tag" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> Live on Shop <i class="fa-solid fa-arrow-up-right-from-square"></i></a></td>
            <td><span class="trend neutral"><i class="fa-solid fa-minus"></i> Stable</span></td>
            <td><a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="padding:0.35rem 0.8rem;font-size:0.8rem"><i class="fa-solid fa-cart-shopping"></i> Order on Shop</a></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION 4: VERIFIED PRODUCTS & LIVESTOCK MARKETPLACE
     All products link directly to shop.meatsokogroup.com
     ========================================================================== -->
<?=products_section(0, true)?>

<!-- ==========================================================================
     SECTION 5: SPECIALIZED AGRIBUSINESS & ECOSYSTEM SERVICES
     ========================================================================== -->
<?=services_section()?>

<!-- ==========================================================================
     SECTION 6: STRATEGIC EDITORIAL SPOTLIGHT / FEATURED STORY
     ========================================================================== -->
<?php if($featured): ?>
  <section class="wrap">
    <div style="margin-bottom:1rem">
      <b class="kind"><i class="fa-solid fa-star"></i> Lead Investigation</b>
    </div>
    <a class="feat rv" href="<?=u('post')?>?id=<?=e($featured['id'])?>">
      <img alt="<?=e($featured['title'])?>" src="<?=pic($featured)?>">
      <div>
        <b class="kind">Featured <?=e($featured['type'])?> &middot; <?=e($featured['category'])?></b>
        <h2><?=e($featured['title'])?></h2>
        <p><?=e($featured['summary'])?></p>
        <time><i class="fa-regular fa-calendar"></i> <?=e($featured['date'])?> &middot; <?=mins($featured)?> min read</time>
      </div>
    </a>
  </section>
<?php endif; ?>

<!-- ==========================================================================
     SECTION 7: LATEST LIVESTOCK & MEAT NEWS GRID
     ========================================================================== -->
<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
    <div>
      <b class="kind"><i class="fa-solid fa-bullhorn"></i> Industry Updates</b>
      <h2 class="rv" style="margin:0">Latest Livestock &amp; Meat News</h2>
    </div>
    <a class="btn alt-green" href="<?=u('news')?>">View all news <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="grid">
    <?php foreach(array_slice($nw, 0, 4) as $x) echo card($x); ?>
  </div>
</section>

<!-- ==========================================================================
     SECTION 8: STRATEGIC MARKET ANALYSIS & RESEARCH GRID
     ========================================================================== -->
<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
    <div>
      <b class="kind"><i class="fa-solid fa-chart-pie"></i> In-Depth Research</b>
      <h2 class="rv" style="margin:0">Strategic Market Analysis</h2>
    </div>
    <a class="btn alt-green" href="<?=u('analysis')?>">View all analysis <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="grid">
    <?php foreach(array_slice($an, 0, 4) as $x) echo card($x); ?>
  </div>
</section>

<!-- ==========================================================================
     SECTION 9: KNOWLEDGE CENTER & INDUSTRY PUBLICATIONS
     ========================================================================== -->
<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
    <div>
      <b class="kind"><i class="fa-solid fa-book"></i> Knowledge Center</b>
      <h2 class="rv" style="margin:0">Industry Publications &amp; Briefings</h2>
    </div>
    <a class="btn alt-green" href="<?=u('publications')?>">All publications <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="grid three">
    <?php foreach($pb as $p): ?>
      <a class="pill rv" href="<?=u('publications')?>">
        <b class="kind"><i class="fa-solid fa-bookmark"></i> <?=e($p['freq'] ?? 'Regular Publication')?></b>
        <h3 style="margin-top:0.3rem"><i class="fa-solid fa-<?=e($p['icon'])?>"></i> <?=e($p['title'])?></h3>
        <p><?=e($p['desc'])?></p>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<!-- ==========================================================================
     SECTION 10: MEATSOKO CONNECTED ECOSYSTEM ARCHITECTURE
     ========================================================================== -->
<section class="wrap">
  <div class="pill rv" style="padding:2.2rem;border-top-width:6px">
    <b class="kind"><i class="fa-solid fa-network-wired"></i> MeatSoko Ecosystem</b>
    <h2>A Unified African Livestock Infrastructure</h2>
    <p class="lead">MeatSoko Media is integrated directly into the continent's complete livestock supply network. Every pastoralist, buyer, rancher, and butcher gets seamless access to 8 interconnected pillars:</p>
    <div class="grid three" style="margin-top:1.5rem">
      <div class="eco-mini-box">
        <h3><i class="fa-solid fa-cow"></i> Cattle &amp; Goat Trading</h3>
        <p>Live-weight transparent digital auctions connecting pastoralists directly with corporate abattoirs via MeatSoko Shop.</p>
      </div>
      <div class="eco-mini-box">
        <h3><i class="fa-solid fa-truck-fast"></i> Cold-Chain Transit</h3>
        <p>Refrigerated logistics fleets and solar collection chillers to eliminate shrinkage and spoilage.</p>
      </div>
      <div class="eco-mini-box">
        <h3><i class="fa-solid fa-building-columns"></i> Instant Guaranteed Payouts</h3>
        <p>Immediate digital escrow payouts upon abattoir weigh-in powered by MeatSoko Assets &amp; Investments.</p>
      </div>
    </div>
    <div style="margin-top:1.5rem;display:flex;gap:0.8rem;flex-wrap:wrap;align-items:center">
      <a class="btn" href="<?=u('about')?>"><i class="fa-solid fa-info-circle"></i> Explore the Ecosystem</a>
      <a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-store"></i> MeatSoko Shop (shop.meatsokogroup.com) <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
      <?=partner('dark')?>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION 11: DIRECT CONTACT & HELPLINE STRIP
     ========================================================================== -->
<section class="wrap" style="padding-top:0">
  <div class="direct-contact-card rv">
    <div>
      <b class="kind" style="color:#ffffff"><i class="fa-solid fa-headset"></i> Need Direct Livestock Intelligence or Trade Support?</b>
      <h3 style="color:#ffffff;margin:0.2rem 0">Call Our Desk or Chat Directly on WhatsApp</h3>
      <p style="color:#ffffff;opacity:0.95;margin:0">Connect with our market analysts, editorial desk, or partnership teams.</p>
    </div>
    <div class="dc-actions">
      <a class="btn" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a>
      <a class="btn green" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp Us</a>
      <a class="btn alt" href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION 12: WEEKLY MARKET INTELLIGENCE NEWSLETTER BRIEFING
     ========================================================================== -->
<section class="cta">
  <div class="wrap rv">
    <div>
      <h2 style="color:#ffffff"><i class="fa-solid fa-envelope-open-text"></i> Receive Weekly Market Intelligence in Your Inbox</h2>
      <p style="margin:0.3rem 0 0;opacity:0.95;color:#ffffff">Get livestock benchmark prices, veterinary alerts, and industry policy briefings delivered every Monday.</p>
    </div>
    <form method="post" action="<?=u('contact')?>" class="sub">
      <?=csrf()?>
      <input type="hidden" name="topic" value="subscribe">
      <input type="email" name="email" placeholder="Enter your business email" required aria-label="Email">
      <input name="website" value="" style="display:none" tabindex="-1" autocomplete="off">
      <button class="btn dark"><i class="fa-solid fa-paper-plane"></i> Subscribe Free</button>
    </form>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
