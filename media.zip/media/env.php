<?php
declare(strict_types=1);

/**
 * env.php — Private secrets & API keys for MeatSoko Media
 *
 * Never commit this file to public git repositories.
 */

define('AI_API_KEY',      'nyk_x23tJkhJIqZS4JJtoSBfdFy_jZt47rkzo7oXQsnsl2Y');
define('AI_API_BASE_URL', 'https://ai.meatsokogroup.com/api/v1');
define('AI_AGENT',        'nyama');
