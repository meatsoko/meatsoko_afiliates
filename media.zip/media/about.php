<?php
require __DIR__.'/includes/functions.php';

$page = 'about';
$pageTitle = 'About MeatSoko Media';
$team = load('team');

require 'includes/header.php';
?>

<section class="wrap page">
  <div class="split">
    <div>
      <b class="kind"><i class="fa-solid fa-cow"></i> African Livestock Intelligence</b>
      <h1>About <?=e(SITE_SHORT)?></h1>
      <p class="lead"><?=e(SITE_SHORT)?> is the premier media, intelligence, and communications pillar of the MeatSoko ecosystem. We empower pastoralists, commercial ranchers, modern abattoirs, retail butchers, veterinary specialists, and agricultural investors with verified livestock data, live price benchmarks, and market analysis.</p>
      <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:1.2rem">
        <a class="btn" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call: <?=e(SITE_PHONE)?></a>
        <a class="btn green" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
        <a class="btn alt-green" href="<?=u('contact')?>"><i class="fa-solid fa-envelope"></i> Contact Us</a>
      </div>
    </div>
    <div>
      <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=70" alt="MeatSoko Real Industry Networking &amp; Collaboration" style="width:100%;border-radius:24px;object-fit:cover;min-height:300px">
    </div>
  </div>

  <h2 style="margin-top:3.5rem">Our Editorial &amp; Industry Charter</h2>
  <div class="grid three">
    <div class="pill rv">
      <h3><i class="fa-solid fa-bullseye"></i> Purpose-Driven Reporting</h3>
      <p>Delivering objective, fact-checked intelligence for the millions of people across Eastern and Central Africa whose livelihoods depend on cattle, goats, and sheep value chains.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-scale-balanced"></i> Editorial Independence</h3>
      <p>All price reporting, market analysis, and veterinary assessments remain strictly editorially independent, free from commercial or sponsor bias.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-circle-check"></i> Verification &amp; Data Rigor</h3>
      <p>We source prices directly from live market weighbridges, quote accredited veterinary authorities, and verify carcass yield metrics at abattoirs.</p>
    </div>
  </div>

  <!-- Real Networking & Industry Hub Showcase -->
  <div class="split" style="margin-top:3.5rem">
    <div>
      <img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=70" alt="MeatSoko Commercial Agribusiness Conference and Networking" style="width:100%;border-radius:24px;object-fit:cover;min-height:300px">
    </div>
    <div>
      <b class="kind"><i class="fa-solid fa-people-arrows"></i> Industry Connectivity</b>
      <h2>Real Networking Across Africa's Red Meat Corridors</h2>
      <p class="lead" style="font-size:1.05rem">We connect pastoralist rangeland associations in Northern Kenya, commercial breeding ranches, butcher cooperatives, cold-chain freight operators, and regional policy makers into an actionable knowledge network.</p>
      <ul class="ticks" style="margin-top:1rem">
        <li><i class="fa-solid fa-circle-check"></i> <strong>Live Market Roundtables:</strong> Monthly dialogues matching cattle and goat cooperatives directly with high-volume abattoirs.</li>
        <li><i class="fa-solid fa-circle-check"></i> <strong>SPS &amp; Halal Trade Forums:</strong> Harmonizing cross-border export standards for Middle Eastern and intra-African red meat trade.</li>
        <li><i class="fa-solid fa-circle-check"></i> <strong>Youth &amp; Women Agribusiness Empowerment:</strong> Scaling commercial goat fattening feedlots and digital livestock tracking.</li>
      </ul>
    </div>
  </div>

  <h2 style="margin-top:3.5rem">Editorial Leadership &amp; Sector Specialists</h2>
  <div class="grid three">
    <?php foreach($team as $t): ?>
      <div class="pill rv">
        <h3><i class="fa-solid fa-user-check"></i> <?=e($t['name'])?></h3>
        <b class="kind"><?=e($t['role'])?></b>
        <p><?=e($t['bio'])?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ==========================================================================
     SECTION: COMMERCIAL LIVESTOCK & MEAT PRODUCTS
     Direct links to shop.meatsokogroup.com
     ========================================================================== -->
<?=products_section(6, true)?>

<!-- ==========================================================================
     SECTION: SPECIALIZED AGRIBUSINESS SERVICES
     ========================================================================== -->
<?=services_section()?>

<section class="wrap page" style="padding-top:0">
  <?php require __DIR__.'/includes/ecosystem.php'; ecosystem_section(); ?>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2 style="color:#ffffff">Partner with MeatSoko Media Group</h2>
      <p style="margin:0.2rem 0;color:#ffffff;opacity:0.95">Pitch an investigative story, sponsor industry research, or advertise to 50,000+ livestock stakeholders.</p>
    </div>
    <div style="display:flex;gap:0.8rem;flex-wrap:wrap">
      <a class="btn dark" href="<?=u('contact')?>">Contact Us</a>
      <a class="btn" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a>
      <?=partner('dark')?>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
