/**
 * assets/chat.js — Nyama AI Chat Widget Controller
 * 
 * Features:
 * - Persistent local conversation memory with configurable TTL (48 hours)
 * - Immediate "Clear Conversation" option with confirmation modal & toast notification
 * - Real-time SSE streaming from secure proxy (/api/chat.php)
 * - Rich Markdown rendering with marked.js (headings, lists, tables, bold, code)
 * - Draggable corner resizing + Fullscreen / Maximize toggle
 * - FontAwesome icons
 */

(function () {
  'use strict';

  // Persistence configuration (48 hours TTL)
  const PERSIST_TTL_HOURS = 48;
  const PERSIST_TTL_MS = PERSIST_TTL_HOURS * 60 * 60 * 1000;

  const STORAGE_KEY_DATA = 'meatsoko_nyama_session_v2';
  const STORAGE_KEY_OPEN = 'meatsoko_nyama_is_open';
  const STORAGE_KEY_SIZE = 'meatsoko_nyama_panel_size';

  let isStreaming = false;
  let abortController = null;
  let isFullscreen = false;

  // Cache DOM elements
  let launcherBtn, panel, closeBtn, resetBtn, expandBtn, resizeHandle;
  let messagesContainer, form, input, sendBtn;
  let confirmOverlay, confirmCancelBtn, confirmDeleteBtn, clearLink, toastEl;

  document.addEventListener('DOMContentLoaded', initChat);

  function initChat() {
    launcherBtn = document.getElementById('nyamaLauncher');
    panel = document.getElementById('nyamaPanel');
    closeBtn = document.getElementById('nyamaCloseBtn');
    resetBtn = document.getElementById('nyamaResetBtn');
    expandBtn = document.getElementById('nyamaExpandBtn');
    resizeHandle = document.getElementById('nyamaResizeHandle');
    messagesContainer = document.getElementById('nyamaMessages');
    form = document.getElementById('nyamaForm');
    input = document.getElementById('nyamaInput');
    sendBtn = document.getElementById('nyamaSendBtn');

    confirmOverlay = document.getElementById('nyamaConfirmOverlay');
    confirmCancelBtn = document.getElementById('nyamaConfirmCancel');
    confirmDeleteBtn = document.getElementById('nyamaConfirmDelete');
    clearLink = document.getElementById('nyamaClearLink');
    toastEl = document.getElementById('nyamaToast');

    if (!launcherBtn || !panel || !messagesContainer || !form || !input) {
      return;
    }

    // Configure marked if loaded
    if (window.marked) {
      window.marked.setOptions({
        breaks: true,
        gfm: true
      });
    }

    // Bind widget toggle & actions
    launcherBtn.addEventListener('click', toggleChat);
    if (closeBtn) closeBtn.addEventListener('click', closeChat);
    if (expandBtn) expandBtn.addEventListener('click', toggleFullscreen);

    // Clear / Reset triggers
    if (resetBtn) resetBtn.addEventListener('click', showClearConfirmation);
    if (clearLink) clearLink.addEventListener('click', (e) => {
      e.preventDefault();
      showClearConfirmation();
    });
    if (confirmCancelBtn) confirmCancelBtn.addEventListener('click', hideClearConfirmation);
    if (confirmDeleteBtn) confirmDeleteBtn.addEventListener('click', executeClearConversation);

    form.addEventListener('submit', handleSubmit);
    input.addEventListener('keydown', handleKeydown);
    input.addEventListener('input', autoResizeInput);

    // Escape key handling
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (confirmOverlay && confirmOverlay.classList.contains('active')) {
          hideClearConfirmation();
        } else if (panel.classList.contains('active')) {
          if (isFullscreen) {
            toggleFullscreen();
          } else {
            closeChat();
          }
        }
      }
    });

    // Close panel on outside click
    document.addEventListener('pointerdown', (e) => {
      if (
        panel.classList.contains('active') &&
        !isFullscreen &&
        !panel.contains(e.target) &&
        !launcherBtn.contains(e.target) &&
        !(confirmOverlay && confirmOverlay.contains(e.target))
      ) {
        closeChat();
      }
    });

    // Initialize draggable resizer
    initResizeHandle();

    // Bind suggestion chips
    bindChipEvents();

    // Restore saved size
    restoreSavedSize();

    // Restore saved history with TTL check
    restoreChatHistoryWithTTL();

    // Check if chat was open previously
    if (sessionStorage.getItem(STORAGE_KEY_OPEN) === 'true') {
      openChat(false);
    }
  }

  function toggleChat() {
    if (panel.classList.contains('active')) {
      closeChat();
    } else {
      openChat(true);
    }
  }

  function openChat(focus = true) {
    panel.classList.add('active');
    if (launcherBtn) launcherBtn.classList.add('nyama-hidden');
    document.body.classList.add('nyama-chat-open');
    sessionStorage.setItem(STORAGE_KEY_OPEN, 'true');
    scrollToBottom();
    autoResizeInput();
    if (focus && input) {
      setTimeout(() => input.focus(), 150);
    }
  }

  function closeChat() {
    panel.classList.remove('active');
    if (launcherBtn) launcherBtn.classList.remove('nyama-hidden');
    document.body.classList.remove('nyama-chat-open');
    sessionStorage.setItem(STORAGE_KEY_OPEN, 'false');
  }

  function toggleFullscreen() {
    isFullscreen = !isFullscreen;
    panel.classList.toggle('is-fullscreen', isFullscreen);
    
    if (expandBtn) {
      const icon = expandBtn.querySelector('i');
      if (icon) {
        icon.className = isFullscreen ? 'fa-solid fa-compress' : 'fa-solid fa-expand';
      }
      expandBtn.title = isFullscreen ? 'Exit Fullscreen (Esc)' : 'Maximize / Fullscreen';
    }

    scrollToBottom();
    if (input) input.focus();
  }

  function initResizeHandle() {
    if (!resizeHandle || !panel) return;

    let isResizing = false;
    let startX = 0, startY = 0;
    let startWidth = 0, startHeight = 0;

    const onMouseDown = (e) => {
      if (isFullscreen) return;
      isResizing = true;
      startX = e.clientX || (e.touches && e.touches[0].clientX);
      startY = e.clientY || (e.touches && e.touches[0].clientY);
      const rect = panel.getBoundingClientRect();
      startWidth = rect.width;
      startHeight = rect.height;

      document.body.style.userSelect = 'none';
      document.body.style.cursor = 'nwse-resize';

      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
      window.addEventListener('touchmove', onMouseMove, { passive: false });
      window.addEventListener('touchend', onMouseUp);
    };

    const onMouseMove = (e) => {
      if (!isResizing || isFullscreen) return;
      const clientX = e.clientX || (e.touches && e.touches[0].clientX);
      const clientY = e.clientY || (e.touches && e.touches[0].clientY);

      const deltaX = startX - clientX;
      const deltaY = startY - clientY;

      const newWidth = Math.min(Math.max(startWidth + deltaX, 320), window.innerWidth * 0.94);
      const newHeight = Math.min(Math.max(startHeight + deltaY, 380), window.innerHeight * 0.92);

      panel.style.width = newWidth + 'px';
      panel.style.height = newHeight + 'px';
    };

    const onMouseUp = () => {
      if (isResizing) {
        isResizing = false;
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
        window.removeEventListener('mousemove', onMouseMove);
        window.removeEventListener('mouseup', onMouseUp);
        window.removeEventListener('touchmove', onMouseMove);
        window.removeEventListener('touchend', onMouseUp);

        const rect = panel.getBoundingClientRect();
        sessionStorage.setItem(STORAGE_KEY_SIZE, JSON.stringify({
          w: Math.round(rect.width),
          h: Math.round(rect.height)
        }));
      }
    };

    resizeHandle.addEventListener('mousedown', onMouseDown);
    resizeHandle.addEventListener('touchstart', onMouseDown, { passive: true });
  }

  function restoreSavedSize() {
    try {
      const saved = JSON.parse(sessionStorage.getItem(STORAGE_KEY_SIZE));
      if (saved && saved.w && saved.h && window.innerWidth > 768) {
        panel.style.width = Math.min(saved.w, window.innerWidth * 0.94) + 'px';
        panel.style.height = Math.min(saved.h, window.innerHeight * 0.92) + 'px';
      }
    } catch (e) {}
  }

  function autoResizeInput() {
    if (!input) return;
    input.style.height = 'auto';
    const targetH = input.value.trim() ? Math.min(input.scrollHeight, 110) : 22;
    input.style.height = targetH + 'px';
  }

  function handleKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isStreaming) {
        form.dispatchEvent(new Event('submit', { cancelable: true }));
      }
    }
  }

  function scrollToBottom() {
    if (messagesContainer) {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
  }

  function sanitizeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function renderMarkdown(raw) {
    if (!raw) return '';

    if (window.marked && typeof window.marked.parse === 'function') {
      try {
        return window.marked.parse(raw);
      } catch (e) {
        console.warn('Marked parse error, using fallback', e);
      }
    }

    let text = sanitizeHtml(raw);
    text = text.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
    text = text.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    text = text.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    text = text.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/(^|[^\*])\*([^\*]+)\*/g, '$1<em>$2</em>');
    text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

    const lines = text.split('\n');
    let inList = false;
    let formatted = [];

    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      const isBullet = /^(\s*)[*-]\s+(.+)/.test(line);

      if (isBullet) {
        if (!inList) {
          formatted.push('<ul>');
          inList = true;
        }
        line = line.replace(/^(\s*)[*-]\s+(.+)/, '<li>$2</li>');
        formatted.push(line);
      } else {
        if (inList) {
          formatted.push('</ul>');
          inList = false;
        }
        if (line.trim().length > 0 && !line.startsWith('<h') && !line.startsWith('<pre') && !line.startsWith('</pre')) {
          formatted.push('<p>' + line + '</p>');
        } else {
          formatted.push(line);
        }
      }
    }
    if (inList) formatted.push('</ul>');

    return formatted.join('\n');
  }

  function appendMessage(role, content = '', save = true) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `nyama-msg nyama-msg-${role}`;

    const bubble = document.createElement('div');
    bubble.className = 'nyama-msg-bubble';

    if (role === 'user') {
      bubble.textContent = content;
    } else {
      bubble.innerHTML = renderMarkdown(content);
    }

    msgDiv.appendChild(bubble);
    messagesContainer.appendChild(msgDiv);
    scrollToBottom();

    if (save && content) {
      saveMessageToLocal(role, content);
    }

    return bubble;
  }

  // ─── LOCAL STORAGE WITH EXPIRATION (TTL) ──────────────────────────────────
  function getStoredData() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_DATA);
      if (!raw) return null;
      const data = JSON.parse(raw);

      // Check if data has expired (older than 48 hours)
      if (data && data.updatedAt) {
        if (Date.now() - data.updatedAt > PERSIST_TTL_MS) {
          localStorage.removeItem(STORAGE_KEY_DATA);
          return null;
        }
      }
      return data;
    } catch (e) {
      return null;
    }
  }

  function saveMessageToLocal(role, content) {
    try {
      const data = getStoredData() || { history: [], convId: null, updatedAt: Date.now() };
      data.history.push({ role, content, time: Date.now() });
      data.updatedAt = Date.now();
      localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(data));
    } catch (e) {}
  }

  function saveConversationId(convId) {
    try {
      const data = getStoredData() || { history: [], convId: null, updatedAt: Date.now() };
      data.convId = convId;
      data.updatedAt = Date.now();
      localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(data));
    } catch (e) {}
  }

  function removeWelcomeCard() {
    const card = document.getElementById('nyamaWelcomeCard');
    if (card) {
      card.remove();
    }
  }

  function restoreChatHistoryWithTTL() {
    const data = getStoredData();
    if (data && data.history && data.history.length > 0) {
      removeWelcomeCard();
      data.history.forEach(item => {
        appendMessage(item.role, item.content, false);
      });
    }
  }

  function bindChipEvents() {
    document.querySelectorAll('.nyama-chip').forEach(chip => {
      chip.onclick = () => {
        const text = chip.dataset.prompt || chip.textContent.trim();
        if (text && !isStreaming) {
          input.value = text;
          handleSubmit(new Event('submit'));
        }
      };
    });
  }

  // ─── CLEAR CONVERSATION FLOW ───────────────────────────────────────────────
  function showClearConfirmation() {
    if (confirmOverlay) {
      confirmOverlay.classList.add('active');
    } else {
      if (confirm('Are you sure you want to clear your conversation history?')) {
        executeClearConversation();
      }
    }
  }

  function hideClearConfirmation() {
    if (confirmOverlay) {
      confirmOverlay.classList.remove('active');
    }
  }

  async function executeClearConversation() {
    hideClearConfirmation();

    if (isStreaming) {
      if (abortController) abortController.abort();
      isStreaming = false;
    }

    // Wipe local persistence
    localStorage.removeItem(STORAGE_KEY_DATA);

    // Reset server session
    try {
      await fetch('api/chat.php?action=reset');
    } catch (e) {}

    // Reset UI
    messagesContainer.innerHTML = '';
    
    // Insert welcome card
    const welcomeHtml = `
      <div class="nyama-welcome-card" id="nyamaWelcomeCard">
        <p><i class="fa-solid fa-circle-info"></i> <strong>Welcome!</strong> I'm Nyama AI, MeatSoko's intelligent assistant. Ask me about our meat products, logistics, or investments.</p>
        <div class="nyama-chips">
          <button type="button" class="nyama-chip" data-prompt="What meat cuts and prices do you offer?"><i class="fa-solid fa-drumstick-bite"></i> Products &amp; Prices</button>
          <button type="button" class="nyama-chip" data-prompt="How does your cold chain and delivery work?"><i class="fa-solid fa-truck-fast"></i> Cold-Chain Logistics</button>
          <button type="button" class="nyama-chip" data-prompt="Tell me about Meatsoko investment options"><i class="fa-solid fa-coins"></i> Investment Plans</button>
          <button type="button" class="nyama-chip" data-prompt="Where are your headquarters and contact numbers?"><i class="fa-solid fa-location-dot"></i> Contact &amp; Location</button>
        </div>
      </div>
    `;
    messagesContainer.insertAdjacentHTML('beforeend', welcomeHtml);
    bindChipEvents();

    showToast('Conversation cleared');
  }

  function showToast(msg) {
    if (!toastEl) return;
    toastEl.innerHTML = `<i class="fa-solid fa-check"></i> <span>${sanitizeHtml(msg)}</span>`;
    toastEl.classList.add('show');
    setTimeout(() => {
      toastEl.classList.remove('show');
    }, 2400);
  }

  // ─── CHAT SUBMISSION & STREAMING ──────────────────────────────────────────
  async function handleSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();

    const userText = input.value.trim();
    if (!userText || isStreaming) return;

    input.value = '';
    autoResizeInput();
    setStreamingState(true);

    removeWelcomeCard();

    appendMessage('user', userText);

    // Create assistant bubble with typing indicator
    const msgDiv = document.createElement('div');
    msgDiv.className = 'nyama-msg nyama-msg-assistant';

    const bubble = document.createElement('div');
    bubble.className = 'nyama-msg-bubble';
    bubble.innerHTML = `
      <div class="nyama-typing-indicator">
        <span class="nyama-typing-dot"></span>
        <span class="nyama-typing-dot"></span>
        <span class="nyama-typing-dot"></span>
      </div>
    `;
    msgDiv.appendChild(bubble);
    messagesContainer.appendChild(msgDiv);
    scrollToBottom();

    let fullAnswer = '';
    let toolBadge = null;
    const stored = getStoredData();
    const conversationId = stored ? stored.convId : null;

    abortController = new AbortController();

    try {
      const response = await fetch('api/chat.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream'
        },
        body: JSON.stringify({
          message: userText,
          conversation_id: conversationId || undefined,
          stream: true
        }),
        signal: abortController.signal
      });

      if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (_) {}
        throw new Error(errData.error || `Server returned status ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (!dataStr) continue;

            try {
              const data = JSON.parse(dataStr);

              // 1. Capture conversation_id
              if (data.type === 'run.started' && data.conversation_id) {
                saveConversationId(data.conversation_id);
              }

              // 2. Tool indicator
              if (data.type === 'tool.started') {
                if (!toolBadge) {
                  toolBadge = document.createElement('div');
                  toolBadge.className = 'nyama-tool-badge';
                  bubble.innerHTML = '';
                  bubble.appendChild(toolBadge);
                }
                toolBadge.innerHTML = `<i class="fa-solid fa-magnifying-glass"></i> <em>Searching company documents...</em>`;
                scrollToBottom();
              }

              // 3. Tool completed
              if (data.type === 'tool.finished' && toolBadge) {
                toolBadge.innerHTML = `<i class="fa-solid fa-check" style="color:#2E7D32;"></i> <em>Information retrieved</em>`;
                setTimeout(() => {
                  if (toolBadge && toolBadge.parentNode) {
                    toolBadge.remove();
                    toolBadge = null;
                  }
                }, 1200);
              }

              // 4. Stream token
              if (data.type === 'token') {
                if (!fullAnswer && !toolBadge) {
                  bubble.innerHTML = '';
                }
                fullAnswer += data.text;
                bubble.innerHTML = (toolBadge ? toolBadge.outerHTML : '') + renderMarkdown(fullAnswer);
                scrollToBottom();
              }

              // 5. Run completed
              if (data.type === 'run.completed') {
                if (data.conversation_id) {
                  saveConversationId(data.conversation_id);
                }
                if (data.output && !fullAnswer) {
                  fullAnswer = data.output;
                }
                bubble.innerHTML = renderMarkdown(fullAnswer);
                saveMessageToLocal('assistant', fullAnswer);
                scrollToBottom();
              }

              // 6. Run failed
              if (data.type === 'run.failed') {
                const errMsg = data.message || 'The request could not be completed.';
                bubble.innerHTML = `<p style="color:#C62828;"><i class="fa-solid fa-circle-exclamation"></i> <strong>Error:</strong> ${sanitizeHtml(errMsg)}</p>`;
                saveMessageToLocal('assistant', `Error: ${errMsg}`);
              }

            } catch (jsonErr) {}
          }
        }
      }

      if (fullAnswer && !bubble.innerHTML.includes(renderMarkdown(fullAnswer))) {
        bubble.innerHTML = renderMarkdown(fullAnswer);
        saveMessageToLocal('assistant', fullAnswer);
      }

    } catch (err) {
      if (err.name !== 'AbortError') {
        bubble.innerHTML = `<p style="color:#C62828;"><i class="fa-solid fa-circle-exclamation"></i> <strong>Error:</strong> ${sanitizeHtml(err.message || 'Unable to connect to Nyama AI.')}</p>`;
      }
    } finally {
      setStreamingState(false);
      abortController = null;
    }
  }

  function setStreamingState(streaming) {
    isStreaming = streaming;
    if (sendBtn) sendBtn.disabled = streaming;
    if (input && !streaming) {
      input.focus();
    }
  }

})();
