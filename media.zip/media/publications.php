<?php require __DIR__.'/includes/functions.php';
$page='publications';$pageTitle='Publications';$pb=load('publications');require 'includes/header.php';?>
<section class="wrap page"><h1>Publications</h1><p class="lead">Magazines, reports and briefings from <?=e(SITE_SHORT)?>.</p><div class="grid three">
<?php foreach($pb as $p){$has=!empty($p['file']);echo '<div class="pill rv"><h3><i class="fa-solid fa-'.e($p['icon']).'"></i> '.e($p['title']).'</h3><b class="kind">'.e($p['type']).' &middot; '.e($p['freq']).'</b><p>'.e($p['desc']).'</p><a class="btn" href="'.($has?e($p['file']):u('contact').'?topic=publication&amp;ref='.e($p['slug'])).'"><i class="fa-solid fa-'.($has?'download':'paper-plane').'"></i> '.($has?'Download':'Request a copy').'</a></div>';}?></div></section>
<?=shop_callout_banner()?>
<?php require 'includes/footer.php';
