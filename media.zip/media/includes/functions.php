<?php
require_once __DIR__.'/../config.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();

const IMG = [
  'hero'       => 'https://upload.wikimedia.org/wikipedia/commons/4/43/Maasai_cattle%2C_Kenya.jpg',
  'about'      => 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=70',
  'News'       => 'https://upload.wikimedia.org/wikipedia/commons/b/bb/Boran_cattle_in_Kenya.jpg',
  'Analysis'   => 'https://upload.wikimedia.org/wikipedia/commons/d/df/Galla_goat_at_kasarani.jpg',
  'networking' => 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=70',
  'conference' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=70',
  'cattle'     => 'https://upload.wikimedia.org/wikipedia/commons/b/bb/Boran_cattle_in_Kenya.jpg',
  'goat'       => 'https://upload.wikimedia.org/wikipedia/commons/d/df/Galla_goat_at_kasarani.jpg',
  'cow'        => 'https://upload.wikimedia.org/wikipedia/commons/2/29/Ankole_bull.jpg'
];

function partner($c=''){
  $x=PARTNER_URL;
  $ext=preg_match('#^https?://#i',$x);
  return '<a class="btn pulse '.e($c).'" href="'.($ext?e($x):u($x)).'"'.($ext?' target="_blank" rel="noopener"':'').'><i class="fa-solid fa-handshake"></i> '.e(PARTNER_LABEL).' <i class="fa-solid fa-arrow-right go"></i></a>';
}

function e($s){
  return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');
}

function load($n){
  $f=__DIR__."/../data/$n.json";
  return is_file($f)?(json_decode(file_get_contents($f),true)?:[]):[];
}

function save($n,$d){
  file_put_contents(__DIR__."/../data/$n.json",json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
}

function u($f){
  if($f==='index')return CLEAN_URLS?'./':'index.php';
  return CLEAN_URLS?$f:$f.'.php';
}

function csrf(){
  if(empty($_SESSION['t']))$_SESSION['t']=bin2hex(random_bytes(16));
  return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">';
}

function ok(){
  return isset($_POST['t'],$_SESSION['t'])&&hash_equals($_SESSION['t'],$_POST['t']);
}

function go($f){
  header('Location: '.u($f));
  exit;
}

function flash(){
  $m=$_SESSION['flash']??'';
  unset($_SESSION['flash']);
  return $m?'<p class="flash" role="status">'.e($m).'</p>':'';
}

function check_rate_limit(string $action, int $max = 5, int $window = 300): bool {
  $ip = preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
  $file = sys_get_temp_dir() . '/mrih_rate_' . md5($action . '_' . $ip) . '.json';
  $now = time();
  $data = ['count' => 0, 'first' => $now];
  if (is_file($file)) {
    $data = json_decode((string)@file_get_contents($file), true) ?: $data;
    if (($now - ($data['first'] ?? 0)) > $window) {
      $data = ['count' => 0, 'first' => $now];
    }
  }
  return ($data['count'] ?? 0) < $max;
}

function hit_rate_limit(string $action, int $window = 300): void {
  $ip = preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
  $file = sys_get_temp_dir() . '/mrih_rate_' . md5($action . '_' . $ip) . '.json';
  $now = time();
  $data = ['count' => 0, 'first' => $now];
  if (is_file($file)) {
    $data = json_decode((string)@file_get_contents($file), true) ?: $data;
    if (($now - ($data['first'] ?? 0)) > $window) {
      $data = ['count' => 0, 'first' => $now];
    }
  }
  $data['count'] = ($data['count'] ?? 0) + 1;
  @file_put_contents($file, json_encode($data), LOCK_EX);
}

function clear_rate_limit(string $action): void {
  $ip = preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
  $file = sys_get_temp_dir() . '/mrih_rate_' . md5($action . '_' . $ip) . '.json';
  if (is_file($file)) @unlink($file);
}

function posts($type=''){
  $p=load('articles');
  if($type)$p=array_values(array_filter($p,fn($x)=>$x['type']===$type));
  usort($p,fn($a,$b)=>strcmp($b['date'],$a['date']));
  return $p;
}

function mins($x){
  $body = is_array($x) ? ($x['body'] ?? '') : '';
  return max(1,(int)ceil(str_word_count($body)/200));
}

function pic($x){
  if(is_array($x)&&!empty($x['image']))return e($x['image']);
  $t=is_array($x)?($x['type']??'News'):'News';
  return IMG[$t]??IMG['News'];
}

function card($x){
  return '<a class="card rv" data-c="'.e($x['category']).'" data-s="'.e(strtolower($x['title'].' '.$x['summary'].' '.$x['category'])).'" href="'.u('post').'?id='.e($x['id']).'"><img loading="lazy" alt="'.e($x['title']).'" src="'.pic($x).'"><div><b class="kind">'.e($x['type']).' &middot; '.e($x['category']).'</b><h3>'.e($x['title']).'</h3><p>'.e($x['summary']).'</p><time><i class="fa-regular fa-calendar"></i> '.e($x['date']).' &middot; '.mins($x).' min read</time></div></a>';
}

function listing($type,$title,$lead){
  global $page,$pageTitle;
  $page=strtolower($type);
  $pageTitle=$title;
  $l=posts($type);
  $cats=array_values(array_unique(array_column($l,'category')));
  require __DIR__.'/header.php';
  echo '<section class="wrap page"><h1>'.e($title).'</h1><p class="lead">'.e($lead).'</p><input id="qn" type="search" placeholder="Search '.e(strtolower($title)).'" aria-label="Search"><div class="chips"><button class="chip-btn on" data-c="all">All</button>';
  foreach($cats as $c)echo '<button class="chip-btn" data-c="'.e($c).'">'.e($c).'</button>';
  echo '</div><div class="grid" id="people">';
  foreach($l as $x)echo card($x);
  if(!$l)echo '<p>Nothing published yet.</p>';
  echo '</div></section>';
  echo shop_callout_banner();
  require __DIR__.'/footer.php';
}

function product_card($p){
  $url = 'https://shop.meatsokogroup.com';
  $cat = $p['category'] ?? 'Livestock';
  $specs = $p['specs'] ?? [];
  $badge = $p['badge'] ?? '';
  $status = $p['status'] ?? 'Available';
  $img = !empty($p['image']) ? $p['image'] : (IMG['cattle'] ?? '');
  $searchStr = strtolower(($p['name'] ?? '') . ' ' . $cat . ' ' . ($p['breed'] ?? '') . ' ' . ($p['description'] ?? ''));

  $html = '<div class="prod-card rv" data-cat="' . e($cat) . '" data-search="' . e($searchStr) . '" onclick="if(event.target.tagName!==\'A\'&&!event.target.closest(\'a\'))window.open(\'https://shop.meatsokogroup.com\',\'_blank\',\'noopener\')" style="cursor:pointer">';
  $html .= '  <a class="prod-img-wrap" href="' . e($url) . '" target="_blank" rel="noopener" title="Order ' . e($p['name']) . ' on MeatSoko Shop">';
  $html .= '    <img loading="lazy" src="' . e($img) . '" alt="' . e($p['name']) . '">';
  if ($badge) {
    $html .= '    <span class="prod-badge">' . e($badge) . '</span>';
  }
  $html .= '    <span class="prod-category-tag"><i class="fa-solid fa-tag"></i> ' . e($cat) . '</span>';
  $html .= '  </a>';
  $html .= '  <div class="prod-body">';
  $html .= '    <div class="prod-status"><span class="prod-dot"></span> ' . e($status) . '</div>';
  $html .= '    <h3 class="prod-title"><a href="' . e($url) . '" target="_blank" rel="noopener">' . e($p['name']) . '</a></h3>';
  $html .= '    <p class="prod-desc">' . e($p['description'] ?? '') . '</p>';
  $html .= '    <div class="prod-meta">';
  if (!empty($p['weight'])) {
    $html .= '      <span><i class="fa-solid fa-weight-scale"></i> ' . e($p['weight']) . '</span>';
  }
  if (!empty($p['origin'])) {
    $html .= '      <span><i class="fa-solid fa-location-dot"></i> ' . e($p['origin']) . '</span>';
  }
  $html .= '    </div>';
  if (!empty($specs)) {
    $html .= '    <ul class="prod-specs">';
    foreach (array_slice($specs, 0, 3) as $spec) {
      $html .= '      <li><i class="fa-solid fa-check"></i> ' . e($spec) . '</li>';
    }
    $html .= '    </ul>';
  }
  $html .= '    <div class="prod-footer">';
  $html .= '      <a class="btn prod-buy-btn" href="' . e($url) . '" target="_blank" rel="noopener" title="Order on MeatSoko Shop">';
  $html .= '        <i class="fa-solid fa-cart-shopping"></i> Order on shop.meatsokogroup.com <i class="fa-solid fa-arrow-up-right-from-square"></i>';
  $html .= '      </a>';
  $html .= '    </div>';
  $html .= '  </div>';
  $html .= '</div>';
  return $html;
}

function service_card($s){
  $url = 'https://shop.meatsokogroup.com';
  $icon = !empty($s['icon']) ? $s['icon'] : 'briefcase';
  $pillar = !empty($s['pillar']) ? $s['pillar'] : 'MeatSoko Ecosystem';
  $points = $s['points'] ?? [];

  $html = '<div class="serv-card rv" onclick="if(event.target.tagName!==\'A\'&&!event.target.closest(\'a\'))window.open(\'https://shop.meatsokogroup.com\',\'_blank\',\'noopener\')" style="cursor:pointer">';
  $html .= '  <div class="serv-top">';
  $html .= '    <div class="serv-icon"><i class="fa-solid fa-' . e($icon) . '"></i></div>';
  $html .= '    <span class="serv-pillar">' . e($pillar) . '</span>';
  $html .= '  </div>';
  $html .= '  <h3><a href="' . e($url) . '" target="_blank" rel="noopener" style="color:inherit;text-decoration:none">' . e($s['title']) . '</a></h3>';
  $html .= '  <p class="serv-lead">' . e($s['lead']) . '</p>';
  if (!empty($points)) {
    $html .= '  <ul class="serv-ticks">';
    foreach ($points as $pt) {
      $html .= '    <li><i class="fa-solid fa-circle-check"></i> <span>' . e($pt) . '</span></li>';
    }
    $html .= '  </ul>';
  }
  $html .= '  <div class="serv-act">';
  $html .= '    <a class="btn alt-green serv-btn" href="' . e($url) . '" target="_blank" rel="noopener">';
  $html .= '      ' . e($s['action_label'] ?? 'Explore on Shop') . ' <i class="fa-solid fa-arrow-up-right-from-square"></i>';
  $html .= '    </a>';
  $html .= '  </div>';
  $html .= '</div>';
  return $html;
}

function products_section($limit = 0, $show_filters = true){
  $products = load('products');
  if (empty($products)) return '';
  $display = $limit > 0 ? array_slice($products, 0, $limit) : $products;

  ob_start();
  ?>
  <!-- Product Catalog Section -->
  <section class="wrap prod-section" id="products">
    <div class="sec-head">
      <div>
        <b class="kind"><i class="fa-solid fa-store"></i> MeatSoko Livestock &amp; Meat Marketplace</b>
        <h2>Verified Livestock &amp; Meat Products</h2>
        <p class="lead">Procure live sheep, goats, prime beef steers, and hygienic abattoir carcasses directly through <a href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="font-weight:700;color:var(--red);text-decoration:underline">shop.meatsokogroup.com</a> with certified live weights and veterinary movement permits.</p>
      </div>
      <div class="sec-actions">
        <a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener">
          <i class="fa-solid fa-basket-shopping"></i> Visit MeatSoko Shop <i class="fa-solid fa-arrow-up-right-from-square"></i>
        </a>
      </div>
    </div>

    <?php if ($show_filters): ?>
    <div class="prod-filters" role="tablist" aria-label="Product Categories">
      <button type="button" class="prod-filter-btn on" data-cat="all"><i class="fa-solid fa-border-all"></i> All Products (<?=count($products)?>)</button>
      <button type="button" class="prod-filter-btn" data-cat="Sheep"><i class="fa-solid fa-shield-cat"></i> Sheep (Dorper &amp; Red Maasai)</button>
      <button type="button" class="prod-filter-btn" data-cat="Goats"><i class="fa-solid fa-paw"></i> Goats (Galla &amp; Boer)</button>
      <button type="button" class="prod-filter-btn" data-cat="Cattle"><i class="fa-solid fa-cow"></i> Cattle &amp; Bulls</button>
      <button type="button" class="prod-filter-btn" data-cat="Wholesale Cuts"><i class="fa-solid fa-drumstick-bite"></i> Wholesale Meat Cuts</button>
    </div>
    <?php endif; ?>

    <div class="prod-grid" id="productGrid">
      <?php foreach ($display as $p) echo product_card($p); ?>
    </div>

    <div class="shop-trust-banner rv">
      <div class="st-item">
        <i class="fa-solid fa-scale-balanced"></i>
        <div>
          <strong>Calibrated Weighbridges</strong>
          <span>Live weight certified on digital scale weighbridges</span>
        </div>
      </div>
      <div class="st-item">
        <i class="fa-solid fa-notes-medical"></i>
        <div>
          <strong>Veterinary &amp; SPS Cleared</strong>
          <span>Fully vaccinated, dewormed, and health documented</span>
        </div>
      </div>
      <div class="st-item">
        <i class="fa-solid fa-truck-fast"></i>
        <div>
          <strong>Cold-Chain &amp; Live Transit</strong>
          <span>0°C–4°C reefers and humane livestock haulage fleets</span>
        </div>
      </div>
      <div class="st-item">
        <i class="fa-solid fa-shield-halved"></i>
        <div>
          <strong>Guaranteed Escrow Payouts</strong>
          <span>Zero default risk via MeatSoko Assets &amp; Investments</span>
        </div>
      </div>
    </div>
  </section>
  <?php
  return ob_get_clean();
}

function services_section(){
  $services = load('services');
  if (empty($services)) return '';

  ob_start();
  ?>
  <!-- Specialized Agribusiness Services Section -->
  <section class="wrap services-section" id="services">
    <div class="sec-head">
      <div>
        <b class="kind"><i class="fa-solid fa-cubes"></i> End-to-End Value-Chain Infrastructure</b>
        <h2>Specialized Industry Services</h2>
        <p class="lead">From cold-chain transport fleets to Halal standards, veterinary quarantine diagnostics, and instant trade settlement across East Africa.</p>
      </div>
      <div class="sec-actions">
        <a class="btn alt-green" href="<?=u('contact')?>"><i class="fa-solid fa-headset"></i> Service Inquiries &amp; Desk</a>
      </div>
    </div>

    <div class="serv-grid">
      <?php foreach ($services as $s) echo service_card($s); ?>
    </div>
  </section>
  <?php
  return ob_get_clean();
}

function shop_callout_banner(){
  ob_start();
  ?>
  <section class="wrap" style="padding-top:0">
    <div class="shop-strip-callout rv">
      <div class="ssc-text">
        <b class="kind"><i class="fa-solid fa-shop"></i> MeatSoko Livestock &amp; Meat Sourcing</b>
        <h3>Looking to Procure Verified Sheep, Goats, or Cattle?</h3>
        <p>Explore live animals and premium wholesale cuts directly on MeatSoko Shop (<a href="https://shop.meatsokogroup.com" target="_blank" rel="noopener" style="font-weight:700;color:inherit;text-decoration:underline">shop.meatsokogroup.com</a>) with guaranteed weighbridge weights and cold-chain transit.</p>
      </div>
      <div class="ssc-acts">
        <a class="btn green" href="https://shop.meatsokogroup.com" target="_blank" rel="noopener">
          <i class="fa-solid fa-cart-shopping"></i> Order on shop.meatsokogroup.com <i class="fa-solid fa-arrow-up-right-from-square"></i>
        </a>
        <a class="btn alt-green" href="tel:<?=e(SITE_PHONE)?>">
          <i class="fa-solid fa-phone"></i> Call: <?=e(SITE_PHONE)?>
        </a>
      </div>
    </div>
  </section>
  <?php
  return ob_get_clean();
}
