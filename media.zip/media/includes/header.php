<?php
require_once __DIR__.'/functions.php';
$page = $page ?? '';
$pageTitle = $pageTitle ?? 'Livestock & Meat Industry Intelligence';
$NAV = [
  'index'        => ['Home', 'house'],
  'news'         => ['News', 'newspaper'],
  'analysis'     => ['Analysis', 'chart-line'],
  'publications' => ['Publications', 'book-open'],
  'about'        => ['About', 'circle-info'],
  'contact'      => ['Contact', 'envelope']
];
$BOT = array_intersect_key($NAV, array_flip(['index', 'news', 'analysis', 'publications', 'contact']));
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($pageTitle)?> | <?=e(SITE_SHORT)?></title>
<meta name="description" content="<?=e(SITE_SHORT)?>: <?=e(SITE_TAG)?>. Independent reporting, cattle & goat market prices, supply chain analysis, and continental livestock trade.">
<script>try{document.documentElement.dataset.theme=localStorage.theme||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light')}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700;800&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/chat.css">
<script src="assets/js/main.js" defer></script>
</head>
<body>
<header class="top" id="top">
  <a class="logo" href="<?=u('index')?>">
    <span class="tagmark"></span>
    <span><?=e(SITE_SHORT)?><small><?=e(SITE_TAG)?></small></span>
  </a>
  <nav class="dnav" aria-label="Main">
    <?php foreach($NAV as $navSlug=>$navItem): ?>
      <a href="<?=u($navSlug)?>"<?=($page===$navSlug?' aria-current="page"':'')?>><?=e($navItem[0])?></a>
    <?php endforeach; ?>
  </nav>
  <div class="acts">
    <a class="ic phone-top-btn" href="tel:<?=e(SITE_PHONE)?>" title="Call <?=e(SITE_PHONE)?>" aria-label="Call <?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i></a>
    <a class="ic wa-top-btn" href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener" title="WhatsApp <?=e(SITE_PHONE)?>" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
    <button class="ic theme-btn" aria-label="Toggle light or dark theme"><i class="fa-solid fa-moon t-moon"></i><i class="fa-solid fa-sun t-sun"></i></button>
    <button class="ic menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="side"><i class="fa-solid fa-bars"></i></button>
  </div>
</header>
<div class="veil" id="veil"></div>
<aside class="side" id="side" aria-label="Menu">
  <div class="sidehead">
    <b><?=e(SITE_SHORT)?></b>
    <button class="ic" id="closeBtn" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button>
  </div>
  <?php foreach($NAV as $navSlug=>$navItem): ?>
    <a href="<?=u($navSlug)?>"<?=($page===$navSlug?' aria-current="page"':'')?>>
      <span><i class="fa-solid fa-<?=$navItem[1]?>"></i></span><?=e($navItem[0])?>
    </a>
  <?php endforeach; ?>
  <button class="theme-btn wide"><i class="fa-solid fa-circle-half-stroke"></i> Switch light / dark</button>
  <div class="sidenote">
    <div style="font-weight:700;margin-bottom:0.3rem"><?=e(SITE_SHORT)?></div>
    <a href="tel:<?=e(SITE_PHONE)?>" style="color:inherit;text-decoration:none;display:flex;align-items:center;gap:0.4rem;margin-bottom:0.25rem"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a>
    <a href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener" style="color:inherit;text-decoration:none;display:flex;align-items:center;gap:0.4rem;margin-bottom:0.25rem"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
    <a href="mailto:<?=e(SITE_EMAIL)?>" style="color:inherit;text-decoration:none;display:flex;align-items:center;gap:0.4rem"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a>
  </div>
</aside>
<main>
