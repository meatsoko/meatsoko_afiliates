<?php
// Shared "MeatSoko ecosystem" section. Content comes from data/ecosystem.json
function ecosystem_section(){
  $eco = load('ecosystem');
  if(!$eco) return;
  $me = defined('ECO_PILLAR') ? ECO_PILLAR : '';

  echo '<b class="kind"><i class="fa-solid fa-network-wired"></i> MeatSoko Group Architecture</b>';
  echo '<h2 style="margin-top:0.3rem">Part of the Connected African MeatSoko Ecosystem</h2>';
  echo '<p class="lead">'.e($eco['intro'] ?? '').'</p>';
  
  echo '<div class="pill rv" style="margin:1.5rem 0;border-top-width:6px">';
  echo '<h3><i class="fa-solid fa-key"></i> One Membership &middot; Full Ecosystem Access</h3>';
  echo '<p>'.e($eco['access']['text'] ?? '').'</p>';
  echo '</div>';

  echo '<div class="grid three">';
  foreach($eco['pillars'] ?? [] as $p){
    $mine = ($p['name'] === $me);
    echo '<div class="pill rv'.($mine ? ' me' : '').'">';
    echo '<h3><i class="fa-solid fa-'.e($p['icon']).'"></i> '.e($p['name']).'</h3>';
    if($mine) echo '<b class="kind" style="display:block;margin-bottom:0.5rem"><i class="fa-solid fa-star"></i> This Company (Tech &amp; Media)</b>';
    echo '<ul class="ticks">';
    foreach($p['items'] as $li) echo '<li><i class="fa-solid fa-check"></i> <span>'.e($li).'</span></li>';
    echo '</ul></div>';
  }
  echo '</div>';

  echo '<p class="lead" style="margin-top:1.8rem;font-size:1.05rem">'.e($eco['marketplace_note'] ?? '').' '.e($eco['external_services'] ?? '').'</p>';

  echo '<h2 style="margin-top:3.5rem"><i class="fa-solid fa-arrows-spin"></i> Value Chain Lifecycle: From Rangeland to Market</h2>';
  echo '<div class="grid three">';
  foreach($eco['flow'] ?? [] as $flowStep){
    echo '<div class="pill rv">';
    echo '<b class="kind">Step '.(int)$flowStep['step'].'</b>';
    echo '<h3 style="margin:0.3rem 0">'.e($flowStep['title']).'</h3>';
    echo '<p>'.e($flowStep['text']).'</p>';
    echo '</div>';
  }
  echo '</div>';
}
