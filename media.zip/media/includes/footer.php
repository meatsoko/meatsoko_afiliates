</main>
<footer class="foot">
  <div class="fwrap">
    <div>
      <b><?=e(SITE_SHORT)?></b>
      <p><?=e(SITE_TAG)?>. Independent reporting, cattle &amp; goat market intelligence, and value-chain analysis.</p>
      <small>&copy; <?=date('Y')?> MeatSoko Group. All rights reserved. Registered livestock intelligence platform.</small>
    </div>
    <nav aria-label="Footer">
      <?php foreach($NAV as $navSlug=>$navItem): ?>
        <a href="<?=u($navSlug)?>"><?=e($navItem[0])?></a>
      <?php endforeach; ?>
      <a href="https://shop.meatsokogroup.com" target="_blank" rel="noopener">MeatSoko Shop</a>
      <a href="api.php">API</a>
    </nav>
    <div class="fr">
      <a href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a>
      <a href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp: <?=e(SITE_PHONE)?></a>
      <a href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a>
      <small><i class="fa-solid fa-location-dot"></i> <?=e(SITE_LOCATION)?></small>
    </div>
  </div>
</footer>
<nav class="bnav" aria-label="Mobile">
  <?php foreach($BOT as $botSlug=>$botItem): ?>
    <a href="<?=u($botSlug)?>"<?=($page===$botSlug?' aria-current="page"':'')?>>
      <span><i class="fa-solid fa-<?=$botItem[1]?>"></i></span>
      <?=e($botItem[0])?>
    </a>
  <?php endforeach; ?>
</nav>

  <!-- NYAMA AI FLOATING CHAT WIDGET -->
  <button class="nyama-chat-launcher" id="nyamaLauncher" aria-label="Chat with Nyama AI">
    <div class="nyama-launcher-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
    <span>Ask Nyama AI</span>
    <span class="nyama-launcher-pulse"></span>
  </button>

  <div class="nyama-chat-panel" id="nyamaPanel" role="dialog" aria-label="Nyama AI Assistant">
    <!-- Draggable Resize Grip -->
    <div class="nyama-resize-handle" id="nyamaResizeHandle" title="Drag to resize window"></div>

    <!-- Header -->
    <div class="nyama-chat-header">
      <div class="nyama-header-info">
        <div class="nyama-avatar">
          <i class="fa-solid fa-robot"></i>
          <span class="nyama-avatar-status"></span>
        </div>
        <div class="nyama-header-text">
          <h3>Nyama AI <span class="nyama-badge">Media Desk</span></h3>
          <p>Livestock Intelligence &bull; Online</p>
        </div>
      </div>
      <div class="nyama-header-actions">
        <button type="button" class="nyama-btn-icon" id="nyamaResetBtn" title="Clear Conversation" aria-label="Clear chat">
          <i class="fa-solid fa-trash-can"></i>
        </button>
        <button type="button" class="nyama-btn-icon" id="nyamaExpandBtn" title="Maximize / Fullscreen" aria-label="Maximize">
          <i class="fa-solid fa-expand"></i>
        </button>
        <button type="button" class="nyama-btn-icon" id="nyamaCloseBtn" title="Close Chat" aria-label="Close Chat">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
    </div>

    <!-- Notification Toast -->
    <div class="nyama-toast" id="nyamaToast"></div>

    <!-- Confirmation Modal -->
    <div class="nyama-confirm-overlay" id="nyamaConfirmOverlay">
      <div class="nyama-confirm-card">
        <div class="nyama-confirm-icon">
          <i class="fa-solid fa-trash-can"></i>
        </div>
        <h4>Clear Conversation?</h4>
        <p>This will permanently erase the current chat history from your browser.</p>
        <div class="nyama-confirm-actions">
          <button type="button" class="nyama-btn-confirm-cancel" id="nyamaConfirmCancel">Cancel</button>
          <button type="button" class="nyama-btn-confirm-delete" id="nyamaConfirmDelete">Clear Chat</button>
        </div>
      </div>
    </div>

    <!-- Messages Container -->
    <div class="nyama-chat-messages" id="nyamaMessages">
      <div class="nyama-welcome-card" id="nyamaWelcomeCard">
        <p><i class="fa-solid fa-circle-info"></i> <strong>Welcome!</strong> I'm Nyama AI, MeatSoko's intelligent assistant. Ask me about livestock market intelligence, industry reports, media publications, or trade partnerships.</p>
        <div class="nyama-chips">
          <button type="button" class="nyama-chip" data-prompt="Where can I buy live sheep, goats, cattle, or wholesale meat on MeatSoko Shop (shop.meatsokogroup.com)?"><i class="fa-solid fa-cart-shopping"></i> Buy Livestock &amp; Meat</button>
          <button type="button" class="nyama-chip" data-prompt="What are the current livestock market price trends across Kenya and the Horn of Africa?"><i class="fa-solid fa-chart-line"></i> Market Intelligence</button>
          <button type="button" class="nyama-chip" data-prompt="What publications and research reports has MeatSoko Media published?"><i class="fa-solid fa-book-open"></i> Media Publications</button>
          <button type="button" class="nyama-chip" data-prompt="How does MeatSoko Media cover value-chain infrastructure and abattoir investments?"><i class="fa-solid fa-newspaper"></i> Industry Analysis</button>
          <button type="button" class="nyama-chip" data-prompt="How can organizations advertise, contribute editorial content, or partner with MeatSoko Media?"><i class="fa-solid fa-handshake"></i> Partnerships</button>
        </div>
      </div>
    </div>

    <!-- Footer Input Bar -->
    <div class="nyama-chat-footer">
      <form class="nyama-chat-form" id="nyamaForm">
        <textarea 
          class="nyama-chat-input" 
          id="nyamaInput" 
          placeholder="Ask Nyama about livestock news, prices, reports..." 
          rows="1" 
          aria-label="Message Nyama AI"
        ></textarea>
        <button type="submit" class="nyama-btn-send" id="nyamaSendBtn" aria-label="Send message">
          <i class="fa-solid fa-paper-plane"></i>
        </button>
      </form>
      <p class="nyama-footer-note">Powered by Nyama AI Agents &bull; Press Enter to send &bull; <a href="#" class="nyama-clear-link" id="nyamaClearLink">Clear chat</a></p>
    </div>
  </div>

  <script src="assets/js/marked.min.js"></script>
  <script src="assets/js/chat.js"></script>
</body>
</html>
