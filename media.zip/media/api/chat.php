<?php
declare(strict_types=1);

/**
 * api/chat.php — Secure Nyama AI Gateway Proxy for MeatSoko Media Group
 *
 * Proxies chat requests between client browser and ai.meatsokogroup.com.
 * Keeps API secrets isolated server-side.
 */

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    @session_start();
}

require_once __DIR__ . '/../config.php';

// Check for simple reset action
$action = $_GET['action'] ?? null;
if ($action === 'reset') {
    $_SESSION['nyama_conversation_id'] = null;
    header('Content-Type: application/json');
    echo json_encode(['status' => 'ok', 'message' => 'Conversation reset successfully']);
    exit;
}

if ($action === 'status') {
    header('Content-Type: application/json');
    $hasKey = defined('AI_API_KEY') && !empty(AI_API_KEY);
    echo json_encode([
        'status' => 'ok',
        'configured' => $hasKey,
        'agent' => defined('AI_AGENT') ? AI_AGENT : 'nyama'
    ]);
    exit;
}

// Ensure POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Method Not Allowed. POST is required.']);
    exit;
}

// Rate limiting (25 requests per minute per IP)
$now = time();
$ip = preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
$ipKey = 'rate_' . md5('chat_' . $ip);
if (!isset($_SESSION[$ipKey]) || ($now - $_SESSION[$ipKey]['start'] > 60)) {
    $_SESSION[$ipKey] = ['count' => 1, 'start' => $now];
} else {
    $_SESSION[$ipKey]['count']++;
    if ($_SESSION[$ipKey]['count'] > 25) {
        http_response_code(429);
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'Rate limit exceeded. Please wait a moment before sending another message.',
            'code' => 'rate_limited'
        ]);
        exit;
    }
}

// Parse JSON input
$rawInput = (string)file_get_contents('php://input');
$input = json_decode($rawInput, true);

$message = isset($input['message']) ? trim((string)$input['message']) : '';
$stream = isset($input['stream']) ? (bool)$input['stream'] : true;
$requestedConvId = !empty($input['conversation_id'])
    ? trim((string)$input['conversation_id'])
    : ($_SESSION['nyama_conversation_id'] ?? null);

if (empty($message)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Message cannot be empty.', 'code' => 'message_required']);
    exit;
}

if (mb_strlen($message) > 4000) {
    $message = mb_substr($message, 0, 4000);
}

// Read credentials
$apiKey = defined('AI_API_KEY') ? (string)AI_API_KEY : '';
$baseUrl = defined('AI_API_BASE_URL') ? rtrim((string)AI_API_BASE_URL, '/') : 'https://ai.meatsokogroup.com/api/v1';
$agentId = defined('AI_AGENT') ? (string)AI_AGENT : 'nyama';

if (empty($apiKey)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'error' => 'Nyama AI service key is not configured on the server.',
        'code' => 'missing_server_key'
    ]);
    exit;
}

$payload = [
    'message' => $message,
    'stream'  => $stream
];
if (!empty($requestedConvId)) {
    $payload['conversation_id'] = $requestedConvId;
}

// Release session lock before external request to prevent UI freezing
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$targetUrl = "{$baseUrl}/agents/{$agentId}/runs/";
$jsonPayload = json_encode($payload);

// ─── NON-STREAMING RESPONSE ──────────────────────────────────────────────────
if (!$stream) {
    $headers = [
        "Authorization: Bearer {$apiKey}",
        "Content-Type: application/json",
        "Accept: application/json"
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($targetUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $jsonPayload,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) {
            http_response_code(502);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Gateway error: ' . $curlErr, 'code' => 'curl_error']);
            exit;
        }

        http_response_code($httpCode ?: 200);
        header('Content-Type: application/json');
        echo $response;
        exit;
    } else {
        $context = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => implode("\r\n", $headers) . "\r\n",
                'content'       => $jsonPayload,
                'timeout'       => 120,
                'ignore_errors' => true
            ],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]
        ]);
        $response = @file_get_contents($targetUrl, false, $context);
        header('Content-Type: application/json');
        echo $response ?: json_encode(['error' => 'Unable to contact AI API']);
        exit;
    }
}

// ─── STREAMED SSE RESPONSE ───────────────────────────────────────────────────
if (function_exists('apache_setenv')) {
    @apache_setenv('no-gzip', '1');
}
@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
@ini_set('implicit_flush', '1');

header('Content-Type: text/event-stream; charset=utf-8');
header('Cache-Control: no-cache, no-transform');
header('Connection: keep-alive');
header('X-Accel-Buffering: no');

while (ob_get_level() > 0) {
    ob_end_flush();
}
flush();

if (function_exists('curl_init')) {
    $ch = curl_init($targetUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $jsonPayload,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $apiKey,
            'Content-Type: application/json',
            'Accept: text/event-stream'
        ],
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_TCP_KEEPALIVE  => 1,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_WRITEFUNCTION  => function ($curl, $chunk): int {
            echo $chunk;
            if (ob_get_level() > 0) {
                ob_flush();
            }
            flush();
            return strlen($chunk);
        }
    ]);

    $success = curl_exec($ch);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if (!$success && $curlErr) {
        echo "event: run.failed\n";
        echo "data: " . json_encode([
            'type' => 'run.failed',
            'code' => 'gateway_error',
            'message' => 'Connection to AI server interrupted: ' . $curlErr
        ]) . "\n\n";
        flush();
    }
} else {
    $context = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Authorization: Bearer {$apiKey}\r\n" .
                               "Content-Type: application/json\r\n" .
                               "Accept: text/event-stream\r\n",
            'content'       => $jsonPayload,
            'timeout'       => 120,
            'ignore_errors' => true
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]
    ]);

    $fp = @fopen($targetUrl, 'rb', false, $context);
    if ($fp) {
        while (!feof($fp)) {
            $buffer = fread($fp, 2048);
            if ($buffer === false || $buffer === '') {
                if (feof($fp)) break;
                usleep(15000);
                continue;
            }
            echo $buffer;
            if (ob_get_level() > 0) {
                ob_flush();
            }
            flush();
        }
        fclose($fp);
    } else {
        echo "event: run.failed\n";
        echo "data: " . json_encode([
            'type' => 'run.failed',
            'code' => 'gateway_error',
            'message' => 'Could not establish connection to AI gateway.'
        ]) . "\n\n";
        flush();
    }
}
