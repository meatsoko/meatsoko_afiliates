<?php
require __DIR__.'/includes/functions.php';

$T = [
  'subscribe'   => 'Subscribe to Weekly Livestock Intelligence',
  'contribute'  => 'Pitch a Story / Editorial Contribution',
  'advertise'   => 'Advertise or Media Partnership',
  'publication' => 'Request Research Publication / Custom Report',
  'livestock'   => 'Livestock Pricing & Off-Take Inquiries',
  'other'       => 'General Agribusiness Inquiries'
];

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  if(!check_rate_limit('contact_submit', 5, 300)){
    $_SESSION['flash'] = 'Too many submissions. Please wait 5 minutes before trying again.';
    go('contact');
  }

  $tp = $_POST['topic'] ?? 'other';
  $n = trim($_POST['name'] ?? '');
  $m = trim($_POST['email'] ?? '');
  $p = trim($_POST['phone'] ?? '');
  $b = trim($_POST['msg'] ?? '');
  $o = trim($_POST['org'] ?? '');
  $lab = $T[$tp] ?? 'General Inquiry';
  
  $valid = ok() && ($_POST['website'] ?? '') === '' && filter_var($m, FILTER_VALIDATE_EMAIL) && ($tp === 'subscribe' || ($n && $b));
  
  if($valid){
    hit_rate_limit('contact_submit', 300);
    if($tp === 'subscribe'){
      $s = load('subscribers');
      if(!in_array($m, array_column($s, 'email'))){
        $s[] = ['date' => date('Y-m-d H:i'), 'email' => $m, 'phone' => $p];
        save('subscribers', $s);
      }
      @mail(SITE_EMAIL, "New MeatSoko Subscriber: $m", "Subscriber Email: $m\nPhone: $p\nDate: ".date('Y-m-d H:i'));
      $_SESSION['flash'] = 'You have successfully subscribed to the MeatSoko Weekly Intelligence briefing.';
    } else {
      $a = load('messages');
      $a[] = [
        'date'  => date('Y-m-d H:i'),
        'name'  => $n,
        'email' => $m,
        'phone' => $p,
        'org'   => $o,
        'topic' => $lab,
        'msg'   => $b
      ];
      save('messages', $a);
      @mail(SITE_EMAIL, "[$lab] $n", "From: $n ($o)\nEmail: $m\nPhone: $p\n\n$b", "Reply-To: $m");
      $_SESSION['flash'] = 'Thank you for reaching out. The MeatSoko Media desk has received your message and will respond promptly.';
    }
  } else {
    hit_rate_limit('contact_submit', 300);
    $_SESSION['flash'] = 'Please check that your name, a valid email, and your message are filled in properly.';
  }
  go('contact');
}

$sel = $_GET['topic'] ?? '';
$ref = $_GET['ref'] ?? '';
$pre = '';
foreach(load('publications') as $pub){
  if(($pub['slug'] ?? '') === $ref){
    $pre = 'Please provide access to: '.$pub['title'];
  }
}

$page = 'contact';
$pageTitle = 'Contact MeatSoko Media Group';
require 'includes/header.php';
?>

<section class="wrap page narrow">
  <b class="kind"><i class="fa-solid fa-headset"></i> Direct Desk</b>
  <h1>Get in Touch with MeatSoko Media</h1>
  <p class="lead">Connect with our editors, livestock market analysts, and advertising desk. For urgent inquiries or commercial off-take partnerships, reach us directly via phone or WhatsApp.</p>
  
  <?=flash()?>

  <!-- Contact channels card -->
  <div class="pill rv" style="margin:1.8rem 0;padding:1.6rem;border-top-width:5px">
    <h3><i class="fa-solid fa-address-book"></i> Direct Contact Channels</h3>
    <div class="grid three" style="margin-top:1rem;gap:1rem">
      <div style="background:var(--bg);padding:1rem;border-radius:14px;border:1px solid var(--ln)">
        <b style="color:var(--ac);display:block;margin-bottom:0.3rem"><i class="fa-solid fa-phone"></i> Telephone</b>
        <a href="tel:<?=e(SITE_PHONE)?>" style="font-weight:700;font-size:1.1rem;text-decoration:none;color:var(--red)"><?=e(SITE_PHONE)?></a>
        <div style="font-size:0.8rem;color:var(--mu);margin-top:0.2rem">Direct desk &middot; Mon&ndash;Fri 8am&ndash;6pm</div>
      </div>
      <div style="background:var(--bg);padding:1rem;border-radius:14px;border:1px solid var(--ln)">
        <b style="color:var(--ac);display:block;margin-bottom:0.3rem"><i class="fa-brands fa-whatsapp"></i> WhatsApp</b>
        <a href="<?=e(SITE_WHATSAPP)?>" target="_blank" rel="noopener" style="font-weight:700;font-size:1.1rem;text-decoration:none;color:var(--ac)">Chat on WhatsApp</a>
        <div style="font-size:0.8rem;color:var(--mu);margin-top:0.2rem">Instant chat &middot; 24/7 alerts</div>
      </div>
      <div style="background:var(--bg);padding:1rem;border-radius:14px;border:1px solid var(--ln)">
        <b style="color:var(--ac);display:block;margin-bottom:0.3rem"><i class="fa-solid fa-envelope"></i> Email Inquiries</b>
        <a href="mailto:<?=e(SITE_EMAIL)?>" style="font-weight:700;font-size:1rem;text-decoration:none;color:var(--red)"><?=e(SITE_EMAIL)?></a>
        <div style="font-size:0.8rem;color:var(--mu);margin-top:0.2rem">Replies within 24 working hours</div>
      </div>
    </div>
  </div>

  <form method="post" class="rv" style="margin-top:2rem">
    <?=csrf()?>
    <label>Full Name
      <input name="name" placeholder="Your full name" required>
    </label>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
      <label>Email Address
        <input type="email" name="email" placeholder="e.g. user@domain.com" required>
      </label>
      <label>Phone Number / WhatsApp
        <input type="tel" name="phone" placeholder="e.g. 0715097128">
      </label>
    </div>
    <label>Organisation / Ranch / Cooperative (Optional)
      <input name="org" placeholder="e.g. Boran Ranchers Association, Dagoretti Butchery Union">
    </label>
    <label>Topic of Inquiry
      <select name="topic">
        <?php foreach($T as $k=>$v): ?>
          <option value="<?=$k?>"<?=($sel===$k?' selected':'')?>><?=e($v)?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Your Message / Specifications
      <textarea name="msg" rows="5" placeholder="Share your inquiry, press release, or data request here..."><?=e($pre)?></textarea>
    </label>
    <input name="website" value="" style="display:none" tabindex="-1" autocomplete="off">
    <button class="btn" style="justify-self:start;padding:0.9rem 2rem">
      <i class="fa-solid fa-paper-plane"></i> Send Message
    </button>
  </form>
  
  <p style="margin-top:1.5rem"><small style="color:var(--mu)"><i class="fa-solid fa-lock"></i> Your privacy is strictly protected. Contact information is used solely by MeatSoko Media to reply to your inquiry.</small></p>
</section>

<?php require 'includes/footer.php'; ?>
