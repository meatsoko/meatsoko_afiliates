<?php
// Public read-only JSON API for MSL-MEDIA (no database, no key needed).
//   api.php                                  -> everything
//   api.php?section=articles                   -> one section (or several, comma separated)
//   api.php?section=articles&q=word&limit=5    -> search text + limit
//   api.php?section=articles&field=value       -> filter any field (contains, case-insensitive)
// Sections: site, about, ecosystem, pages, articles, publications, team
require __DIR__.'/includes/functions.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=60');
if(($_SERVER['REQUEST_METHOD']??'GET')==='OPTIONS'){header('Access-Control-Allow-Methods: GET');exit;}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){http_response_code(405);echo json_encode(['error'=>'GET only']);exit;}
function out($d,$c=200){http_response_code($c);echo json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
$base=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').rtrim(dirname($_SERVER['SCRIPT_NAME']),'/\\').'/';
$files=['articles','publications','team'];
$postpage=true;
function absu($b,$v){return (is_string($v)&&$v!==''&&!preg_match('#^(https?:|//|data:|mailto:|\#)#i',$v))?$b.ltrim($v,'/'):$v;}
function prep($rows,$b,$pp){return array_map(function($r)use($b,$pp){
 if(!is_array($r))return $r;
 foreach(['file','image','src'] as $k)if(isset($r[$k]))$r[$k]=absu($b,$r[$k]);
 if($pp&&isset($r['id']))$r['url']=$b.'post?id='.$r['id'];
 return $r;},$rows);}
function filt($rows){
 $skip=['section','q','limit','post'];
 foreach($_GET as $k=>$v){if(in_array($k,$skip,true)||!is_string($v)||$v==='')continue;
  $rows=array_filter($rows,fn($r)=>is_array($r)&&isset($r[$k])&&stripos(is_array($r[$k])?implode(' ',$r[$k]):(string)$r[$k],$v)!==false);}
 if(!empty($_GET['q']))$rows=array_filter($rows,fn($r)=>stripos(json_encode($r,JSON_UNESCAPED_UNICODE),$_GET['q'])!==false);
 $rows=array_values($rows);
 return isset($_GET['limit'])?array_slice($rows,0,max(1,(int)$_GET['limit'])):$rows;}

$sections=[
 'site'=>fn()=>['name'=>SITE_SHORT,'tagline'=>SITE_TAG,'email'=>SITE_EMAIL,'phone'=>defined('SITE_PHONE')?SITE_PHONE:null,'whatsapp'=>defined('SITE_WHATSAPP')?SITE_WHATSAPP:null,'url'=>$base,'ecosystem_role'=>defined('ECO_PILLAR')?ECO_PILLAR:null],
 'about'=>fn()=>['summary'=>str_replace('{SITE}',SITE_SHORT,'{SITE} is a livestock media group. We publish invaluable insights and analysis, and give our readers access to unfolding information in the industry.'),'points'=>[['title'=>'Mission','text'=>'Inform the people who raise, trade, process and regulate livestock with accurate, useful reporting.'],['title'=>'Independence','text'=>'Editorial decisions are made by editors, not advertisers.'],['title'=>'Accuracy','text'=>'We name sources, show data and correct mistakes openly.']]],
 'ecosystem'=>fn()=>load('ecosystem'),
 'pages'=>fn()=>array_map(fn($p)=>$base.($p==='index'?'':$p),['index','news','analysis','publications','about','contact']),
];
foreach($files as $f)$sections[$f]=fn()=>filt(prep(load($f),$base,$postpage&&in_array($f,['insights','articles'],true)));
if(isset($_GET['post'])&&$postpage){foreach(['insights','articles'] as $f)foreach(load($f) as $p)if(($p['id']??null)===$_GET['post'])out(prep([$p],$base,true)[0]);out(['error'=>'post not found'],404);}
$want=!empty($_GET['section'])?array_map('trim',explode(',',$_GET['section'])):array_keys($sections);
$res=['generated'=>date('c'),'sections'=>array_keys($sections)];
foreach($want as $s){if(!isset($sections[$s]))out(['error'=>"unknown section '$s'",'available'=>array_keys($sections)],400);$res[$s]=$sections[$s]();}
out($res);
