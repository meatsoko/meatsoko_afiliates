<?php
header('Location: energy/');
exit;
