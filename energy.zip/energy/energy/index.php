<?php require __DIR__.'/includes/functions.php';
$page='index';$pageTitle='Clean energy from animal waste';$ps=posts();$pr=load('prices');$prods=load('products');
$ar=count(array_unique(array_column($pr,'place')));
require 'includes/header.php';?>
<section class="hero" style="--img:url('<?=IMG['hero']?>')"><div class="hwrap"><p class="chip">Biogas &middot; Clean cooking &middot; Organic fertiliser</p>
<h1>Turn goat and sheep waste into <em>clean energy</em></h1>
<p class="lead"><?=e(SITE_NAME)?> (<?=SITE_SHORT?>) helps farms, schools and homes turn animal manure into cooking gas, electricity and free fertiliser, and cut firewood, charcoal and LPG bills.</p>
<a class="btn" href="<?=u('calculator')?>"><i class="fa-solid fa-calculator"></i> Size my biogas plant</a> <a class="btn alt" href="<?=u('biogas')?>"><i class="fa-solid fa-fire-flame-curved"></i> How biogas works</a>
<div class="hstats"><div><b>6 kWh</b><span>energy in 1 m&sup3; of biogas</span></div><div><b>0.46 kg</b><span>LPG replaced per m&sup3;</span></div><div><b>30&ndash;60</b><span>days in the digester</span></div></div></div>
<div class="ticker" aria-label="Biogas facts"><div class="track"><?php $facts=[['1 m³ biogas','≈ 6 kWh of energy'],['Methane','50–70% of biogas'],['1 m³ biogas','≈ 3.5 kg firewood'],['Digestion','30–60 days'],['Best temperature','30–40 °C'],['Bioslurry','free organic fertiliser']];for($k=0;$k<2;$k++)foreach($facts as $f)echo '<span><i>'.e($f[0]).'</i> '.e($f[1]).'</span>';?></div></div></section>

<section class="wrap"><div class="sechead rv"><span class="eyebrow">The process</span><h2>From manure to meals in five steps</h2><p>The same simple loop runs on a household digester in China, a farm in Kenya or a school in India.</p></div>
<div class="flow">
<div class="step rv"><i class="fa-solid fa-hand-holding-droplet"></i><h3>1. Collect</h3><p>Gather goat, sheep or cattle manure daily from the pen.</p><small>about 1 kg per goat a day</small></div>
<div class="step rv"><i class="fa-solid fa-blender"></i><h3>2. Mix</h3><p>Blend with an equal amount of water in the inlet tank.</p><small>6&ndash;10% solids</small></div>
<div class="step rv"><i class="fa-solid fa-circle-notch"></i><h3>3. Digest</h3><p>Bacteria break it down in the sealed digester, with no air.</p><small>30&ndash;40 &deg;C, 30&ndash;60 days</small></div>
<div class="step rv"><i class="fa-solid fa-fire-flame-curved"></i><h3>4. Use gas</h3><p>Pipe the gas, cleaned of water and H&#8322;S, to stoves, lamps or an engine.</p><small>50&ndash;70% methane</small></div>
<div class="step rv"><i class="fa-solid fa-seedling"></i><h3>5. Fertilise</h3><p>Spread the bioslurry on crops and fodder.</p><small>N, P and K retained</small></div></div></section>

<section class="wrap stats"><div class="rv"><i class="fa-solid fa-book-open"></i><b data-count="<?=count($ps)?>">0</b><span>guides and projects</span></div><div class="rv"><i class="fa-solid fa-coins"></i><b data-count="<?=count($pr)?>">0</b><span>cost and price records</span></div><div class="rv"><i class="fa-solid fa-location-dot"></i><b data-count="<?=$ar?>">0</b><span>areas tracked</span></div></section>

<section class="wrap split"><div class="photo rv"><img loading="lazy" alt="Tubular biogas digester beside a goat pen" src="<?=IMG['about']?>"><span>Tubular digester on a goat farm</span></div><div class="rv"><span class="eyebrow">Why biogas</span><h2>Waste is a resource</h2><p>Manure from goats, sheep, cattle, pigs and poultry gives off methane when it rots in the open, a gas that traps far more heat than carbon dioxide. Inside a sealed digester the same manure becomes biogas you can burn, plus a nutrient-rich slurry that feeds crops.</p><ul class="ticks"><li><i class="fa-solid fa-check"></i> Cooking gas with no smoke, soot or daily wood collection</li><li><i class="fa-solid fa-check"></i> Bioslurry fertiliser that improves soil and cuts input costs</li><li><i class="fa-solid fa-check"></i> Lower methane emissions, cleaner water and fewer flies and odours</li><li><i class="fa-solid fa-check"></i> Power for lights, pumps, chaff cutters and milk coolers</li></ul></div></section>

<section class="wrap"><div class="sechead rv"><span class="eyebrow">Digester designs</span><h2>The machines behind the gas</h2><p>Three proven designs, developed in China, India and across the developing world.</p></div>
<div class="mach">
<figure class="rv"><img loading="lazy" alt="Cutaway of a Chinese fixed-dome digester" src="<?=IMG['dome']?>"><figcaption><span class="origin">Origin: China</span><h3>Fixed dome</h3><p>A brick or concrete dome buried underground. Gas pushes slurry into the outlet chamber. Tens of millions have been built.</p><div class="chips"><span>20+ year life</span><span>Stable temperature</span><span>Needs skilled masons</span></div></figcaption></figure>
<figure class="rv"><img loading="lazy" alt="Cutaway of an Indian floating-drum digester" src="<?=IMG['drum']?>"><figcaption><span class="origin">Origin: India</span><h3>Floating drum</h3><p>A steel drum rises on the slurry as gas collects, so pressure stays constant and the gas level is easy to read.</p><div class="chips"><span>Constant pressure</span><span>Easy to operate</span><span>Drum needs painting</span></div></figcaption></figure>
<figure class="rv"><img loading="lazy" alt="Tubular bag digester on a farm" src="<?=IMG['about']?>"><figcaption><span class="origin">Low cost bag</span><h3>Tubular bag</h3><p>A long plastic bag in a trench. Fast to install and cheaper, good for small flocks and trials.</p><div class="chips"><span>Install in days</span><span>5&ndash;10 year life</span><span>Fence and shade it</span></div></figcaption></figure></div></section>

<section class="band" style="--img:url('<?=IMG['stove']?>')"><div class="wrap"><div class="sechead rv"><span class="eyebrow">Why it matters</span><h2>Cleaner homes, fewer trees cut, less methane</h2></div><div class="grid three">
<div class="pill rv"><h3><i class="fa-solid fa-lungs"></i> Healthier homes</h3><p>The WHO estimates household air pollution from dirty cooking fuels contributes to about 3 million premature deaths a year worldwide. Biogas burns cleanly.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-tree"></i> Fewer trees cut</h3><p>About 3.5 kg of firewood is replaced by every cubic metre of biogas, saving forests and hours of collection time.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-earth-africa"></i> Climate action</h3><p>Methane warms the climate roughly 28 times more than CO&#8322; over 100 years, so capturing and burning it cuts emissions.</p></div></div></div></section>

<section class="wrap"><div class="sechead rv"><span class="eyebrow">What we do</span><h2>Everything from design to training</h2></div><div class="grid three">
<div class="pill rv"><h3><i class="fa-solid fa-drafting-compass"></i> Design and sizing</h3><p>Digester sizing from your herd, feed and gas needs, using fixed-dome, floating-drum or tubular designs.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-screwdriver-wrench"></i> Installation and training</h3><p>Build supervision, commissioning, safe use and daily operation training for farm families and staff.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-seedling"></i> Bioslurry for crops</h3><p>Guidance on applying digested slurry to kitchen gardens, fodder, maize and vegetables.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-bolt"></i> Biogas power</h3><p>Biogas-fuelled lights, engines and generators for farms, schools and small enterprises.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-recycle"></i> Co-digestion</h3><p>Mixing manure with crop residue, kitchen waste and abattoir waste to lift gas yield.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-flask"></i> Research</h3><p>Open guides and field-tested innovations on yield, cold-climate operation and safety.</p></div></div></section>

<section class="wrap">
  <div class="sechead rv">
    <span class="eyebrow">Clean Energy & Bio-Products</span>
    <h2>Biogas Installations, LPG Gas & Organic Fertilisers</h2>
    <p>Turnkey farm biogas systems, clean cooking LPG gas supply, and certified high-potency organic solid and liquid fertilisers powered by MeatSoko Group.</p>
  </div>
  <div class="prod-grid">
    <?php foreach($prods as $p): ?>
      <div class="prod-card rv" data-cat="<?=e($p['category'])?>">
        <div class="prod-img-wrap">
          <img loading="lazy" src="<?=e($p['image'])?>" alt="<?=e($p['name'])?>">
          <?php if(!empty($p['badge'])): ?><span class="prod-badge"><?=e($p['badge'])?></span><?php endif; ?>
          <span class="prod-cat"><?=e($p['category'])?></span>
        </div>
        <div class="prod-body">
          <h3><?=e($p['name'])?></h3>
          <p><?=e($p['summary'])?></p>
          <?php if(!empty($p['features'])): ?>
            <ul class="prod-features">
              <?php foreach($p['features'] as $f): ?>
                <li><i class="fa-solid fa-check"></i> <?=e($f)?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
          <a class="prod-btn" href="<?=e($p['link'])?>" target="_blank" rel="noopener">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> <?=e($p['link_text']??'Order on MeatSoko')?>
          </a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div style="text-align:center;margin-top:2.2rem">
    <a class="btn" href="https://meatsokogroup.com" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> Visit MeatSoko Group for All Products & Orders</a>
  </div>
</section>

<section class="wrap"><div class="sechead rv"><span class="eyebrow">Knowledge</span><h2>Latest guides and projects</h2></div><div class="grid"><?php foreach(array_slice($ps,0,4) as $x)echo card($x);?></div></section>
<section class="cta img" style="--img:url('<?=IMG['power']?>')"><div class="wrap rv"><h2>Ready to power your farm with waste?</h2><a class="btn dark" href="<?=u('contact')?>"><i class="fa-solid fa-paper-plane"></i> Get a free consultation</a></div></section>
<?php require 'includes/footer.php';
