<?php require __DIR__.'/includes/functions.php';
$page='biogas';$pageTitle='How biogas works';require 'includes/header.php';?>
<section class="wrap page"><span class="eyebrow">Biogas guide</span><h1>How biogas works</h1><p class="lead">Biogas is a mix of gases made when bacteria break down organic matter without oxygen. This process is called anaerobic digestion, and it happens naturally in swamps and in the stomachs of animals.</p>
<h2 style="margin-top:2rem">What is in biogas?</h2>
<div class="scroll"><table><thead><tr><th>Gas</th><th>Share</th><th>Role</th></tr></thead><tbody>
<tr><td>Methane (CH&#8324;)</td><td>50&ndash;70%</td><td>The fuel. Pure methane holds about 36 MJ per m&sup3;</td></tr>
<tr><td>Carbon dioxide (CO&#8322;)</td><td>30&ndash;45%</td><td>Does not burn; lowers heating value</td></tr>
<tr><td>Hydrogen sulphide (H&#8322;S)</td><td>0.01&ndash;0.5%</td><td>Smells of rotten eggs, toxic and corrosive; remove with a scrubber</td></tr>
<tr><td>Water vapour, nitrogen, traces</td><td>Small</td><td>Removed with a water trap</td></tr></tbody></table></div>
<p>Typical biogas holds about 20&ndash;25 MJ per m&sup3; (roughly 6 kWh), enough to run a household stove for around 3 hours.</p>

<h2 style="margin-top:3rem">The four stages of digestion</h2>
<div class="grid three">
<div class="pill rv"><h3><span class="num">1</span> Hydrolysis</h3><p>Enzymes split complex solids (fibre, fats, proteins) into sugars, fatty acids and amino acids.</p></div>
<div class="pill rv"><h3><span class="num">2</span> Acidogenesis</h3><p>Bacteria ferment these into volatile fatty acids, alcohols, hydrogen and CO&#8322;.</p></div>
<div class="pill rv"><h3><span class="num">3</span> Acetogenesis</h3><p>Fatty acids are turned into acetic acid, hydrogen and CO&#8322;, the raw material for methane.</p></div>
<div class="pill rv"><h3><span class="num">4</span> Methanogenesis</h3><p>Methane-forming archaea convert acetic acid, or hydrogen and CO&#8322;, into methane. They are slow and sensitive, so they set the pace.</p></div></div>

<h2 style="margin-top:3rem">Feedstocks: what goes in</h2>
<div class="scroll"><table><thead><tr><th>Feedstock</th><th>Fresh manure per animal per day*</th><th>Biogas per kg fresh*</th><th>Notes</th></tr></thead><tbody>
<tr><td>Goat</td><td>about 1 kg</td><td>0.04&ndash;0.06 m&sup3;</td><td>Dry pellets: soak and mix well. Good carbon-to-nitrogen balance</td></tr>
<tr><td>Sheep</td><td>about 1&ndash;1.5 kg</td><td>0.04&ndash;0.06 m&sup3;</td><td>Similar to goats; collect from the night pen</td></tr>
<tr><td>Cattle (dung)</td><td>10&ndash;15 kg</td><td>0.03&ndash;0.04 m&sup3;</td><td>The standard household feedstock; very stable</td></tr>
<tr><td>Pig</td><td>about 2&ndash;4 kg</td><td>0.05&ndash;0.07 m&sup3;</td><td>High yield; wash-down water helps</td></tr>
<tr><td>Poultry</td><td>about 0.1&ndash;0.2 kg</td><td>0.06&ndash;0.09 m&sup3;</td><td>High nitrogen; dilute well or ammonia can inhibit bacteria</td></tr>
<tr><td>Kitchen and crop waste</td><td>varies</td><td>varies</td><td>Chop small; add gradually (co-digestion)</td></tr></tbody></table></div>
<p><small>*Indicative values from published literature. Real figures depend on diet, age, water content and design. Use the <a href="<?=u('calculator')?>">calculator</a> for a first estimate and have a certified technician confirm the size.</small></p>

<h2 style="margin-top:3rem">Digester designs from around the world</h2>
<div class="mach">
<figure class="rv"><img loading="lazy" alt="Cutaway of a Chinese fixed-dome digester" src="<?=IMG['dome']?>"><figcaption><span class="origin">Origin: China</span><h3>Fixed dome (Chinese dome)</h3><p>A brick or concrete dome buried underground, with an inlet tank, an outlet chamber and a gas pipe from the crown. As gas collects it pushes slurry up into the outlet chamber and creates pressure. Developed in China and rolled out to millions of households from the 1970s. Long life of 20 years or more, stable temperature, no moving parts, but needs skilled masons and gas leaks are hard to repair.</p><div class="chips"><span>6&ndash;10 m&sup3; typical</span><span>20+ year life</span><span>Variable pressure</span></div></figcaption></figure>
<figure class="rv"><img loading="lazy" alt="Cutaway of an Indian floating-drum digester" src="<?=IMG['drum']?>"><figcaption><span class="origin">Origin: India</span><h3>Floating drum (KVIC)</h3><p>A cylindrical well with a steel drum that floats on the slurry and rises as gas collects. Promoted in India from the 1950s by the Khadi and Village Industries Commission. Gas pressure stays constant and the amount of gas is easy to see, but the steel drum corrodes and needs regular painting.</p><div class="chips"><span>Constant pressure</span><span>Visible gas level</span><span>Higher cost</span></div></figcaption></figure>
<figure class="rv"><img loading="lazy" alt="Tubular bag digester with feeding tank" src="<?=IMG['about']?>"><figcaption><span class="origin">Low-cost bag</span><h3>Tubular bag digester</h3><p>A long polyethylene or PVC bag laid in a trench, popularised in Latin America, Asia and Africa. It is cheap and quick to install and suits small flocks and trials, but it is exposed to damage, UV and animals, so it needs a fence and shade, and lasts around 5 to 10 years.</p><div class="chips"><span>Install in days</span><span>Low cost</span><span>5&ndash;10 year life</span></div></figcaption></figure>
<figure class="rv"><img loading="lazy" alt="Biogas gas holder and generator on a farm" src="<?=IMG['power']?>"><figcaption><span class="origin">Farm and industrial</span><h3>Gas holder with engine</h3><p>Larger farm and community plants use steel or concrete tanks with a flexible gas holder and a combined heat and power engine, as in thousands of plants across Germany and Europe. They also add heating, mixing and gas cleaning, and can feed power to the grid.</p><div class="chips"><span>Electricity and heat</span><span>Mixers and heating</span><span>Gas cleaning</span></div></figcaption></figure></div>

<h2 style="margin-top:3rem">How a plant is built</h2>
<div class="split"><div class="photo rv"><img loading="lazy" alt="Masons and engineers building a brick digester" src="<?=IMG['install']?>"><span>Building a brick digester in a village</span></div><div class="rv"><ol class="ticks" style="list-style:decimal"><li><b>Site and sizing:</b> pick ground near the animal pen and kitchen, at least 10 m from wells, and size from daily manure and gas needs.</li><li><b>Excavation and base:</b> dig the pit and cast a concrete foundation.</li><li><b>Walls and dome:</b> build the brick or concrete digester, inlet and outlet.</li><li><b>Plaster and gas-tightness test:</b> seal the dome and test it with water or air pressure.</li><li><b>Pipes and fittings:</b> fit the gas pipe, water trap, valves, pressure gauge and stove.</li><li><b>Start-up:</b> load with fresh dung and water and wait for the first usable gas.</li></ol></div></div>

<h2 style="margin-top:3rem">A short history</h2>
<div class="timeline"><div class="rv"><b>1895</b><p>Exeter, England: street lamps are lit with biogas collected from sewage.</p></div><div class="rv"><b>1950s</b><p>India develops the floating-drum household digester.</p></div><div class="rv"><b>1970s</b><p>China spreads the fixed-dome household digester to rural areas on a massive scale.</p></div><div class="rv"><b>1990s&ndash;today</b><p>Nepal, Vietnam, Kenya, Tanzania, Ethiopia and many other countries run national domestic biogas programmes, while Europe builds large farm and food-waste plants.</p></div></div>
<h2 style="margin-top:3rem">Keeping the digester healthy</h2>
<ul class="ticks"><li><i class="fa-solid fa-temperature-half"></i> <b>Temperature:</b> mesophilic bacteria work best at 30&ndash;40 &deg;C. Below 15 &deg;C gas falls sharply. In cold highlands bury, insulate or cover the digester.</li>
<li><i class="fa-solid fa-droplet"></i> <b>pH:</b> keep it between 6.8 and 7.5. Overfeeding makes it acidic.</li>
<li><i class="fa-solid fa-scale-balanced"></i> <b>Dilution:</b> mix manure with about an equal amount of water, giving 6&ndash;10% solids.</li>
<li><i class="fa-solid fa-clock"></i> <b>Retention time:</b> slurry stays 30&ndash;60 days, longer in cool weather.</li>
<li><i class="fa-solid fa-ban"></i> <b>Avoid:</b> disinfectant, detergent, antibiotics, dewormer-heavy manure right after treatment, sawdust, wood ash and large amounts of citrus peel.</li>
<li><i class="fa-solid fa-utensils"></i> <b>Feed daily</b> at roughly the same time and amount.</li></ul>

<h2 style="margin-top:3rem">Safety first</h2>
<div class="grid three">
<div class="pill rv"><h3><i class="fa-solid fa-fire"></i> Fire and explosion</h3><p>Methane is explosive when it makes up about 5&ndash;15% of the air. Keep gas lines sealed and check joints with soapy water, never a flame.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-skull-crossbones"></i> Toxic gas</h3><p>H&#8322;S is poisonous. Never enter an empty digester or slurry pit without ventilation, a second person and proper equipment.</p></div>
<div class="pill rv"><h3><i class="fa-solid fa-wind"></i> Ventilation</h3><p>Keep stoves in ventilated kitchens, shut the main valve at night, and install a water trap and a safety valve.</p></div></div>

<h2 style="margin-top:3rem">Frequently asked questions</h2>
<details class="faq rv"><summary>How long before I get gas?</summary><p>Usually 2&ndash;4 weeks after first loading. Starting with fresh cattle dung or slurry from another digester speeds this up. The first gas is mostly CO&#8322; and air, so do not burn it.</p></details>
<details class="faq rv"><summary>How many goats or sheep do I need to cook?</summary><p>A family of five cooking all meals needs roughly 1.5&ndash;2 m&sup3; of biogas daily. At about 1 kg of manure per goat and around 0.05 m&sup3; per kg, that is far more than a small flock gives, so goat and sheep manure is usually combined with cattle dung, kitchen waste or crop residues. Collecting manure from a zero-grazing or night pen helps.</p></details>
<details class="faq rv"><summary>Is the slurry safe on crops?</summary><p>Yes. Digestion reduces odour, many pathogens and weed seed viability, and keeps the nitrogen, phosphorus and potassium. Apply it diluted, avoid fresh slurry on leaves of vegetables eaten raw, and wash produce.</p></details>
<details class="faq rv"><summary>Can biogas replace LPG completely?</summary><p>For cooking, often yes if the digester is the right size. One cubic metre of biogas replaces about 0.46 kg of LPG, and a 13 kg cylinder is equal to roughly 28 m&sup3; of biogas.</p></details>
<details class="faq rv"><summary>Can I make electricity?</summary><p>Yes. Engines and generators designed or converted for biogas make roughly 1.5&ndash;2 kWh of electricity per cubic metre, depending on engine efficiency. Gas must be dried and the H&#8322;S removed to protect the engine.</p></details>
<details class="faq rv"><summary>What if my digester stops producing?</summary><p>Check for leaks, cold weather, a blocked inlet, overfeeding or harmful chemicals. Stop feeding for a few days, stir gently, and restart with smaller amounts. Contact us if it persists.</p></details>
</section>
<section class="cta"><div class="wrap rv"><h2>Find out how big your digester should be</h2><a class="btn dark" href="<?=u('calculator')?>"><i class="fa-solid fa-calculator"></i> Open calculator</a></div></section>
<?php require 'includes/footer.php';
