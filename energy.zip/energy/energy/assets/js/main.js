(function(){
var d=document,r=d.documentElement;
function theme(){var t=r.dataset.theme==='dark'?'light':'dark';r.dataset.theme=t;try{localStorage.theme=t}catch(e){}}
d.querySelectorAll('.theme-btn').forEach(function(b){b.onclick=theme});
var side=d.getElementById('side'),veil=d.getElementById('veil'),mb=d.getElementById('menuBtn');
function menu(o){d.body.classList.toggle('open',o);mb.setAttribute('aria-expanded',o);if(o)side.querySelector('a').focus()}
mb.onclick=function(){menu(true)};d.getElementById('closeBtn').onclick=function(){menu(false)};veil.onclick=function(){menu(false)};
d.addEventListener('keydown',function(e){if(e.key==='Escape')menu(false)});
side.querySelectorAll('a').forEach(function(a){a.onclick=function(){menu(false)}});
var top=d.getElementById('top');function sc(){top.classList.toggle('scrolled',scrollY>20)}sc();addEventListener('scroll',sc,{passive:true});
var q=d.getElementById('q');if(q)q.oninput=function(){var v=q.value.toLowerCase();d.querySelectorAll('#t tbody tr').forEach(function(x){x.hidden=!x.textContent.toLowerCase().includes(v)})};
var qs=d.getElementById('qs');if(qs)qs.oninput=function(){var v=qs.value.toLowerCase();d.querySelectorAll('#cards .card').forEach(function(c){c.hidden=!c.dataset.s.includes(v)})};
var lb=d.getElementById('lb');if(lb)d.querySelectorAll('.gal img').forEach(function(i){i.onclick=function(){lb.querySelector('img').src=i.src;lb.querySelector('p').textContent=i.alt;lb.showModal()}});
if(lb)lb.onclick=function(e){if(e.target===lb)lb.close()};
var still=matchMedia('(prefers-reduced-motion:reduce)').matches;
function count(el){var n=+el.dataset.count,s=performance.now();if(still){el.textContent=n;return}
(function f(t){var p=Math.min((t-s)/1200,1);el.textContent=Math.round(n*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)})(s)}
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');var c=e.target.querySelector('[data-count]');if(c)count(c);io.unobserve(e.target)}})},{threshold:.15});
d.querySelectorAll('.rv').forEach(function(el,i){el.style.transitionDelay=(i%4)*80+'ms';io.observe(el)});
var cf=d.getElementById('calc');if(cf){var K={goat:[1,.05],sheep:[1.2,.05],cattle:[10,.036],pig:[3,.06],poultry:[.15,.08]};
function fmt(n,p){return n.toLocaleString(undefined,{maximumFractionDigits:p})}
function calc(){var kg=0,gas=0,sh=(+d.getElementById('share').value||0)/100,hrt=+d.getElementById('hrt').value;
cf.querySelectorAll('[data-k]').forEach(function(i){var k=K[i.dataset.k],n=Math.max(+i.value||0,0);kg+=n*k[0]*sh;gas+=n*k[0]*sh*k[1]});
var slurry=kg*2,vol=slurry/1000*hrt*1.2;
function s(id,v,p){d.getElementById(id).textContent=fmt(v,p)}
s('r-kg',kg,1);s('r-gas',gas,2);s('r-stove',gas/.35,1);s('r-kwh',gas*6,1);s('r-lpg',gas*.46*30,1);s('r-wood',gas*3.5,1);s('r-vol',vol,1);s('r-slurry',slurry,0)}
cf.addEventListener('input',calc);calc()}

// Product filtering & search
var qp=d.getElementById('qp');
var filterBtns=d.querySelectorAll('.filter-btn');
function filterProducts(){
  var term=qp?qp.value.toLowerCase().trim():'';
  var activeBtn=d.querySelector('.filter-btn.active');
  var cat=activeBtn?activeBtn.dataset.cat:'all';
  d.querySelectorAll('.prod-card').forEach(function(card){
    var matchSearch=!term||(card.dataset.s||'').toLowerCase().includes(term);
    var matchCat=(cat==='all')||(card.dataset.cat===cat);
    card.hidden=!(matchSearch&&matchCat);
  });
}
if(qp)qp.addEventListener('input',filterProducts);
filterBtns.forEach(function(btn){
  btn.addEventListener('click',function(){
    filterBtns.forEach(function(b){b.classList.remove('active')});
    btn.classList.add('active');
    filterProducts();
  });
});

// Dynamic products rendering for static / zero-server HTML
var staticContainer=d.getElementById('static-prod-grid');
if(staticContainer){
  function renderProducts(items){
    if(!items||!items.length)return;
    staticContainer.innerHTML=items.map(function(p){
      var feats=(p.features||[]).map(function(f){
        return '<li><i class="fa-solid fa-check"></i> '+f+'</li>';
      }).join('');
      return '<div class="prod-card rv in" data-cat="'+p.category+'" data-s="'+(p.name+' '+p.summary+' '+p.category).toLowerCase()+'">'+
        '<div class="prod-img-wrap">'+
          '<img loading="lazy" src="'+p.image+'" alt="'+p.name+'">'+
          (p.badge?'<span class="prod-badge">'+p.badge+'</span>':'')+
          '<span class="prod-cat">'+p.category+'</span>'+
        '</div>'+
        '<div class="prod-body">'+
          '<h3>'+p.name+'</h3>'+
          '<p>'+p.summary+'</p>'+
          '<ul class="prod-features">'+feats+'</ul>'+
          '<a class="prod-btn" href="'+(p.link||'https://meatsokogroup.com')+'" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> '+(p.link_text||'Order on MeatSoko')+'</a>'+
        '</div>'+
      '</div>';
    }).join('');
  }
  if(window.GEBS_PRODUCTS){
    renderProducts(window.GEBS_PRODUCTS);
  }else{
    fetch('data/products.json').then(function(r){return r.json()}).then(renderProducts).catch(function(){});
  }
}
})();
