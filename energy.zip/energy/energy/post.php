<?php require __DIR__.'/includes/functions.php';
$post=null;foreach(posts() as $x)if($x['id']===($_GET['id']??''))$post=$x;
$page=$post['type']??'research';
if(!$post){http_response_code(404);$pageTitle='Not found';require 'includes/header.php';echo '<section class="wrap page"><h1>Page not found</h1><a href="'.u('biogas').'">Learn about biogas</a></section>';require 'includes/footer.php';exit;}
$pageTitle=$post['title'];require 'includes/header.php';?>
<article class="wrap page narrow"><img class="banner" src="<?=e(cover($post))?>" alt=""><b class="kind"><?=TYPES[$post['type']]?></b><h1><?=e($post['title'])?></h1><time><?=e($post['date'])?></time><p class="lead"><?=e($post['summary'])?></p>
<?php foreach(preg_split('/\n\s*\n/',$post['body']) as $p)echo '<p>'.nl2br(e($p)).'</p>';?></article>
<?php require 'includes/footer.php';
