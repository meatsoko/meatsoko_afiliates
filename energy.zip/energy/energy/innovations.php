<?php require __DIR__.'/includes/functions.php';
listing('innovations','Innovations','Designs, tools and business models we test with farmers and communities to make biogas affordable and reliable.');
