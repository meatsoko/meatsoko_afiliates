GEBS - GreenEnergy Biogas Solutions (PHP 7.4+, no database)
Biogas from goat, sheep, cattle, pig and poultry waste for clean cooking, power and fertiliser.

1. Upload everything to public_html.  2. Edit config.php (password, email, phone).
3. Make data/ and uploads/ writable (755/775).  4. Staff login: yoursite/admin.php

Pages: Home, Biogas (how it works), Calculator, Research, Innovations, Gallery, Costs, About, Contact.
Images are local files in assets/img (AI-generated illustrations and photos). Replace them with your own project photos of the same name, or upload new ones from the admin dashboard.
Costs and prices in data/prices.json are INDICATIVE estimates - update them from the admin dashboard with real quotes.
Calculator factors are typical literature values; actual yields vary with diet, dilution, temperature and design.
