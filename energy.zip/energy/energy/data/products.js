window.GEBS_PRODUCTS = [
  {
    "id": "prod-1",
    "name": "Turnkey Biogas Plant Installation",
    "category": "Biogas Installations",
    "badge": "Turnkey Installation",
    "summary": "Complete on-site biogas plant design, excavation, construction, and commissioning for dairy, sheep, goat, and poultry farms, schools, and homes. Custom-tailored tubular, fixed-dome, or floating-drum digesters converting animal manure into continuous clean cooking gas and rich bioslurry fertiliser.",
    "features": [
      "Custom engineering based on herd count & household energy demand",
      "Robust fixed-dome masonry, tubular polymer, or floating-drum options",
      "Full piping, inline desulfurizer scrubber, and pressure valve system",
      "Comprehensive operator training and aftercare maintenance support",
      "Eliminates monthly firewood, charcoal, and cooking gas expenses"
    ],
    "link": "https://meatsokogroup.com",
    "link_text": "Order on MeatSoko",
    "image": "assets/img/tubular.jpg"
  },
  {
    "id": "prod-2",
    "name": "LPG Cooking Gas Supply & Cylinders",
    "category": "LPG Gas",
    "badge": "Clean Fuel",
    "summary": "Clean, dependable Liquefied Petroleum Gas (LPG) cylinders, refills, and safety regulators for domestic kitchens, restaurants, and agribusinesses. Perfect as an immediate clean cooking solution or as an integrated hybrid energy backup paired with your farm biogas digester.",
    "features": [
      "Standard 6kg, 13kg, and commercial 50kg cylinder refills",
      "Certified safety-inspected cylinders and leak-tested fittings",
      "Fast doorstep, homestead, and farm-site delivery",
      "Seamless hybrid biogas-LPG dual cooking integration available",
      "Heavy-duty brass regulators, safety valves, and high-pressure hoses"
    ],
    "link": "https://meatsokogroup.com",
    "link_text": "Order on MeatSoko",
    "image": "assets/img/stove.jpg"
  },
  {
    "id": "prod-3",
    "name": "Enriched Bio-Slurry Organic Fertiliser",
    "category": "Organic Fertiliser",
    "badge": "100% Organic",
    "summary": "Premium fully-digested organic bio-slurry solid fertiliser rich in bioavailable nitrogen, phosphorus, potassium, and humic matter. 100% pathogen-free, weed-seed-free, and odorless compost that regenerates depleted farm soils, builds moisture retention, and boosts crop yields.",
    "features": [
      "Anaerobically matured, completely odorless & pathogen-free",
      "Rich in active slow-release N-P-K macro & micro soil nutrients",
      "Significantly boosts soil humus, aeration, and moisture retention",
      "Available in retail and commercial bulk sacks for farms and agrovets",
      "Ideal for maize, vegetables, avocado, coffee, and pasture grasses"
    ],
    "link": "https://meatsokogroup.com",
    "link_text": "Order on MeatSoko",
    "image": "assets/img/slurry.jpg"
  },
  {
    "id": "prod-4",
    "name": "Concentrated Liquid Bio-Fertiliser (Foliar Spray)",
    "category": "Liquid Fertiliser",
    "badge": "High Yield Foliar",
    "summary": "Micro-filtered, nutrient-dense liquid bio-fertiliser formulated for drip irrigation systems and knapsack foliar spraying. Delivers rapid plant uptake of amino acids, minerals, and beneficial microbes to stimulate vigorous vegetative growth, fruit set, and natural resistance against pests.",
    "features": [
      "Ultra-fine filtration ensuring zero clogging in sprayers and drip emitters",
      "Rapid foliar cuticle absorption for swift greening and root vigor",
      "Rich in natural phytohormones, humic acids, and beneficial soil biology",
      "Certified organic and eco-friendly with zero toxic chemical runoff",
      "Available in convenient 5-litre, 20-litre, and 200-litre containers"
    ],
    "link": "https://meatsokogroup.com",
    "link_text": "Order on MeatSoko",
    "image": "assets/img/hero.jpg"
  },
  {
    "id": "prod-5",
    "name": "High-Efficiency Biogas Stoves & Burners",
    "category": "Biogas Appliances",
    "badge": "Zero Soot",
    "summary": "Commercial and household stainless steel biogas stoves specially engineered for low-pressure methane combustion. Features enlarged gas nozzles and precision air mixing rings that produce an intense, soot-free blue cooking flame with superior thermal efficiency.",
    "features": [
      "Single and twin-burner heavy-gauge stainless steel construction",
      "Calibrated low-pressure methane injectors for maximum fuel efficiency",
      "Clean, smokeless blue flame protecting cookware and kitchen air",
      "Instant push-button piezo spark ignition and durable brass valve taps",
      "Directly compatible with fixed-dome, floating-drum, and tubular digesters"
    ],
    "link": "https://meatsokogroup.com",
    "link_text": "Order on MeatSoko",
    "image": "assets/img/stove.jpg"
  },
  {
    "id": "prod-6",
    "name": "Biogas H₂S Scrubbers & Gas Purification Kits",
    "category": "Biogas Hardware",
    "badge": "Equipment Protection",
    "summary": "Heavy-duty steel-wool and iron-sponge desulfurizer canisters and inline moisture condensation traps. Effectively scrubs corrosive hydrogen sulfide (H₂S) gas from raw biogas to safeguard stoves, heaters, and generator engines from pitting and acidic wear.",
    "features": [
      "Eliminates over 95% of corrosive H₂S acid gases and rotten-egg odors",
      "Prolongs the lifespan of gas stoves, piping, and generator engine valves",
      "Includes transparent moisture trap with easy drain petcock valve",
      "Rechargeable and replaceable filter media with clear service indicators",
      "Standard universal fitting for standard 1/2-inch and 3/4-inch gas piping"
    ],
    "link": "https://meatsokogroup.com",
    "link_text": "Order on MeatSoko",
    "image": "assets/img/install.jpg"
  }
];
