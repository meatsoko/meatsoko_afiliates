<?php require __DIR__.'/includes/functions.php';
$page='gallery';$pageTitle='Gallery';$g=load('gallery');require 'includes/header.php';?>
<section class="wrap page"><h1>Gallery</h1><p class="lead">Farms, digesters and clean kitchens in the field.</p>
<div class="gal"><?php foreach($g as $x)echo '<figure class="rv"><img loading="lazy" src="'.e($x['src']).'" alt="'.e($x['caption']).'"><figcaption>'.e($x['caption']).'</figcaption></figure>';if(!$g)echo '<p>No photos yet.</p>';?></div></section>
<dialog id="lb"><img alt=""><p></p><button class="btn" onclick="lb.close()">Close</button></dialog>
<?php require 'includes/footer.php';
