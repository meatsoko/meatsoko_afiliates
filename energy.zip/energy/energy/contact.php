<?php require __DIR__.'/includes/functions.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $n=trim($_POST['name']??'');$m=trim($_POST['email']??'');$b=trim($_POST['msg']??'');
 if(ok()&&($_POST['website']??'')===''&&$n&&filter_var($m,FILTER_VALIDATE_EMAIL)&&$b){
  $a=load('messages');$a[]=['date'=>date('Y-m-d H:i'),'name'=>$n,'email'=>$m,'msg'=>$b];save('messages',$a);
  @mail(SITE_EMAIL,"New message from $n",$b,"Reply-To: $m");$_SESSION['flash']='Thanks. We have your message and will reply within two working days.';
 }else $_SESSION['flash']='Please enter your name, a valid email and a message.';
 go('contact.php');}
$page='contact';$pageTitle='Contact';require 'includes/header.php';?>
<section class="wrap page narrow"><h1>Get a biogas consultation</h1><p class="lead">Farmers, schools, institutions and partners: tell us about your animals and energy needs and we will advise on the right biogas system.</p><?=flash()?>
<form method="post"><?=csrf()?><label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label><label>Number and type of animals (optional)<input name="animals"></label><label>Message<textarea name="msg" rows="6" required></textarea></label><input name="website" value="" style="display:none" tabindex="-1" autocomplete="off"><button class="btn"><i class="fa-solid fa-paper-plane"></i> Send message</button></form></section>
<?php require 'includes/footer.php';
