<?php
require_once __DIR__.'/../config.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
const IMG=[
  'hero'=>'assets/img/hero.jpg','about'=>'assets/img/tubular.jpg','research'=>'assets/img/fixed-dome.jpg','innovations'=>'assets/img/power.jpg',
  'stove'=>'assets/img/stove.jpg','slurry'=>'assets/img/slurry.jpg','install'=>'assets/img/install.jpg','dome'=>'assets/img/fixed-dome.jpg','drum'=>'assets/img/floating-drum.jpg','power'=>'assets/img/power.jpg'];
function cover($x){if(empty($x['image']))return IMG[$x['type']];return strpos($x['image'],'assets/')===0?$x['image']:'uploads/'.$x['image'];}
const TYPES=['research'=>'Research','innovations'=>'Innovation'];
function u($f){if($f==='index')return CLEAN_URLS?'./':'index.php';return CLEAN_URLS?$f:$f.'.php';}
function up($k){if(empty($_FILES[$k]['tmp_name'])||$_FILES[$k]['error']!==0||$_FILES[$k]['size']>5242880)return '';
$x=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][(new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$k]['tmp_name'])]??'';if(!$x)return '';
$d=__DIR__.'/../uploads';$n=bin2hex(random_bytes(8)).".$x";return move_uploaded_file($_FILES[$k]['tmp_name'],"$d/$n")?$n:'';}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function load($n){$f=__DIR__."/../data/$n.json";return is_file($f)?(json_decode(file_get_contents($f),true)?:[]):[];}
function save($n,$d){file_put_contents(__DIR__."/../data/$n.json",json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);}
function csrf(){if(empty($_SESSION['t']))$_SESSION['t']=bin2hex(random_bytes(16));return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">';}
function ok(){return isset($_POST['t'],$_SESSION['t'])&&hash_equals($_SESSION['t'],$_POST['t']);}
function admin(){return !empty($_SESSION['admin']);}
function go($f){header('Location: '.u($f));exit;}
function flash(){$m=$_SESSION['flash']??'';unset($_SESSION['flash']);return $m?'<p class="flash" role="status">'.e($m).'</p>':'';}
function posts(){$p=load('posts');usort($p,fn($a,$b)=>strcmp($b['date'],$a['date']));return $p;}
function card($x){return '<a class="card rv" data-s="'.e(strtolower($x['title'].' '.$x['summary'])).'" href="'.u('post').'?id='.e($x['id']).'"><img loading="lazy" alt="" src="'.e(cover($x)).'"><div><b>'.TYPES[$x['type']].'</b><h3>'.e($x['title']).'</h3><p>'.e($x['summary']).'</p><time><i class="fa-regular fa-calendar"></i> '.e($x['date']).'</time></div></a>';}
function listing($type,$title,$lead){
  global $page;$page=$type;$pageTitle=$title;require __DIR__.'/header.php';
  echo '<section class="wrap page"><h1>'.e($title).'</h1><p class="lead">'.e($lead).'</p><input id="qs" type="search" placeholder="Search '.e(strtolower($title)).'" aria-label="Search"><div class="grid" id="cards">';
  $l=array_filter(posts(),fn($x)=>$x['type']===$type);foreach($l as $x)echo card($x);
  if(!$l)echo '<p>Nothing published yet.</p>';echo '</div></section>';require __DIR__.'/footer.php';}
