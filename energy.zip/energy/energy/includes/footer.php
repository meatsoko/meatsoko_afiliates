</main>
<footer class="foot"><div class="fwrap"><div><b><?=e(SITE_NAME)?> (<?=SITE_SHORT?>)</b><p>Turning animal waste into clean energy.</p></div>
<nav aria-label="Footer"><?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'">'.$n[0].'</a>';?><a href="<?=u('admin')?>">Staff</a></nav>
<div class="fr"><a href="mailto:<?=SITE_EMAIL?>"><i class="fa-solid fa-envelope"></i> <?=SITE_EMAIL?></a><a href="tel:<?=e(preg_replace('/\s+/','',SITE_PHONE))?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a><small>&copy; <?=date('Y')?> <?=SITE_SHORT?>. All rights reserved.</small></div></div></footer>
<nav class="bnav" aria-label="Mobile"><?php foreach($BOT as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?></nav></body></html>
