<?php
require_once __DIR__.'/functions.php';
$page=$page??'';$pageTitle=$pageTitle??'Biogas from animal waste';
$NAV=['index'=>['Home','house'],'biogas'=>['Biogas','fire-flame-curved'],'calculator'=>['Calculator','calculator'],'research'=>['Research','flask'],'innovations'=>['Innovations','lightbulb'],'gallery'=>['Gallery','images'],'prices'=>['Costs','coins'],'about'=>['About','circle-info'],'contact'=>['Contact','envelope']];
$TOP=array_diff_key($NAV,['gallery'=>1]);
$BOT=array_intersect_key($NAV,array_flip(['index','biogas','calculator','prices','contact']));
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($pageTitle)?> | <?=SITE_SHORT?></title>
<meta name="description" content="<?=e(SITE_NAME)?> (<?=SITE_SHORT?>): clean biogas energy from goat, sheep, cattle, pig and poultry waste. Cooking gas, electricity and organic fertiliser for farms and homes.">
<meta name="theme-color" content="#15803d">
<script>try{document.documentElement.dataset.theme=localStorage.theme||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light')}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;800&family=IBM+Plex+Sans:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer"><link rel="stylesheet" href="assets/css/style.css"><script src="assets/js/main.js" defer></script></head><body>
<header class="top" id="top"><a class="logo" href="<?=u('index')?>"><span class="tagmark"></span><span><?=SITE_SHORT?><small>GreenEnergy Biogas Solutions</small></span></a>
<nav class="dnav" aria-label="Main"><?php foreach($TOP as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'>'.$n[0].'</a>';?></nav>
<div class="acts"><button class="ic theme-btn" aria-label="Toggle light or dark theme"><i class="fa-solid fa-moon t-moon"></i><i class="fa-solid fa-sun t-sun"></i></button>
<button class="ic menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="side"><i class="fa-solid fa-bars"></i></button></div></header>
<div class="veil" id="veil"></div>
<aside class="side" id="side" aria-label="Menu"><div class="sidehead"><b><?=SITE_SHORT?></b><button class="ic" id="closeBtn" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button></div>
<?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?>
<button class="theme-btn wide"><i class="fa-solid fa-circle-half-stroke"></i> Switch light / dark</button><p class="sidenote"><?=SITE_EMAIL?></p></aside><main>
