<?php
// === EDIT BEFORE GOING LIVE ===
const SITE_NAME  = 'GreenEnergy Biogas Solutions';
const SITE_SHORT = 'GEBS';
const SITE_EMAIL = 'info@meatsokogroup.com';
const SITE_PHONE = '0715097128';
const SITE_PLACE = 'Kenya';
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'ChangeMe#2026';   // change immediately
const CLEAN_URLS = true;   // set false if your host has no mod_rewrite
