<?php require __DIR__.'/includes/functions.php';
$page='calculator';$pageTitle='Biogas calculator';require 'includes/header.php';?>
<section class="wrap page"><h1>Biogas calculator</h1><p class="lead">Enter your animals and see how much gas, cooking time, energy and fertiliser you could get, and how big a digester you need.</p>
<div class="two"><form id="calc" onsubmit="return false"><h2>Your animals</h2>
<label>Goats<input type="number" min="0" value="20" data-k="goat"></label>
<label>Sheep<input type="number" min="0" value="20" data-k="sheep"></label>
<label>Cattle<input type="number" min="0" value="2" data-k="cattle"></label>
<label>Pigs<input type="number" min="0" value="0" data-k="pig"></label>
<label>Poultry<input type="number" min="0" value="0" data-k="poultry"></label>
<label>Share of manure you can collect (%)<input type="number" min="10" max="100" value="60" id="share"></label>
<label>Retention time (days)<select id="hrt"><option value="40">40 (warm, 25&ndash;35 &deg;C)</option><option value="50">50 (mild)</option><option value="60">60 (cool highlands)</option></select></label></form>
<div><h2>Your estimate</h2><div class="res" aria-live="polite">
<div><b id="r-kg">0</b><span>kg manure per day</span></div><div><b id="r-gas">0</b><span>m&sup3; biogas per day</span></div>
<div><b id="r-stove">0</b><span>hours of cooking per day</span></div><div><b id="r-kwh">0</b><span>kWh of energy per day</span></div>
<div><b id="r-lpg">0</b><span>kg LPG replaced per month</span></div><div><b id="r-wood">0</b><span>kg firewood saved per day</span></div>
<div><b id="r-vol">0</b><span>m&sup3; digester size</span></div><div><b id="r-slurry">0</b><span>litres bioslurry per day</span></div></div>
<p><small>Assumptions: fresh manure per day (goat 1, sheep 1.2, cattle 10, pig 3, poultry 0.15 kg); yield per kg (0.05, 0.05, 0.036, 0.06, 0.08 m&sup3;); manure mixed 1:1 with water; digester volume is feed times retention time plus 20% gas space; 0.35 m&sup3;/h per burner; 1 m&sup3; = 6 kWh = 0.46 kg LPG = 3.5 kg firewood. These are typical literature values; get a professional design before building.</small></p></div></div></section>
<section class="cta"><div class="wrap rv"><h2>Want an accurate design?</h2><a class="btn dark" href="<?=u('contact')?>"><i class="fa-solid fa-paper-plane"></i> Request a site visit</a></div></section>
<?php require 'includes/footer.php';
