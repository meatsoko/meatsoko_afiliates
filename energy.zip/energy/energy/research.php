<?php require __DIR__.'/includes/functions.php';
listing('research','Research','Guides and open research on biogas yield, digester operation, safety and bioslurry.');
