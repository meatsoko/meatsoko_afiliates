<?php
require_once __DIR__ . '/includes/functions.php';

$page = 'services';
$pageTitle = 'Branding & Design Services';
$sv = load('services');

require 'includes/header.php';
?>

<section class="wrap page">
    <div class="page-intro">
        <p class="section-tag">Specialist Disciplines</p>
        <h1>Our Specialist Disciplines</h1>
        <p class="lead">
            Strategic branding, structural packaging architectures, cattle & goat breed identification systems, and summit liveries tailored exclusively to meat producers, pastoralists, and commercial livestock enterprises.
        </p>
    </div>

    <!-- Quick Direct Contact Strip -->
    <div class="contact-channels rv" style="margin-bottom: 3rem;">
        <a href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>" class="contact-channel-card">
            <div class="channel-icon red">
                <i class="fa fa-phone" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Speak with a Director</b>
                <span><?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?></span>
            </div>
        </a>

        <a href="mailto:<?= e(SITE_EMAIL) ?>" class="contact-channel-card">
            <div class="channel-icon">
                <i class="fa fa-envelope" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Send Project RFP</b>
                <span><?= e(SITE_EMAIL) ?></span>
            </div>
        </a>

        <a href="<?= e(defined('SITE_WHATSAPP') ? SITE_WHATSAPP : 'https://wa.me/254715097128') ?>" target="_blank" rel="noopener" class="contact-channel-card">
            <div class="channel-icon red">
                <i class="fa fa-whatsapp" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>WhatsApp Desk</b>
                <span>+254 715 097 128</span>
            </div>
        </a>

        <div class="contact-channel-card">
            <div class="channel-icon">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Studio Base</b>
                <span><?= e(defined('SITE_LOCATION') ? SITE_LOCATION : 'Nairobi, Kenya') ?></span>
            </div>
        </div>
    </div>

    <div class="services-list">
        <?php foreach ($sv as $s): ?>
            <article class="svc rv" id="<?= e($s['slug']) ?>">
                <div class="svc-icon-box">
                    <i class="fa fa-<?= e($s['icon']) ?> big" aria-hidden="true"></i>
                </div>
                <div class="svc-body">
                    <h2><?= e($s['title']) ?></h2>
                    <p class="svc-detail"><?= e($s['detail']) ?></p>

                    <div class="svc-meta">
                        <b class="kind">Who it helps:</b>
                        <span><?= e($s['who']) ?></span>
                    </div>

                    <?php if (!empty($s['deliverables'])): ?>
                        <div class="svc-deliverables">
                            <b class="kind">Key Deliverables:</b>
                            <ul class="deliverables-grid">
                                <?php foreach ($s['deliverables'] as $item): ?>
                                    <li><i class="fa fa-check-circle" aria-hidden="true"></i> <?= e($item) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="svc-action">
                        <a class="btn" href="<?= u('contact') ?>?service=<?= e($s['slug']) ?>">
                            <i class="fa fa-paper-plane"></i> Commission this discipline
                        </a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<!-- 4-Stage Methodology -->
<section class="wrap">
    <div class="section-head">
        <p class="section-tag">Methodology</p>
        <h2>Our 4-Stage Process</h2>
        <p class="section-desc">From initial pasture immersion to print-ready packaging, livestock registration, and digital deployment.</p>
    </div>
    <ol class="steps four">
        <li class="rv">
            <b>1. Discover</b>
            <span>We conduct in-depth pasture visits, competitor audits, and butcher counter evaluations to understand your audience and livestock genetics.</span>
        </li>
        <li class="rv">
            <b>2. Define</b>
            <span>We establish your brand positioning, core breed narrative, strict color architecture (Red, Green, White), and veterinary regulatory requirements.</span>
        </li>
        <li class="rv">
            <b>3. Design</b>
            <span>We craft the brand marks, tamper-evident ear tags, packaging dielines, and trade liveries with iterative client reviews.</span>
        </li>
        <li class="rv">
            <b>4. Deliver</b>
            <span>You receive print-ready production files, registered trademark specs, comprehensive brand guidelines, and direct vendor coordination.</span>
        </li>
    </ol>
</section>

<!-- Official MeatSoko Merchandise & Gear -->
<?php
$prods = load('products');
if (!empty($prods)):
?>
<section class="wrap">
    <div class="section-head">
        <p class="section-tag">Official Merchandise</p>
        <h2>Official MeatSoko Gear &amp; Branded Apparel</h2>
        <p class="section-desc">Authentic MeatSoko t-shirts, ceramic mugs, fleece hoodies, and workwear crafted for the pastoral ecosystem.</p>
    </div>
    <div class="grid three">
        <?php foreach (array_slice($prods, 0, 3) as $prod): ?>
            <?= pcard($prod) ?>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- Call to Action Banner -->
<section class="cta">
    <div class="wrap rv">
        <div class="cta-copy">
            <h2>Have a project in mind?</h2>
            <p>Schedule an introductory consultation with our principals to discuss your brand scope and timeline. We respond within 24 hours.</p>
        </div>
        <div class="cta-actions">
            <a class="btn dark" href="<?= u('contact') ?>">
                <i class="fa fa-paper-plane"></i> Start your brief
            </a>
            <a class="btn dark" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                <i class="fa fa-phone"></i> Call 0715 097 128
            </a>
            <?= partner('dark') ?>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
