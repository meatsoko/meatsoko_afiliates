THE MSL BRAND GROUP - Web Platform
---------------------------------------
Lightweight PHP website (PHP 7.4+ / PHP 8.x, file-backed data, no database required).
Core structure: Home, Services, Portfolio (Work), About, Contact.

DEPLOYMENT & SETUP:
1. Upload all files into your web root (or public_html).
2. Configure settings in config.php:
   - SITE_SHORT: Studio brand name
   - SITE_TAG: Brand positioning descriptor
   - SITE_EMAIL: Target inbox for incoming project briefs
   - CLEAN_URLS: Toggle true (for Apache mod_rewrite / Nginx) or false (for direct .php scripts)
3. Ensure the data/ directory has write permissions (chmod 755 or 775) for messages.json logging.
4. Content management:
   - data/products.json: Commercial software (POS, ERP), courses/eCommerce masterclasses, prices, features & buy links
   - data/projects.json: Portfolio case studies and color palette hex arrays
   - data/services.json: Specialist service descriptions and deliverable lists
   - data/team.json: Leadership bios and credentials
   - data/ecosystem.json: MeatSoko ecosystem integration nodes
5. Media assets:
   - Local photography located in assets/img/ (hero-goat.jpg, about-pasture.jpg)
   - Image fallback configuration in includes/functions.php (IMG)

API:
- api.php serves structured read-only JSON for all public site sections (projects, services, team, ecosystem, products).
- Brief submissions and client messages are securely isolated and never exposed via the API.
