<?php
require_once __DIR__ . '/includes/functions.php';

$page = 'index';
$pageTitle = 'Distinctive identities for meat and livestock';
$sv = load('services');
$pj = load('projects');
$products = load('products');
$cats = array_values(array_unique(array_column($pj, 'category')));

require 'includes/header.php';
?>

<section class="hero" style="--img: url('<?= img_url('hero') ?>')">
    <div class="hwrap">
        <p class="chip">
            <i class="fa fa-certificate"></i> Pan-African Meat & Livestock Brand Authority
        </p>
        <h1>Distinctive identities for meat and livestock</h1>
        <p class="lead">
            <?= e(SITE_SHORT) ?> engineers identities that command respect at the auction ring, premium pricing on retail shelves, and trust across pastoral rangelands — from cattle & goat pedigree marks to cold-chain export packaging and trade summit liveries.
        </p>
        <div class="hero-actions">
            <a class="btn" href="<?= u('contact') ?>">
                <i class="fa fa-pencil"></i> Start a brand project
            </a>
            <a class="btn alt" href="<?= u('work') ?>">
                <i class="fa fa-th-large"></i> View portfolio
            </a>
            <a class="btn alt" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                <i class="fa fa-phone"></i> <?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?>
            </a>
        </div>
    </div>

    <div class="ticker" aria-hidden="true">
        <div class="track">
            <?php for ($k = 0; $k < 2; $k++): ?>
                <?php foreach ($sv as $s): ?>
                    <span>
                        <i>
                            <i class="fa fa-<?= e($s['icon']) ?>"></i>
                            <?= e($s['title']) ?>
                        </i>
                    </span>
                <?php endforeach; ?>
            <?php endfor; ?>
        </div>
    </div>
</section>

<!-- Quantitative Impact Stats -->
<section class="wrap stats">
    <div class="rv stat-item">
        <i class="fa fa-compass" aria-hidden="true"></i>
        <b data-count="<?= count($sv) ?>">0</b>
        <span>Core disciplines</span>
    </div>
    <div class="rv stat-item">
        <i class="fa fa-shield" aria-hidden="true"></i>
        <b data-count="56">0</b>
        <span>Pedigree marks & systems</span>
    </div>
    <div class="rv stat-item">
        <i class="fa fa-handshake-o" aria-hidden="true"></i>
        <b data-count="1400">0</b>
        <span>Pastoralists connected</span>
    </div>
</section>

<!-- Editorial Split Section -->
<section class="wrap split">
    <div class="split-media rv">
        <img loading="lazy" alt="Grazing beef cattle on serene green meadow" src="assets/img/project-cow-pasture.jpg">
    </div>
    <div class="split-content rv">
        <p class="section-tag">Value, Heritage & Trust</p>
        <h2>A livestock brand buyers remember, respect and trust</h2>
        <p>
            In livestock auction rings, export air-freight corridors, and retail butchery counters alike, commercial buyers choose names and markings they trust. We engineer identities deeply rooted in your pastoral rangeland story, conforming strictly to veterinary traceability and export standards.
        </p>
        <ul class="ticks">
            <li><i class="fa fa-check"></i> Commercial strategy and genetic heritage prior to aesthetic craft</li>
            <li><i class="fa fa-check"></i> Tamper-evident RFID ear tags, fire brands, and stud certificate architectures</li>
            <li><i class="fa fa-check"></i> Packaging engineering calibrated for vacuum skin durability and cold-chain integrity</li>
            <li><i class="fa fa-check"></i> Direct integration with MeatSoko Group intra-Africa trade networks</li>
        </ul>
        <div class="split-action">
            <a class="btn" href="<?= u('about') ?>">Learn about our studio <i class="fa fa-arrow-right"></i></a>
        </div>
    </div>
</section>

<!-- Sector Specialization: Cattle, Goats, Processors, Trade Networks -->
<section class="wrap">
    <div class="section-head">
        <p class="section-tag">Target Sectors</p>
        <h2>Where Our Work Excels</h2>
        <p class="section-desc">Specialized branding solutions built specifically for cattle breeders, goat pastoralists, commercial abattoirs, and trade networks.</p>
    </div>

    <div class="spec-grid">
        <div class="spec-card rv">
            <i class="fa fa-shield spec-card-icon" aria-hidden="true"></i>
            <h3>Cattle & Beef Ranches</h3>
            <p>Heritage pedigree marks, sire registry catalogs, and RFID ear-tag architectures for Boran, Sahiwal, and Ankole cattle breeders.</p>
            <ul>
                <li><i class="fa fa-check"></i> Registered herd marks</li>
                <li><i class="fa fa-check"></i> Annual auction catalogs</li>
                <li><i class="fa fa-check"></i> Feedlot gate architecture</li>
            </ul>
        </div>

        <div class="spec-card green-top rv">
            <i class="fa fa-leaf spec-card-icon" aria-hidden="true"></i>
            <h3>Goat Flocks & Cooperatives</h3>
            <p>Specialized pastoral flock marks, veterinary health stamps, and export shipping livery for Boer, Galla, and indigenous goat herds.</p>
            <ul>
                <li><i class="fa fa-check"></i> Communal flock branding</li>
                <li><i class="fa fa-check"></i> Live-export shipping livery</li>
                <li><i class="fa fa-check"></i> Weigh-bridge receipts</li>
            </ul>
        </div>

        <div class="spec-card rv">
            <i class="fa fa-cube spec-card-icon" aria-hidden="true"></i>
            <h3>Abattoirs & Processors</h3>
            <p>Moisture-barrier vacuum packaging, shelf-ready carton sleeves, Halal certification seals, and QR traceability for retail counters.</p>
            <ul>
                <li><i class="fa fa-check"></i> Chilled cold-chain labels</li>
                <li><i class="fa fa-check"></i> Halal & regulatory seals</li>
                <li><i class="fa fa-check"></i> Anti-counterfeit QR marks</li>
            </ul>
        </div>

        <div class="spec-card green-top rv">
            <i class="fa fa-handshake-o spec-card-icon" aria-hidden="true"></i>
            <h3>Livestock Trade & Summits</h3>
            <p>Auction yard spatial wayfinding, multilateral summit livery, off-take agreement design, and Pan-African trade delegacy kits.</p>
            <ul>
                <li><i class="fa fa-check"></i> Auction arena wayfinding</li>
                <li><i class="fa fa-check"></i> Buyer-seller match livery</li>
                <li><i class="fa fa-check"></i> Off-take trade frameworks</li>
            </ul>
        </div>
    </div>
</section>

<!-- Moments Across Our Network: Real Cattle, Goats & Networking Images -->
<section class="wrap">
    <div class="section-head flex-head">
        <div>
            <p class="section-tag">Network In Action</p>
            <h2>Moments Across Our Pastoral Network</h2>
            <p class="section-desc">Authentic imagery from our partner cattle ranches, goat cooperatives, and pan-African agribusiness summits.</p>
        </div>
        <a class="btn ghost-btn" href="<?= u('work') ?>">
            Explore case studies <i class="fa fa-arrow-right"></i>
        </a>
    </div>

    <div class="gal">
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-summit-network.jpg" alt="Pan-African Livestock Strategic Summit">
            <figcaption><i class="fa fa-handshake-o"></i> Pan-African Livestock Strategic Summit & Networking Hall</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-livestock-network.jpg" alt="Agribusiness Partnership Agreement">
            <figcaption><i class="fa fa-file-text-o"></i> Commercial Off-Take & Partnership Agreement Handshake</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-goat-pasture.jpg" alt="Commercial Meat Goats on Highland Rangeland">
            <figcaption><i class="fa fa-leaf"></i> Commercial Meat Goats Browsing on Highland Rangeland</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-cattle-breeders.jpg" alt="East African Pedigree Boran Cattle Stud">
            <figcaption><i class="fa fa-shield"></i> Pedigree Boran Champion Cattle Stud Sire Registry</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-goat-flock.jpg" alt="Pastoral Goat Flock on Green Meadow">
            <figcaption><i class="fa fa-check-circle"></i> Pastoralist Goat Flock on Verdant Meadow Pasture</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-cow-pasture.jpg" alt="Grazing Beef Cattle on Pasture">
            <figcaption><i class="fa fa-sun-o"></i> Grazing Commercial Beef Cattle Herd on Open Range</figcaption>
        </figure>
    </div>
</section>

<!-- Creative Capabilities Grid -->
<section class="wrap">
    <div class="section-head">
        <p class="section-tag">Capabilities</p>
        <h2>What We Craft</h2>
        <p class="section-desc">End-to-end creative disciplines tailored specifically for the livestock, meat processing, and butchery industries.</p>
    </div>
    <div class="grid three">
        <?php foreach ($sv as $s): ?>
            <a class="pill rv" href="<?= u('services') ?>#<?= e($s['slug']) ?>">
                <h3><i class="fa fa-<?= e($s['icon']) ?>"></i> <?= e($s['title']) ?></h3>
                <p><?= e($s['summary']) ?></p>
                <span class="pill-more">Explore discipline <i class="fa fa-arrow-right"></i></span>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- Official MeatSoko Merchandise & Store -->
<section class="wrap">
    <div class="section-head">
        <p class="section-tag">Official Merch & Apparel</p>
        <h2>MeatSoko Official Branded Merchandise</h2>
        <p class="section-desc">Authentic MeatSoko & NyamaFest t-shirts, ceramic cups, fleece hoodies, caps, and butcher workwear.</p>
    </div>
    <div class="grid three">
        <?php foreach (array_slice($products, 0, 6) as $prod): ?>
            <?= pcard($prod, true) ?>
        <?php endforeach; ?>
    </div>
</section>

<!-- Selected Work Grid -->
<section class="wrap">
    <div class="section-head flex-head">
        <div>
            <p class="section-tag">Portfolio</p>
            <h2>Selected Work</h2>
            <p class="section-desc">Recent visual identities, structural packaging, and marks created for our partners.</p>
        </div>
        <a class="btn ghost-btn" href="<?= u('work') ?>">
            View all work <i class="fa fa-arrow-right"></i>
        </a>
    </div>
    <div class="grid">
        <?php foreach (array_slice($pj, 0, 4) as $project): ?>
            <?= wcard($project) ?>
        <?php endforeach; ?>
    </div>
</section>

<!-- FAQ Accordion -->
<section class="wrap">
    <div class="section-head">
        <p class="section-tag">Common Enquiries</p>
        <h2>Frequently Asked Questions</h2>
        <p class="section-desc">Clear answers regarding our branding process, livestock marking standards, and MeatSoko Group integration.</p>
    </div>

    <div class="faq-list">
        <details class="faq-item rv" open>
            <summary>What makes livestock and meat branding different from general branding?</summary>
            <p>Livestock branding requires deep technical knowledge of agricultural value chains, veterinary laws, RFID ear tag durability, chill-chain moisture resistance, and pastoral heritage. We engineer systems that work in the dust of the auction ring, survive vacuum chillers, and communicate authentic provenance to commercial buyers.</p>
        </details>

        <details class="faq-item rv">
            <summary>How do your registered herd marks comply with veterinary and livestock registries?</summary>
            <p>Every mark we design is audited against national livestock identification guidelines (including Kenya Directorate of Veterinary Services and regional EAC frameworks). We formulate geometric vectors optimized for tamper-evident ear tag laser printing, hot-iron brands, and digital livestock management databases.</p>
        </details>

        <details class="faq-item rv">
            <summary>How does working with MSL Brand connect us to the MeatSoko Ecosystem?</summary>
            <p>As the branding and engineering pillar of MeatSoko Group, our partners gain immediate access to our ecosystem networks: logistics and cold-chain freight, advisory and legal compliance, intra-Africa marketplace trading, and investor capital through the Assets & Investments Company.</p>
        </details>

        <details class="faq-item rv">
            <summary>How do we initiate a project and what is the typical turnaround?</summary>
            <p>You can contact our studio directly at <b>0715 097 128</b> or email <b>info@meatsokogroup.com</b>. Typical brand identity and packaging systems take 3 to 6 weeks from initial pasture immersion to print-ready pre-press file delivery.</p>
        </details>
    </div>
</section>

<!-- Call to Action Banner -->
<section class="cta">
    <div class="wrap rv">
        <div class="cta-copy">
            <h2>Ready to build a brand that commands premium value?</h2>
            <p>Connect with our principals today to discuss your cattle herd, goat flock, butchery, or processing facility. We respond within 24 hours.</p>
        </div>
        <div class="cta-actions">
            <a class="btn dark" href="<?= u('contact') ?>">
                <i class="fa fa-paper-plane"></i> Contact our studio
            </a>
            <a class="btn dark" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                <i class="fa fa-phone"></i> Call 0715 097 128
            </a>
            <?= partner('dark') ?>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
