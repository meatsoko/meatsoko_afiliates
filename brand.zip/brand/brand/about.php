<?php
require_once __DIR__ . '/includes/functions.php';

$page = 'about';
$pageTitle = 'About Our Studio';
$team = load('team');

require 'includes/header.php';
?>

<section class="wrap page">
    <div class="page-intro">
        <p class="section-tag">About MSL Brand Group</p>
        <h1>Engineering Value for Meat & Livestock</h1>
        <p class="lead">
            We are the specialized branding, design and engineering company within the MeatSoko Group. We partner with cattle breeders, goat farming cooperatives, commercial abattoirs, and regional processors to build brands that command market respect, export readiness, and premium pricing.
        </p>
    </div>

    <!-- Quick Direct Contact Strip -->
    <div class="contact-channels rv" style="margin-bottom: 3.5rem;">
        <a href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>" class="contact-channel-card">
            <div class="channel-icon red">
                <i class="fa fa-phone" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Studio Direct Line</b>
                <span><?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?></span>
            </div>
        </a>

        <a href="mailto:<?= e(SITE_EMAIL) ?>" class="contact-channel-card">
            <div class="channel-icon">
                <i class="fa fa-envelope" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>General Inquiries</b>
                <span><?= e(SITE_EMAIL) ?></span>
            </div>
        </a>

        <a href="<?= e(defined('SITE_WHATSAPP') ? SITE_WHATSAPP : 'https://wa.me/254715097128') ?>" target="_blank" rel="noopener" class="contact-channel-card">
            <div class="channel-icon red">
                <i class="fa fa-whatsapp" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>WhatsApp Desk</b>
                <span>+254 715 097 128</span>
            </div>
        </a>

        <div class="contact-channel-card">
            <div class="channel-icon">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Headquarters</b>
                <span><?= e(defined('SITE_LOCATION') ? SITE_LOCATION : 'Nairobi, Kenya') ?></span>
            </div>
        </div>
    </div>

    <div class="grid four-grid">
        <div class="pill rv">
            <h3><i class="fa fa-bullseye" aria-hidden="true"></i> Mission</h3>
            <p>Empower livestock producers and meat businesses to capture lasting market trust and premium pricing across Africa.</p>
        </div>
        <div class="pill rv">
            <h3><i class="fa fa-shield" aria-hidden="true"></i> Bespoke Pedigree</h3>
            <p>Zero templates. Every identity system is conceived from your specific genetics, pasture heritage, and target consumer.</p>
        </div>
        <div class="pill rv">
            <h3><i class="fa fa-handshake-o" aria-hidden="true"></i> Commercial Clarity</h3>
            <p>Transparent project scopes, rigorous pre-press specifications, and designs calibrated for production feasibility.</p>
        </div>
        <div class="pill rv">
            <h3><i class="fa fa-leaf" aria-hidden="true"></i> Pasture-Grounded</h3>
            <p>We understand the practical realities of abattoirs, chill chains, auction arenas, and butcher display counters.</p>
        </div>
    </div>

    <!-- Pan-African Livestock Corridor Coverage -->
    <div class="section-head" style="margin-top: 4.5rem">
        <p class="section-tag">Pan-African Reach</p>
        <h2>Our Pastoral & Trade Footprint</h2>
        <p class="section-desc">Operating across premier livestock producing rangelands and intra-Africa trade corridors.</p>
    </div>

    <div class="spec-grid">
        <div class="spec-card rv">
            <i class="fa fa-map-marker spec-card-icon" aria-hidden="true"></i>
            <h3>Rift Valley & Laikipia Plateau</h3>
            <p>Hub of premier Boran cattle studs, commercial feedlots, and private ranches requiring registered pedigree marks and sire auction catalogs.</p>
            <ul>
                <li><i class="fa fa-check"></i> Pedigree herd marks</li>
                <li><i class="fa fa-check"></i> Auction catalog systems</li>
            </ul>
        </div>

        <div class="spec-card green-top rv">
            <i class="fa fa-leaf spec-card-icon" aria-hidden="true"></i>
            <h3>Northern Rangelands & Kajiado</h3>
            <p>Home to pastoral goat farming alliances, Galla and Boer meat goat breeders, and communal aggregation weigh-stations.</p>
            <ul>
                <li><i class="fa fa-check"></i> Flock identification seals</li>
                <li><i class="fa fa-check"></i> Export health tags</li>
            </ul>
        </div>

        <div class="spec-card rv">
            <i class="fa fa-globe spec-card-icon" aria-hidden="true"></i>
            <h3>Pan-African Export Gateways</h3>
            <p>Cold-chain packaging architectures and Halal compliance branding engineered for Mombasa, Lamu, and regional air-cargo hubs.</p>
            <ul>
                <li><i class="fa fa-check"></i> Halal export compliance</li>
                <li><i class="fa fa-check"></i> Chilled air-cargo shippers</li>
            </ul>
        </div>

        <div class="spec-card green-top rv">
            <i class="fa fa-users spec-card-icon" aria-hidden="true"></i>
            <h3>Ecosystem Trade Forums</h3>
            <p>Staging visual livery and partner credentials for MeatSoko summits, livestock buyer-seller forums, and government roundtables.</p>
            <ul>
                <li><i class="fa fa-check"></i> Summit staging livery</li>
                <li><i class="fa fa-check"></i> Bilateral off-take contracts</li>
            </ul>
        </div>
    </div>

    <!-- Real Network Moments Gallery -->
    <div class="section-head" style="margin-top: 4.5rem">
        <p class="section-tag">Real Moments</p>
        <h2>Pastoral Field & Summit Moments</h2>
        <p class="lead">Grounded documentation of our partner cattle ranches, goat rangelands, and commercial agribusiness summits.</p>
    </div>

    <div class="gal">
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-summit-network.jpg" alt="Pan-African Livestock Strategic Summit">
            <figcaption><i class="fa fa-handshake-o"></i> Pan-African Livestock Strategic Summit & Networking Hall</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-livestock-network.jpg" alt="Agribusiness Partnership Agreement">
            <figcaption><i class="fa fa-file-text-o"></i> Strategic Agribusiness Partnership & Off-Take Handshake</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-goat-pasture.jpg" alt="Commercial Meat Goats on Highland Rangeland">
            <figcaption><i class="fa fa-leaf"></i> Commercial Boer & Galla Goats on Highland Rangeland</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-cattle-breeders.jpg" alt="East African Pedigree Boran Cattle Stud">
            <figcaption><i class="fa fa-shield"></i> Pedigree Boran Champion Cattle Stud Sire Registry</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-goat-flock.jpg" alt="Pastoral Goat Flock on Green Meadow">
            <figcaption><i class="fa fa-check-circle"></i> Pastoralist Goat Flock on Verdant Meadow Pasture</figcaption>
        </figure>
        <figure class="rv">
            <img loading="lazy" src="assets/img/project-cow-pasture.jpg" alt="Grazing Beef Cattle on Pasture">
            <figcaption><i class="fa fa-sun-o"></i> Grazing Commercial Beef Cattle Herd on Open Range</figcaption>
        </figure>
    </div>

    <!-- Practice Leadership Team -->
    <div class="section-head" style="margin-top: 4.5rem">
        <p class="section-tag">Studio Disciplines</p>
        <h2>Practice Leadership</h2>
        <p class="section-desc">Multidisciplinary practices covering brand architecture, pastoral value chains, veterinary traceability, and packaging engineering.</p>
    </div>

    <div class="grid three">
        <?php foreach ($team as $member): ?>
            <div class="pill rv team-card">
                <div class="team-header">
                    <div class="team-avatar" aria-hidden="true">
                        <?php
                            $initials = implode('', array_map(fn($w) => strtoupper($w[0] ?? ''), explode(' ', $member['name'] ?? '')));
                            echo e(substr($initials, 0, 2));
                        ?>
                    </div>
                    <div>
                        <h3><?= e($member['name']) ?></h3>
                        <b class="kind"><?= e($member['role']) ?></b>
                    </div>
                </div>
                <p><?= e($member['bio']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Integrated MeatSoko Ecosystem Section -->
<section class="wrap page-sub" style="padding-top: 0">
    <?php
    require __DIR__ . '/includes/ecosystem.php';
    ecosystem_section();
    ?>
</section>

<!-- Call to Action Banner -->
<section class="cta">
    <div class="wrap rv">
        <div class="cta-copy">
            <h2>Ready to craft an unmistakable brand?</h2>
            <p>Connect with our principals to explore how we can elevate your cattle, goat, or meat business.</p>
        </div>
        <div class="cta-actions">
            <a class="btn dark" href="<?= u('contact') ?>">
                <i class="fa fa-paper-plane"></i> Contact our studio
            </a>
            <a class="btn dark" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                <i class="fa fa-phone"></i> Call 0715 097 128
            </a>
            <?= partner('dark') ?>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
