<?php
require_once __DIR__ . '/includes/functions.php';

$sv = load('services');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $msg = trim($_POST['msg'] ?? '');
    $company = trim($_POST['org'] ?? '');
    $service = trim($_POST['service'] ?? '');
    $honeypot = $_POST['website'] ?? '';

    if (ok() && $honeypot === '' && $name && filter_var($email, FILTER_VALIDATE_EMAIL) && $msg) {
        $messages = load('messages');
        $messages[] = [
            'date'    => date('Y-m-d H:i'),
            'name'    => $name,
            'email'   => $email,
            'phone'   => $phone,
            'company' => $company,
            'service' => $service,
            'msg'     => $msg,
        ];
        save('messages', $messages);

        $subject = "Brand enquiry from {$name}" . ($service ? " ({$service})" : '');
        $body = "From: {$name}" . ($company ? " ({$company})" : '') . "\n"
              . "Email: {$email}\n"
              . "Phone: {$phone}\n"
              . "Service: {$service}\n\n"
              . "Message:\n{$msg}";

        @mail(SITE_EMAIL, $subject, $body, "Reply-To: {$email}\r\nContent-Type: text/plain; charset=UTF-8");
        $_SESSION['flash'] = 'Thank you! We have received your project brief and will respond within 24 hours.';
    } else {
        $_SESSION['flash'] = 'Please provide your name, a valid email address, and a brief description of your project.';
    }
    go('contact');
}

$selectedService = $_GET['service'] ?? '';
$page = 'contact';
$pageTitle = 'Start a Brand Project';

require 'includes/header.php';
?>

<section class="wrap page">
    <div class="page-intro">
        <p class="section-tag">Direct Studio Enquiries</p>
        <h1>Let's Build Your Livestock Brand</h1>
        <p class="lead">
            Whether you are registering a pedigree cattle herd mark, establishing a pastoral goat cooperative brand, launching commercial abattoir retail packaging, or coordinating pan-African livestock summits, our studio is ready to collaborate.
        </p>
    </div>

    <!-- Quick Direct Contact Channels -->
    <div class="contact-channels rv">
        <a href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>" class="contact-channel-card">
            <div class="channel-icon red">
                <i class="fa fa-phone" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Call Direct</b>
                <span><?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?></span>
            </div>
        </a>

        <a href="mailto:<?= e(SITE_EMAIL) ?>" class="contact-channel-card">
            <div class="channel-icon">
                <i class="fa fa-envelope" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Business Email</b>
                <span><?= e(SITE_EMAIL) ?></span>
            </div>
        </a>

        <a href="<?= e(defined('SITE_WHATSAPP') ? SITE_WHATSAPP : 'https://wa.me/254715097128') ?>" target="_blank" rel="noopener" class="contact-channel-card">
            <div class="channel-icon red">
                <i class="fa fa-whatsapp" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>WhatsApp Desk</b>
                <span>+254 715 097 128</span>
            </div>
        </a>

        <div class="contact-channel-card">
            <div class="channel-icon">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
            </div>
            <div class="channel-meta">
                <b>Studio Location</b>
                <span><?= e(defined('SITE_LOCATION') ? SITE_LOCATION : 'Nairobi, Kenya') ?></span>
            </div>
        </div>
    </div>

    <?= flash() ?>

    <div class="contact-layout">
        <div class="contact-info rv">
            <div class="contact-card">
                <h3><i class="fa fa-headphones" aria-hidden="true"></i> Direct Studio Access</h3>
                <p>We review every brief directly with our creative directors and value-chain strategists.</p>
                <div style="margin-top: 1rem; display: flex; flex-direction: column; gap: 0.6rem;">
                    <a class="contact-email-link" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                        <i class="fa fa-phone" style="color:var(--tg);"></i> <?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?>
                    </a>
                    <a class="contact-email-link" href="mailto:<?= e(SITE_EMAIL) ?>">
                        <i class="fa fa-envelope" style="color:var(--tg);"></i> <?= e(SITE_EMAIL) ?>
                    </a>
                    <a class="contact-email-link" href="<?= e(defined('SITE_WHATSAPP') ? SITE_WHATSAPP : 'https://wa.me/254715097128') ?>" target="_blank" rel="noopener">
                        <i class="fa fa-whatsapp" style="color:var(--ac);"></i> Chat via WhatsApp Direct
                    </a>
                </div>
            </div>

            <div class="contact-steps">
                <h4>What to expect next:</h4>
                <ol class="brief-steps">
                    <li>
                        <b>Initial Review & Triage</b>
                        <span>We assess your sector (cattle, goat, abattoir, or trade network) and scope within 24 hours.</span>
                    </li>
                    <li>
                        <b>Discovery Call & Scoping</b>
                        <span>A 30-minute consultation to examine genetics, market channel, packaging substrates, and budget.</span>
                    </li>
                    <li>
                        <b>Fixed Scope & Milestone Roadmap</b>
                        <span>A comprehensive statement of work with guaranteed milestone delivery dates and trademark clearance.</span>
                    </li>
                </ol>
            </div>

            <div class="contact-guarantee">
                <i class="fa fa-shield" aria-hidden="true"></i>
                <div>
                    <b>Strict Confidentiality & NDA</b>
                    <span>We routinely sign mutual non-disclosure agreements for unreleased pedigree bloodlines, processing facilities, and regional acquisitions.</span>
                </div>
            </div>
        </div>

        <div class="contact-form-card rv">
            <form method="post" class="styled-form" novalidate>
                <?= csrf() ?>

                <div class="form-row">
                    <label>
                        Full Name <span class="req">*</span>
                        <input name="name" type="text" placeholder="e.g. Samuel Karanja" required autocomplete="name">
                    </label>

                    <label>
                        Business Email <span class="req">*</span>
                        <input name="email" type="email" placeholder="name@company.com" required autocomplete="email">
                    </label>
                </div>

                <div class="form-row">
                    <label>
                        Phone / WhatsApp Number
                        <input name="phone" type="tel" placeholder="e.g. 0715 097 128" autocomplete="tel">
                    </label>

                    <label>
                        Ranch, Butchery, or Company Name
                        <input name="org" type="text" placeholder="e.g. Rift Highlands Pastoral" autocomplete="organization">
                    </label>
                </div>

                <label>
                    Discipline Needed
                    <select name="service">
                        <option value="">Select a service (or general inquiry)</option>
                        <?php foreach ($sv as $s): ?>
                            <option value="<?= e($s['slug']) ?>"<?= $selectedService === $s['slug'] ? ' selected' : '' ?>>
                                <?= e($s['title']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Project Goals & Scope <span class="req">*</span>
                    <textarea name="msg" rows="5" placeholder="Tell us about your cattle herd, goat flock, butchery counters, cold-chain packaging, or summit timeline..." required></textarea>
                </label>

                <!-- Anti-spam honeypot -->
                <input name="website" value="" style="display:none" tabindex="-1" autocomplete="off" aria-hidden="true">

                <div class="form-actions">
                    <button class="btn" type="submit">
                        <i class="fa fa-paper-plane" aria-hidden="true"></i> Submit project brief
                    </button>
                    <span class="privacy-note"><i class="fa fa-lock" aria-hidden="true"></i> Your data is kept strictly confidential.</span>
                </div>
            </form>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
