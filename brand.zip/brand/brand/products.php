<?php
require_once __DIR__ . '/config.php';

$targetUrl = defined('STORE_URL') ? STORE_URL : 'https://event.meatsokogroup.com';

// Instant 302 redirect to official MeatSoko store
header('Location: ' . $targetUrl, true, 302);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="0;url=<?= htmlspecialchars($targetUrl, ENT_QUOTES, 'UTF-8') ?>">
    <title>Redirecting to MeatSoko Merchandise &amp; Events Store...</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; text-align: center; padding: 4rem 1.5rem; background: #0b130e; color: #f1f5f9;">
    <div style="max-width: 520px; margin: 0 auto; background: #132219; padding: 2.5rem; border-radius: 16px; border: 1px solid rgba(255,255,255,0.08); box-shadow: 0 20px 40px rgba(0,0,0,0.4);">
        <h2 style="margin: 0 0 1rem; color: #fff;">Opening Official MeatSoko Store</h2>
        <p style="color: #94a3b8; line-height: 1.6; margin-bottom: 2rem;">
            All official MeatSoko t-shirts, cups, hoodies, caps, aprons, and merchandise are available live on our official store.
        </p>
        <a href="<?= htmlspecialchars($targetUrl, ENT_QUOTES, 'UTF-8') ?>" style="display: inline-block; padding: 14px 28px; background: #166534; color: #fff; text-decoration: none; border-radius: 999px; font-weight: 700; font-size: 1.05rem;">
            Continue to event.meatsokogroup.com &rarr;
        </a>
    </div>
    <script>window.location.href = <?= json_encode($targetUrl) ?>;</script>
</body>
</html>
