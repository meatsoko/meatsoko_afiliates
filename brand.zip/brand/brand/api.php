<?php
/**
 * Public Read-Only JSON API for THE MSL BRAND GROUP
 * Endpoints:
 *   api.php                                    -> Full studio catalog & metadata
 *   api.php?section=projects                   -> Selected section(s)
 *   api.php?section=projects&q=search          -> Full-text search
 *   api.php?section=projects&category=Butchery -> Field filtering
 */

require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=60');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    header('Access-Control-Allow-Methods: GET');
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'GET only']);
    exit;
}

function out($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$rawDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$dir = ($rawDir === '/' || $rawDir === '\\' || $rawDir === '.') ? '' : trim(str_replace('\\', '/', $rawDir), '/');
$base = $proto . '://' . $host . ($dir !== '' ? '/' . $dir : '') . '/';

$files = ['projects', 'services', 'team', 'products'];

function absu(string $base, $val) {
    if (is_string($val) && $val !== '' && !preg_match('#^(https?:|//|data:|mailto:|\#)#i', $val)) {
        return $base . ltrim($val, '/');
    }
    return $val;
}

function prep(array $rows, string $base): array {
    return array_map(function ($row) use ($base) {
        if (!is_array($row)) return $row;
        foreach (['file', 'image', 'src'] as $key) {
            if (isset($row[$key])) {
                $row[$key] = absu($base, $row[$key]);
            }
        }
        return $row;
    }, $rows);
}

function filt(array $rows): array {
    $skip = ['section', 'q', 'limit'];
    foreach ($_GET as $key => $val) {
        if (in_array($key, $skip, true) || !is_string($val) || $val === '') {
            continue;
        }
        $rows = array_filter($rows, function ($r) use ($key, $val) {
            if (!is_array($r) || !isset($r[$key])) return false;
            $haystack = is_array($r[$key]) ? implode(' ', $r[$key]) : (string)$r[$key];
            return stripos($haystack, $val) !== false;
        });
    }

    if (!empty($_GET['q'])) {
        $q = (string)$_GET['q'];
        $rows = array_filter($rows, function ($r) use ($q) {
            return stripos(json_encode($r, JSON_UNESCAPED_UNICODE), $q) !== false;
        });
    }

    $rows = array_values($rows);
    return isset($_GET['limit']) ? array_slice($rows, 0, max(1, (int)$_GET['limit'])) : $rows;
}

$sections = [
    'site' => fn() => [
        'name'           => SITE_SHORT,
        'tagline'        => SITE_TAG,
        'email'          => SITE_EMAIL,
        'phone'          => defined('SITE_PHONE') ? SITE_PHONE : '',
        'phone_display'  => defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '',
        'phone_intl'     => defined('SITE_PHONE_INTL') ? SITE_PHONE_INTL : '',
        'whatsapp'       => defined('SITE_WHATSAPP') ? SITE_WHATSAPP : '',
        'location'       => defined('SITE_LOCATION') ? SITE_LOCATION : '',
        'url'            => $base,
        'ecosystem_role' => defined('ECO_PILLAR') ? ECO_PILLAR : null,
    ],
    'about' => fn() => [
        'summary' => SITE_SHORT . ' is a specialized branding consultancy engineering brand strategy, visual identities, packaging architectures, and registered livestock marks for agrifood businesses.',
        'points'  => [
            ['title' => 'Mission', 'text' => 'Empower livestock producers and meat businesses to capture lasting market trust and premium pricing.'],
            ['title' => 'Bespoke Craft', 'text' => 'Zero templates. Every identity is conceived from your specific genetics, region, and target market.'],
            ['title' => 'Commercial Clarity', 'text' => 'Transparent project scopes, rigorous pre-press specs, and designs calibrated for production.'],
            ['title' => 'Pasture-Grounded', 'text' => 'We understand the practical realities of abattoirs, chill chains, auction arenas, and butcher display counters.'],
        ],
    ],
    'ecosystem' => fn() => load('ecosystem'),
    'pages'     => fn() => array_map(fn($p) => $base . ($p === 'index' ? '' : u($p)), ['index', 'products', 'services', 'work', 'about', 'contact']),
];

foreach ($files as $f) {
    $sections[$f] = fn() => filt(prep(load($f), $base));
}

$requested = !empty($_GET['section']) ? array_map('trim', explode(',', $_GET['section'])) : array_keys($sections);
$response = [
    'generated' => date('c'),
    'sections'  => array_keys($sections),
];

foreach ($requested as $sec) {
    if (!isset($sections[$sec])) {
        out(['error' => "Unknown section '{$sec}'", 'available' => array_keys($sections)], 400);
    }
    $response[$sec] = $sections[$sec]();
}

out($response);
