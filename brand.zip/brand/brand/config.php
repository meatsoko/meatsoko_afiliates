<?php
// === EDIT THESE BEFORE GOING LIVE ===
const SITE_SHORT = 'THE MSL BRAND GROUP';
const SITE_TAG   = 'Meat and livestock branding company';
const SITE_EMAIL = 'info@meatsokogroup.com';   // enquiries are emailed here
const SITE_PHONE = '0715097128';
const SITE_PHONE_DISPLAY = '0715 097 128';
const SITE_PHONE_INTL = '+254715097128';
const SITE_WHATSAPP = 'https://wa.me/254715097128';
const SITE_LOCATION = 'Nairobi, Kenya';
const ECO_PILLAR    = 'Branding, Design & Engineering';   // this company's place in the MeatSoko ecosystem
const PARTNER_URL   = 'contact';       // page name (e.g. 'contact') or a full link (https://...)
const PARTNER_LABEL = 'Partner with us';
const STORE_URL     = 'https://event.meatsokogroup.com'; // official MeatSoko merchandise & events store
const CLEAN_URLS = true;                 // set false if your host has no mod_rewrite
