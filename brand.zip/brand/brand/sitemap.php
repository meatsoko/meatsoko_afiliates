<?php
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/xml; charset=utf-8');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
$scheme = $isHttps ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$baseUrl = "{$scheme}://{$host}{$dir}/";

$routes = [
    ''         => ['priority' => '1.0', 'changefreq' => 'weekly'],
    'services' => ['priority' => '0.9', 'changefreq' => 'weekly'],
    'work'     => ['priority' => '0.9', 'changefreq' => 'weekly'],
    'about'    => ['priority' => '0.8', 'changefreq' => 'monthly'],
    'contact'  => ['priority' => '0.8', 'changefreq' => 'monthly'],
];

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach ($routes as $route => $meta): ?>
    <url>
        <loc><?= e($baseUrl . ($route ? u($route) : '')) ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq><?= e($meta['changefreq']) ?></changefreq>
        <priority><?= e($meta['priority']) ?></priority>
    </url>
<?php endforeach; ?>
</urlset>
