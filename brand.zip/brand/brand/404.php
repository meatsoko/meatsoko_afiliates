<?php
require_once __DIR__ . '/includes/functions.php';

http_response_code(404);
$page = '';
$pageTitle = 'Page Not Found';

require 'includes/header.php';
?>

<section class="wrap page" style="text-align: center; max-width: 680px; margin: 0 auto; padding-top: 10rem;">
    <p class="section-tag">Error 404</p>
    <h1>Page Not Found</h1>
    <p class="lead" style="margin: 1rem auto 2rem;">
        The page or project you requested cannot be located. It may have moved or been updated.
    </p>
    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
        <a class="btn" href="<?= u('index') ?>"><i class="fa-solid fa-house"></i> Return Home</a>
        <a class="btn alt" href="<?= u('work') ?>" style="box-shadow: inset 0 0 0 2px var(--ac); color: var(--ac);"><i class="fa-solid fa-swatchbook"></i> Explore Our Work</a>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
