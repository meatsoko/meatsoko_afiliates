<?php
require_once __DIR__ . '/includes/functions.php';

$page = 'work';
$pageTitle = 'Our Work';
$pj = load('projects');
$cats = array_values(array_unique(array_column($pj, 'category')));

require 'includes/header.php';
?>

<section class="wrap page">
    <div class="page-intro">
        <p class="section-tag">Curated Portfolio</p>
        <h1>Selected Livestock & Meat Branding</h1>
        <p class="lead">
            Explore our case studies spanning cattle stud registries, pastoral goat cooperatives, commercial abattoirs, and pan-African livestock trade summits.
        </p>
    </div>

    <div class="work-toolbar">
        <div class="search-box">
            <i class="fa fa-search search-icon" aria-hidden="true"></i>
            <input id="qn" type="search" placeholder="Search by name, sector, cattle, goats, summit..." aria-label="Search projects">
        </div>

        <div class="chips" role="tablist" aria-label="Filter projects by category">
            <button class="chip-btn on" data-c="all">All Sectors</button>
            <?php foreach ($cats as $cat): ?>
                <button class="chip-btn" data-c="<?= e($cat) ?>"><?= e($cat) ?></button>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="grid" id="projectsGrid">
        <?php foreach ($pj as $project): ?>
            <?= wcard($project) ?>
        <?php endforeach; ?>
    </div>

    <div id="noResults" class="empty-state" hidden>
        <i class="fa fa-folder-open-o" aria-hidden="true"></i>
        <h3>No projects match your criteria</h3>
        <p>Try adjusting your search terms or filter to see more case studies.</p>
        <button type="button" class="btn ghost-btn" id="resetFilterBtn">View all projects</button>
    </div>
</section>

<!-- Call to Action Banner -->
<section class="cta">
    <div class="wrap rv">
        <div class="cta-copy">
            <h2>Looking to create an industry-defining livestock brand?</h2>
            <p>We work directly with ranch owners, cooperatives, and meat processors. Contact us today.</p>
        </div>
        <div class="cta-actions">
            <a class="btn dark" href="<?= u('contact') ?>">
                <i class="fa fa-paper-plane"></i> Commission a project
            </a>
            <a class="btn dark" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                <i class="fa fa-phone"></i> Call 0715 097 128
            </a>
            <?= partner('dark') ?>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
