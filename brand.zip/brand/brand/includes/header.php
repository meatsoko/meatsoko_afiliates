<?php
require_once __DIR__ . '/functions.php';

$page = $page ?? '';
$pageTitle = $pageTitle ?? 'Distinctive identities for meat and livestock';
$storeUrl = defined('STORE_URL') ? STORE_URL : 'https://event.meatsokogroup.com';

$NAV = [
    'index'    => ['Home', 'home'],
    'services' => ['Services', 'pencil-square-o'],
    'products' => ['Products', 'shopping-bag', $storeUrl],
    'work'     => ['Work', 'th-large'],
    'about'    => ['About', 'info-circle'],
    'contact'  => ['Contact', 'envelope'],
];
$BOT = $NAV;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title><?= e($pageTitle) ?> | <?= e(SITE_SHORT) ?></title>
    <meta name="description" content="<?= e(SITE_SHORT) ?> is a specialized meat and livestock branding consultancy. We engineer brand strategy, visual identities, packaging architectures, and registered herd marks that build lasting trust and premium market value.">
    <meta name="robots" content="index, follow">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='8' fill='%23166534'/%3E%3Cpath d='M16 6c-3 0-6 3-6 7v7c0 3 3 6 6 6s6-3 6-6v-7c0-4-3-7-6-7z' fill='%23dc2626'/%3E%3Ccircle cx='16' cy='12' r='2' fill='%23ffffff'/%3E%3C/svg%3E">

    <!-- Open Graph / Meta -->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= e(SITE_SHORT) ?>">
    <meta property="og:title" content="<?= e($pageTitle) ?> | <?= e(SITE_SHORT) ?>">
    <meta property="og:description" content="Distinctive identities, cattle & goat breed marks, and retail packaging systems crafted for pastoralists and meat enterprises.">

    <script>
        try {
            document.documentElement.dataset.theme = localStorage.theme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
        } catch (err) {}
    </script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;500;600;700;800&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Font Awesome 4 and Font Awesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/main.js" defer></script>
</head>
<body>
    <a href="#mainContent" class="skip-link">Skip to main content</a>

    <header class="top" id="top">
        <a class="logo" href="<?= u('index') ?>" aria-label="<?= e(SITE_SHORT) ?> home">
            <span class="tagmark" aria-hidden="true"></span>
            <span>
                <?= e(SITE_SHORT) ?>
                <small><?= e(SITE_TAG) ?></small>
            </span>
        </a>

        <nav class="dnav" aria-label="Main Navigation">
            <?php foreach ($NAV as $slug => $item): 
                $isExt = !empty($item[2]);
                $href = $isExt ? $item[2] : u($slug);
                $attrs = $isExt ? ' target="_blank" rel="noopener"' : ($page === $slug ? ' aria-current="page"' : '');
            ?>
                <a href="<?= e($href) ?>"<?= $attrs ?>>
                    <?= e($item[0]) ?><?= $isExt ? ' <i class="fa fa-external-link" style="font-size:0.75em;opacity:0.8;margin-left:2px;" aria-hidden="true"></i>' : '' ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="acts">
            <a href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>" class="ic" aria-label="Call studio" title="Call: <?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?>">
                <i class="fa fa-phone" aria-hidden="true"></i>
            </a>
            <button class="ic theme-btn" aria-label="Toggle color theme" title="Toggle theme">
                <i class="fa fa-moon-o t-moon" aria-hidden="true"></i>
                <i class="fa fa-sun-o t-sun" aria-hidden="true"></i>
            </button>
            <button class="ic menu-btn" id="menuBtn" aria-label="Open mobile navigation menu" aria-expanded="false" aria-controls="side">
                <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
        </div>
    </header>

    <div class="veil" id="veil" aria-hidden="true"></div>

    <aside class="side" id="side" aria-label="Mobile Navigation">
        <div class="sidehead">
            <b><?= e(SITE_SHORT) ?></b>
            <button class="ic" id="closeBtn" aria-label="Close menu">
                <i class="fa fa-times" aria-hidden="true"></i>
            </button>
        </div>

        <nav class="side-links">
            <?php foreach ($NAV as $slug => $item): 
                $isExt = !empty($item[2]);
                $href = $isExt ? $item[2] : u($slug);
                $attrs = $isExt ? ' target="_blank" rel="noopener"' : ($page === $slug ? ' aria-current="page"' : '');
            ?>
                <a href="<?= e($href) ?>"<?= $attrs ?>>
                    <span><i class="fa fa-<?= e($item[1]) ?>" aria-hidden="true"></i></span>
                    <?= e($item[0]) ?><?= $isExt ? ' <i class="fa fa-external-link" style="font-size:0.78em;opacity:0.75;margin-left:auto;" aria-hidden="true"></i>' : '' ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="side-footer">
            <button class="theme-btn wide">
                <i class="fa fa-adjust" aria-hidden="true"></i> Switch appearance
            </button>
            <div class="sidenote">
                <span>Direct studio contact</span>
                <a href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>" style="display:block; font-weight:700; margin-bottom: 0.25rem;">
                    <i class="fa fa-phone"></i> <?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?>
                </a>
                <a href="mailto:<?= e(SITE_EMAIL) ?>" style="display:block; margin-bottom: 0.25rem;">
                    <i class="fa fa-envelope"></i> <?= e(SITE_EMAIL) ?>
                </a>
                <a href="<?= e(defined('SITE_WHATSAPP') ? SITE_WHATSAPP : 'https://wa.me/254715097128') ?>" target="_blank" rel="noopener" style="display:inline-flex; align-items:center; gap:0.4rem; color:var(--ac); font-weight:600;">
                    <i class="fa fa-whatsapp"></i> Chat on WhatsApp
                </a>
            </div>
        </div>
    </aside>

    <main id="mainContent">
