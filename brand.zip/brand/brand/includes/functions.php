<?php
require_once __DIR__ . '/../config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * Image configurations for primary hero and editorial sections.
 * Uses high-resolution local assets with Unsplash CDN fallbacks.
 */
const IMG = [
    'hero'          => 'assets/img/hero-goat.jpg',
    'hero_remote'   => 'https://images.unsplash.com/photo-1571076442742-2d459d0c5000?auto=format&fit=crop&w=1920&q=80',
    'about'         => 'assets/img/about-pasture.jpg',
    'about_remote'  => 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=1200&q=80',
];

/**
 * Resolves an image URL, preferring local files when present.
 */
function img_url(string $key): string {
    $path = IMG[$key] ?? '';
    if ($path && is_file(__DIR__ . '/../' . $path)) {
        return $path;
    }
    return IMG[$key . '_remote'] ?? $path;
}

/**
 * Renders the animated partner button.
 */
function partner(string $class = ''): string {
    $url = PARTNER_URL;
    $isExternal = preg_match('#^https?://#i', $url);
    $href = $isExternal ? e($url) : u($url);
    $attrs = $isExternal ? ' target="_blank" rel="noopener"' : '';
    $classes = 'btn pulse ' . e($class);

    return '<a class="' . trim($classes) . '" href="' . $href . '"' . $attrs . '>'
         . '<i class="fa fa-handshake-o"></i> ' . e(PARTNER_LABEL)
         . ' <i class="fa fa-arrow-right go"></i></a>';
}

/**
 * Escapes HTML entities for output security.
 */
function e($str): string {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/**
 * Loads JSON data from the data directory.
 */
function load(string $name): array {
    $file = __DIR__ . "/../data/{$name}.json";
    if (!is_file($file)) {
        return [];
    }
    $decoded = json_decode(file_get_contents($file), true);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Saves data into a JSON file with exclusive lock.
 */
function save(string $name, array $data): void {
    $file = __DIR__ . "/../data/{$name}.json";
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/**
 * Generates SEO-friendly or clean page URLs.
 */
function u(string $file): string {
    if ($file === 'index') {
        return CLEAN_URLS ? './' : 'index.php';
    }
    return CLEAN_URLS ? $file : $file . '.php';
}

/**
 * Generates a CSRF token hidden input field.
 */
function csrf(): string {
    if (empty($_SESSION['t'])) {
        $_SESSION['t'] = bin2hex(random_bytes(16));
    }
    return '<input type="hidden" name="t" value="' . $_SESSION['t'] . '">';
}

/**
 * Validates CSRF token from POST requests.
 */
function ok(): bool {
    return isset($_POST['t'], $_SESSION['t']) && hash_equals($_SESSION['t'], $_POST['t']);
}

/**
 * Redirects to a named page.
 */
function go(string $page): void {
    header('Location: ' . u($page));
    exit;
}

/**
 * Displays session flash message if present.
 */
function flash(): string {
    $msg = $_SESSION['flash'] ?? '';
    unset($_SESSION['flash']);
    if (!$msg) {
        return '';
    }
    return '<div class="flash" role="status"><i class="fa fa-check-circle"></i> ' . e($msg) . '</div>';
}

/**
 * Determines optimal foreground text color (dark or light) based on luminance.
 */
function ink(string $hex): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if (strlen($hex) !== 6) {
        return '#ffffff';
    }
    $luminance = 0.299 * hexdec(substr($hex, 0, 2)) +
                 0.587 * hexdec(substr($hex, 2, 2)) +
                 0.114 * hexdec(substr($hex, 4, 2));

    return $luminance > 150 ? '#052110' : '#ffffff';
}

/**
 * Validates a 6-digit hex color string with fallback.
 */
function hx(string $color): string {
    return preg_match('/^#[0-9a-fA-F]{6}$/', $color) ? $color : '#166534';
}

/**
 * Renders a project portfolio card with real photography and color palette strip.
 */
function wcard(array $project): string {
    $colors = array_map('hx', $project['colors'] ?? ['#166534']);
    $firstColor = $colors[0] ?? '#166534';

    $paletteHtml = '';
    foreach ($colors as $c) {
        $paletteHtml .= '<span style="background:' . $c . '"></span>';
    }

    $searchTerms = strtolower(implode(' ', [
        $project['name'] ?? '',
        $project['category'] ?? '',
        $project['type'] ?? '',
        $project['summary'] ?? ''
    ]));

    $imgSrc = !empty($project['image']) ? e($project['image']) : '';

    return '<article class="card work rv" data-c="' . e($project['category'] ?? '') . '" data-s="' . e($searchTerms) . '">'
         . '<div class="card-media">'
         . ($imgSrc ? '<img src="' . $imgSrc . '" alt="' . e($project['name'] ?? '') . '" loading="lazy" class="card-img">' : '')
         . '<span class="card-badge">' . e($project['category'] ?? '') . '</span>'
         . '</div>'
         . '<div class="strip" aria-hidden="true">' . $paletteHtml . '</div>'
         . '<div class="wb">'
         . '<b class="kind">' . e($project['type'] ?? '') . '</b>'
         . '<h3>' . e($project['name'] ?? '') . '</h3>'
         . '<p>' . e($project['summary'] ?? '') . '</p>'
         . '</div>'
         . '</article>';
}

/**
 * Renders a commercial product selling card with pricing, features checklist, and buy/order link.
 */
function pcard(array $product, bool $featured = false): string {
    $searchTerms = strtolower(implode(' ', array_filter([
        $product['name'] ?? '',
        $product['category'] ?? '',
        $product['badge'] ?? '',
        $product['price'] ?? '',
        $product['summary'] ?? '',
        implode(' ', $product['features'] ?? [])
    ])));

    $imgSrc = !empty($product['image']) ? e($product['image']) : '';
    $link = $product['link'] ?? '#';
    $isExternal = preg_match('#^https?://#i', $link);
    $href = $isExternal ? e($link) : u($link);
    $target = $isExternal ? ' target="_blank" rel="noopener"' : '';
    $linkLabel = !empty($product['link_label']) ? e($product['link_label']) : 'Order Now';

    $demoLink = $product['demo_link'] ?? (defined('STORE_URL') ? STORE_URL : 'https://event.meatsokogroup.com');
    $demoExternal = preg_match('#^https?://#i', $demoLink);
    $demoHref = $demoExternal ? e($demoLink) : u($demoLink);
    $demoTarget = $demoExternal ? ' target="_blank" rel="noopener"' : '';

    $featuresHtml = '';
    if (!empty($product['features']) && is_array($product['features'])) {
        $featuresHtml .= '<ul class="product-features">';
        foreach ($product['features'] as $feat) {
            $featuresHtml .= '<li><i class="fa fa-check-circle" aria-hidden="true"></i> ' . e($feat) . '</li>';
        }
        $featuresHtml .= '</ul>';
    }

    $icon = !empty($product['icon']) ? e($product['icon']) : 'shopping-bag';
    $badge = !empty($product['badge']) ? '<span class="product-badge">' . e($product['badge']) . '</span>' : '';

    return '<article class="card product rv' . ($featured ? ' featured-product' : '') . '" data-c="' . e($product['category'] ?? '') . '" data-s="' . e($searchTerms) . '">'
         . '<a href="' . $href . '"' . $target . ' class="card-media product-media" title="' . e($product['name'] ?? '') . '">'
         . ($imgSrc ? '<img src="' . $imgSrc . '" alt="' . e($product['name'] ?? '') . '" loading="lazy" class="card-img product-img">' : '<div class="product-fallback-icon"><i class="fa fa-' . $icon . '"></i></div>')
         . $badge
         . '<span class="product-cat-tag">' . e($product['category'] ?? 'Merchandise') . '</span>'
         . '</a>'
         . '<div class="product-body">'
         . '<h3 class="product-title"><a href="' . $href . '"' . $target . ' style="color:inherit;text-decoration:none;"><i class="fa fa-' . $icon . '" aria-hidden="true"></i> ' . e($product['name'] ?? '') . '</a></h3>'
         . '<p class="product-summary">' . e($product['summary'] ?? '') . '</p>'
         . $featuresHtml
         . '<div class="product-actions">'
         . '<a class="btn product-store-btn" href="' . $href . '"' . $target . '>'
         . '<i class="fa fa-external-link"></i> Live Store'
         . '</a>'
         . '</div>'
         . '</div>'
         . '</article>';
}

