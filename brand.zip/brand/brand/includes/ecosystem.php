<?php
/**
 * Shared "MeatSoko Ecosystem" Section
 * Renders the integrated agricultural value chain and member services.
 */
function ecosystem_section(): void {
    $eco = load('ecosystem');
    if (!$eco) {
        return;
    }
    $currentPillar = defined('ECO_PILLAR') ? ECO_PILLAR : '';
    ?>
    <div class="section-head" style="margin-top: 4rem;">
        <p class="section-tag">Network Architecture</p>
        <h2>Part of the MeatSoko Ecosystem</h2>
        <p class="section-desc"><?= e($eco['intro'] ?? '') ?></p>
    </div>

    <div class="pill rv" style="margin: 1.8rem 0; border-top-color: var(--tg);">
        <h3><i class="fa fa-key" aria-hidden="true"></i> One Membership, Comprehensive Access</h3>
        <p><?= e($eco['access']['text'] ?? '') ?></p>
    </div>

    <div class="grid three">
        <?php foreach ($eco['pillars'] ?? [] as $pillar): ?>
            <?php $isCurrent = ($pillar['name'] === $currentPillar); ?>
            <div class="pill rv<?= $isCurrent ? ' me' : '' ?>">
                <h3>
                    <i class="fa fa-<?= e($pillar['icon']) ?>" aria-hidden="true"></i>
                    <?= e($pillar['name']) ?>
                </h3>
                <?php if ($isCurrent): ?>
                    <b class="kind"><i class="fa fa-star"></i> Our Studio Role</b>
                <?php endif; ?>
                <ul class="ticks" style="margin: 0.8rem 0 0;">
                    <?php foreach ($pillar['items'] ?? [] as $item): ?>
                        <li><i class="fa fa-check"></i> <?= e($item) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (!empty($eco['marketplace_note']) || !empty($eco['external_services'])): ?>
        <p class="lead" style="margin-top: 2rem; font-size: 1.05rem;">
            <?= e($eco['marketplace_note'] ?? '') ?> <?= e($eco['external_services'] ?? '') ?>
        </p>
    <?php endif; ?>

    <div class="section-head" style="margin-top: 4.5rem;">
        <p class="section-tag">Value Flow</p>
        <h2>How an Idea Becomes a Finished Brand</h2>
        <p class="section-desc">The collaborative lifecycle from member inception to market launch.</p>
    </div>

    <div class="grid three">
        <?php foreach ($eco['flow'] ?? [] as $stage): ?>
            <div class="pill rv">
                <b class="kind">Stage <?= (int)$stage['step'] ?></b>
                <h3><?= e($stage['title']) ?></h3>
                <p><?= e($stage['text']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
}
