    </main>

    <footer class="foot">
        <div class="fwrap">
            <div class="foot-brand">
                <a class="logo foot-logo" href="<?= u('index') ?>">
                    <span class="tagmark" aria-hidden="true"></span>
                    <span><?= e(SITE_SHORT) ?></span>
                </a>
                <p class="foot-desc">
                    <?= e(SITE_TAG) ?>. Strategic identities, packaging architectures, and registered herd marks crafted for producers, butcheries, and processors.
                </p>
            </div>

            <nav class="foot-nav" aria-label="Footer Navigation">
                <?php foreach ($NAV as $slug => $item): 
                    $isExt = !empty($item[2]);
                    $href = $isExt ? $item[2] : u($slug);
                    $attrs = $isExt ? ' target="_blank" rel="noopener"' : '';
                ?>
                    <a href="<?= e($href) ?>"<?= $attrs ?>><?= e($item[0]) ?><?= $isExt ? ' <i class="fa fa-external-link" style="font-size:0.7em;"></i>' : '' ?></a>
                <?php endforeach; ?>
                <a href="api.php" title="Data API endpoint">API</a>
            </nav>

            <div class="fr">
                <a class="foot-mail" href="tel:<?= e(defined('SITE_PHONE') ? SITE_PHONE : '0715097128') ?>">
                    <i class="fa fa-phone" aria-hidden="true"></i> <?= e(defined('SITE_PHONE_DISPLAY') ? SITE_PHONE_DISPLAY : '0715 097 128') ?>
                </a>
                <a class="foot-mail" href="mailto:<?= e(SITE_EMAIL) ?>">
                    <i class="fa fa-envelope" aria-hidden="true"></i> <?= e(SITE_EMAIL) ?>
                </a>
                <a class="foot-mail" href="<?= e(defined('SITE_WHATSAPP') ? SITE_WHATSAPP : 'https://wa.me/254715097128') ?>" target="_blank" rel="noopener">
                    <i class="fa fa-whatsapp" aria-hidden="true"></i> WhatsApp Support
                </a>
                <span class="foot-loc" style="color:var(--mu); font-size:0.88rem;">
                    <i class="fa fa-map-marker" aria-hidden="true"></i> <?= e(defined('SITE_LOCATION') ? SITE_LOCATION : 'Nairobi, Kenya') ?>
                </span>
                <span class="copyright">&copy; <?= date('Y') ?> <?= e(SITE_SHORT) ?> &middot; MeatSoko Group. All rights reserved.</span>
            </div>
        </div>
    </footer>

    <nav class="bnav" aria-label="Mobile Bottom Navigation">
        <?php foreach ($BOT as $slug => $item): 
            $isExt = !empty($item[2]);
            $href = $isExt ? $item[2] : u($slug);
            $attrs = $isExt ? ' target="_blank" rel="noopener"' : ($page === $slug ? ' aria-current="page"' : '');
        ?>
            <a href="<?= e($href) ?>"<?= $attrs ?>>
                <span><i class="fa fa-<?= e($item[1]) ?>" aria-hidden="true"></i></span>
                <?= e($item[0]) ?>
            </a>
        <?php endforeach; ?>
    </nav>
</body>
</html>
