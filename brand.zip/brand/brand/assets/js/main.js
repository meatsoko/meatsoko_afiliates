/**
 * THE MSL BRAND GROUP - Core Interactions
 * Responsive navigation, theme switching, project filtering & smooth reveals.
 */
document.addEventListener('DOMContentLoaded', function () {
    const doc = document;
    const root = doc.documentElement;

    /* ==========================================================================
       1. Theme Toggle (Light / Dark)
       ========================================================================== */
    function toggleTheme() {
        const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
        root.dataset.theme = next;
        try {
            localStorage.setItem('theme', next);
        } catch (e) {}
    }

    doc.querySelectorAll('.theme-btn').forEach(function (btn) {
        btn.addEventListener('click', toggleTheme);
    });

    /* ==========================================================================
       2. Mobile Navigation Drawer
       ========================================================================== */
    const side = doc.getElementById('side');
    const veil = doc.getElementById('veil');
    const menuBtn = doc.getElementById('menuBtn');
    const closeBtn = doc.getElementById('closeBtn');

    function setMenuOpen(open) {
        doc.body.classList.toggle('open', open);
        if (menuBtn) {
            menuBtn.setAttribute('aria-expanded', String(open));
        }
        if (open && side) {
            const firstLink = side.querySelector('a');
            if (firstLink) firstLink.focus();
        }
    }

    if (menuBtn) {
        menuBtn.addEventListener('click', function () {
            setMenuOpen(true);
        });
    }
    if (closeBtn) {
        closeBtn.addEventListener('click', function () {
            setMenuOpen(false);
        });
    }
    if (veil) {
        veil.addEventListener('click', function () {
            setMenuOpen(false);
        });
    }

    doc.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && doc.body.classList.contains('open')) {
            setMenuOpen(false);
        }
    });

    if (side) {
        side.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                setMenuOpen(false);
            });
        });
    }

    /* ==========================================================================
       3. Header Scroll Glass Effect
       ========================================================================== */
    const topBar = doc.getElementById('top');
    function handleScroll() {
        if (topBar) {
            topBar.classList.toggle('scrolled', window.scrollY > 24);
        }
    }
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });

    /* ==========================================================================
       4. Work & Products Search & Category Filtering
       ========================================================================== */
    function setupFilter(containerId, inputId, noResultsId, resetBtnId) {
        const container = doc.getElementById(containerId);
        if (!container) return;
        const input = doc.getElementById(inputId);
        const noResults = doc.getElementById(noResultsId);
        const resetBtn = doc.getElementById(resetBtnId);
        const parentScope = container.closest('.page') || container.parentElement || doc;
        const chips = parentScope.querySelectorAll('.chip-btn');
        let currentCategory = 'all';
        const cards = container.querySelectorAll('.card');

        function applyFilter() {
            const query = input ? input.value.trim().toLowerCase() : '';
            let visibleCount = 0;

            cards.forEach(function (card) {
                const searchData = (card.dataset.s || '').toLowerCase();
                const cardCategory = card.dataset.c || '';

                const matchesQuery = !query || searchData.includes(query);
                const matchesCategory = currentCategory === 'all' || cardCategory === currentCategory;

                const isVisible = matchesQuery && matchesCategory;
                card.hidden = !isVisible;
                if (isVisible) {
                    visibleCount++;
                }
            });

            if (noResults) {
                noResults.hidden = visibleCount > 0;
            }
        }

        if (input) {
            input.addEventListener('input', applyFilter);
        }

        chips.forEach(function (btn) {
            btn.addEventListener('click', function () {
                currentCategory = btn.dataset.c || 'all';
                chips.forEach(function (c) {
                    c.classList.toggle('on', c === btn);
                });
                applyFilter();
            });
        });

        if (resetBtn) {
            resetBtn.addEventListener('click', function () {
                currentCategory = 'all';
                if (input) {
                    input.value = '';
                }
                chips.forEach(function (c) {
                    c.classList.toggle('on', (c.dataset.c || 'all') === 'all');
                });
                applyFilter();
            });
        }
    }

    setupFilter('projectsGrid', 'qn', 'noResults', 'resetFilterBtn');
    setupFilter('people', 'qn', 'noResults', 'resetFilterBtn');
    setupFilter('productsGrid', 'qp', 'noProductResults', 'resetProductFilterBtn');

    /* ==========================================================================
       5. Animated Number Statistics Counter
       ========================================================================== */
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function animateCounter(el) {
        const target = +el.dataset.count;
        const suffix = el.dataset.suffix || '';
        if (isNaN(target)) return;

        if (prefersReducedMotion) {
            el.textContent = target + suffix;
            return;
        }

        const startTime = performance.now();
        const duration = 1200;

        function step(now) {
            const progress = Math.min((now - startTime) / duration, 1);
            // Cubic ease-out
            const current = Math.round(target * (1 - Math.pow(1 - progress, 3)));
            el.textContent = current + suffix;
            if (progress < 1) {
                requestAnimationFrame(step);
            }
        }
        requestAnimationFrame(step);
    }

    /* ==========================================================================
       6. Scroll Reveal Observer
       ========================================================================== */
    if ('IntersectionObserver' in window) {
        const revealObserver = new IntersectionObserver(
            function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('in');
                        const counter = entry.target.querySelector('[data-count]');
                        if (counter) {
                            animateCounter(counter);
                        }
                        revealObserver.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.12 }
        );

        doc.querySelectorAll('.rv').forEach(function (el, index) {
            el.style.transitionDelay = (index % 4) * 75 + 'ms';
            revealObserver.observe(el);
        });
    } else {
        // Fallback for older browsers
        doc.querySelectorAll('.rv').forEach(function (el) {
            el.classList.add('in');
            const counter = el.querySelector('[data-count]');
            if (counter) {
                counter.textContent = (counter.dataset.count || '0') + (counter.dataset.suffix || '');
            }
        });
    }
});
