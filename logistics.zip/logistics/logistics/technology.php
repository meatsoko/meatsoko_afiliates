<?php require __DIR__.'/includes/functions.php';
$page='technology';$pageTitle='Technology';$tc=load('tech');require 'includes/header.php';?>
<section class="wrap page"><h1>Technology for efficiency</h1><p class="lead">Innovation that gives you visibility, protects quality and removes delays across the supply chain.</p>
<div class="grid three"><?php foreach($tc as $t)echo '<div class="pill rv"><h3><i class="fa-solid fa-'.e($t['icon']).'"></i> '.e($t['title']).'</h3><p>'.e($t['text']).'</p></div>';?></div></section>
<section class="cta"><div class="wrap rv"><h2>See how it fits your supply chain</h2><a class="btn dark" href="<?=u('contact')?>">Talk to our team</a></div></section>
<?php require 'includes/footer.php';
