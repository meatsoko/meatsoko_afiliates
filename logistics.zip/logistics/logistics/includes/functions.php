<?php
require_once __DIR__.'/../config.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
const IMG=[
 'hero'=>'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=1800&q=80',
 'about'=>'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=80',
 'herd'=>'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=1200&q=80',
 'cows'=>'https://images.unsplash.com/photo-1596733430284-f7437764b1a9?auto=format&fit=crop&w=1200&q=80',
 'goats'=>'https://images.unsplash.com/photo-1524024973431-2ad916746881?auto=format&fit=crop&w=1200&q=80',
 'goat_pasture'=>'https://images.unsplash.com/photo-1524024973431-2ad916746881?auto=format&fit=crop&w=1200&q=80'];
function partner($c=''){$x=PARTNER_URL;$ext=preg_match('#^https?://#i',$x);
return '<a class="btn pulse '.e($c).'" href="'.($ext?e($x):u($x)).'"'.($ext?' target="_blank" rel="noopener"':'').'><i class="fa-solid fa-handshake"></i> '.e(PARTNER_LABEL).' <i class="fa-solid fa-arrow-right go"></i></a>';}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function load($n){$f=__DIR__."/../data/$n.json";return is_file($f)?(json_decode(file_get_contents($f),true)?:[]):[];}
function save($n,$d){file_put_contents(__DIR__."/../data/$n.json",json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);}
function u($f){if($f==='index')return CLEAN_URLS?'./':'index.php';return CLEAN_URLS?$f:$f.'.php';}
function csrf(){if(empty($_SESSION['t']))$_SESSION['t']=bin2hex(random_bytes(16));return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">';}
function ok(){return isset($_POST['t'],$_SESSION['t'])&&hash_equals($_SESSION['t'],$_POST['t']);}
function go($f){header('Location: '.u($f));exit;}
function flash(){$m=$_SESSION['flash']??'';unset($_SESSION['flash']);return $m?'<p class="flash" role="status">'.e($m).'</p>':'';}
