</main>
<footer class="foot"><div class="fwrap"><div><b><?=e(SITE_SHORT)?></b><p><?=e(SITE_TAG)?>.</p><small><i class="fa-solid fa-location-dot"></i> <?=e(SITE_ADDRESS)?></small></div>
<nav aria-label="Footer"><?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'">'.$n[0].'</a>';?><a href="api.php">API</a></nav>
<div class="fr"><a href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE_DISPLAY)?></a><a href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a><small>&copy; <?=date('Y')?> <?=e(SITE_SHORT)?></small></div></div></footer>
<nav class="bnav" aria-label="Mobile"><?php foreach($BOT as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?></nav></body></html>
