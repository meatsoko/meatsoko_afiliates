<?php
// Shared Products & Deliveries section. Data loaded dynamically from data/products.json
require_once __DIR__.'/functions.php';

function render_products_section($limit = 0, $title = 'Meat, Merchandise, Farm Inputs & Deliveries', $lead = 'Explore quality fresh meat, organic livestock manure fertilizer, official MeatSoko merchandise (hoodies, t-shirts, shoes, cups), and book cold deliveries directly on meatsokogroup.com.') {
    $products = load('products');
    if (empty($products)) return;
    if ($limit > 0) {
        $products = array_slice($products, 0, $limit);
    }
?>
<section class="wrap page-products" id="products" style="margin-top:3.5rem;margin-bottom:3.5rem;">
  <div class="sec-head rv" style="text-align:center;max-width:820px;margin:0 auto 2.5rem;">
    <p class="chip" style="margin:0 auto 0.75rem;"><i class="fa-solid fa-store"></i> MeatSoko Group Store &amp; Deliveries</p>
    <h2 style="font-size:2.1rem;margin-bottom:0.75rem;color:var(--tx);"><?=e($title)?></h2>
    <p class="lead" style="margin:0 auto 1.25rem;color:var(--mu);font-size:1.05rem;"><?=e($lead)?></p>
    <div style="display:flex;justify-content:center;gap:0.75rem;flex-wrap:wrap;margin-top:0.75rem;">
      <a class="btn" href="https://meatsokogroup.com" target="_blank" rel="noopener" style="font-size:0.95rem;padding:0.65rem 1.4rem;">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> Visit meatsokogroup.com
      </a>
      <a class="btn alt" href="<?=u('contact')?>" style="font-size:0.95rem;padding:0.65rem 1.4rem;border:2px solid var(--ac) !important;">
        <i class="fa-solid fa-truck-fast"></i> Delivery &amp; Bulk Quotes
      </a>
    </div>
  </div>

  <div class="grid three">
    <?php foreach ($products as $p):
        $storeUrl = !empty($p['link']) ? $p['link'] : 'https://meatsokogroup.com';
        $btnLabel = !empty($p['btn_text']) ? $p['btn_text'] : 'Order on MeatSokoGroup.com';
        $imgUrl = !empty($p['image']) ? $p['image'] : 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=800&q=80';
    ?>
    <article class="pill rv prod-item" id="<?=e($p['slug'] ?? $p['id'])?>" style="display:flex;flex-direction:column;justify-content:space-between;position:relative;padding:1.4rem;border-radius:14px;background:var(--sf);border:2px solid var(--ln-soft);border-top:6px solid var(--tg);transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease;">
      <div>
        <!-- Real Internet Product Image -->
        <div style="position:relative;width:100%;height:210px;border-radius:10px;overflow:hidden;margin-bottom:1.1rem;background:var(--sf-subtle);border:1px solid var(--ln-soft);">
          <img src="<?=e($imgUrl)?>" alt="<?=e($p['name'])?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease;">
          <?php if (!empty($p['badge'])): ?>
            <span class="chip" style="position:absolute;top:0.75rem;right:0.75rem;font-size:0.72rem;padding:0.25rem 0.65rem;text-transform:uppercase;letter-spacing:0.5px;box-shadow:0 4px 12px rgba(0,0,0,0.2);"><?=e($p['badge'])?></span>
          <?php endif; ?>
        </div>

        <div style="margin-bottom:0.75rem;">
          <small style="color:var(--mu);font-weight:700;text-transform:uppercase;letter-spacing:0.5px;display:block;font-size:0.78rem;margin-bottom:0.25rem;"><?=e($p['category'] ?? 'Product')?></small>
          <h3 style="margin:0;font-size:1.25rem;line-height:1.3;color:var(--tx);font-weight:700;"><?=e($p['name'])?></h3>
        </div>

        <p style="color:var(--tx);font-size:0.95rem;line-height:1.55;margin-bottom:1.1rem;opacity:0.9;"><?=e($p['summary'])?></p>

        <?php if (!empty($p['highlights'])): ?>
          <ul class="ticks" style="margin-bottom:1.5rem;font-size:0.88rem;line-height:1.5;display:grid;gap:0.45rem;">
            <?php foreach ($p['highlights'] as $hl): ?>
              <li style="display:flex;align-items:flex-start;gap:0.5rem;color:var(--tx);"><i class="fa-solid fa-check" style="color:var(--tg);margin-top:0.25rem;flex-shrink:0;"></i> <span><?=e($hl)?></span></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>

      <div style="margin-top:auto;display:flex;flex-direction:column;gap:0.55rem;padding-top:1rem;border-top:1px solid var(--ln-soft);">
        <!-- Primary Action: Open meatsokogroup.com -->
        <a class="btn" href="<?=e($storeUrl)?>" target="_blank" rel="noopener" style="text-align:center;display:flex;align-items:center;justify-content:center;gap:0.5rem;padding:0.75rem 1rem;font-size:0.95rem;text-decoration:none;font-weight:700;">
          <i class="fa-solid fa-arrow-up-right-from-square"></i> <?=e($btnLabel)?>
        </a>

        <!-- Store Link Reference -->
        <a href="https://meatsokogroup.com" target="_blank" rel="noopener" style="text-align:center;font-size:0.82rem;color:var(--tg);font-weight:700;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:0.35rem;">
          <i class="fa-solid fa-globe"></i> Open meatsokogroup.com &rarr;
        </a>

        <?php 
          $waMsg = rawurlencode('Hello MeatSoko Logistics, I would like to order/inquire about: ' . $p['name'] . ' via meatsokogroup.com');
        ?>
        <a href="https://wa.me/254715097128?text=<?=$waMsg?>" target="_blank" rel="noopener" style="text-align:center;font-size:0.82rem;color:var(--mu);font-weight:600;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:0.4rem;padding:0.15rem 0;">
          <i class="fa-brands fa-whatsapp" style="font-size:1rem;color:var(--ac);"></i> Order via WhatsApp
        </a>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
</section>
<?php
}
