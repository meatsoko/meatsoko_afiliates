<?php
require_once __DIR__.'/functions.php';
$page=$page??'';$pageTitle=$pageTitle??'End-to-end supply chains for meat and livestock';
$NAV=['index'=>['Home','house'],'services'=>['Services','truck-fast'],'coverage'=>['Coverage','earth-africa'],'technology'=>['Technology','microchip'],'about'=>['About','circle-info'],'contact'=>['Contact','envelope']];
$BOT=array_intersect_key($NAV,array_flip(['index','services','coverage','technology','contact']));
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($pageTitle)?> | <?=e(SITE_SHORT)?></title>
<meta name="description" content="<?=e(SITE_SHORT)?>: meat and livestock logistics based in Kiamaiko, Nairobi. End-to-end supply chain solutions for cattle, goats and meat.">
<script>try{document.documentElement.dataset.theme=localStorage.theme||(window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;800&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
<link rel="stylesheet" href="assets/css/style.css?v=<?=filemtime(__DIR__.'/../assets/css/style.css')?>">
<style>
/* LIGHT THEME (DEFAULT) */
:root, [data-theme="light"] {
  --bg: #ffffff;
  --sf: #ffffff;
  --sf-subtle: #f0fdf4;
  --tx: #0b3d1c;
  --mu: #15803d;
  --ln: #15803d;
  --ln-soft: #bbf7d0;
  --ac: #15803d;
  --tg: #dc2626;
  --dk: #0b3d1c;
  --gl: rgba(255, 255, 255, 0.98);
  --sh: 0 10px 30px rgba(21, 128, 61, 0.12);
  --rc: 220, 38, 38;
}

/* DARK THEME */
[data-theme="dark"] {
  --bg: #07190d;
  --sf: #0d2817;
  --sf-subtle: #133821;
  --tx: #f0fdf4;
  --mu: #86efac;
  --ln: #166534;
  --ln-soft: #14532d;
  --ac: #22c55e;
  --tg: #ef4444;
  --dk: #030c06;
  --gl: rgba(13, 40, 23, 0.96);
  --sh: 0 10px 30px rgba(0, 0, 0, 0.55);
  --rc: 239, 68, 68;
}

body { background: var(--bg) !important; color: var(--tx) !important; transition: background .25s ease, color .25s ease; }
h1, h2, h3 { color: var(--tx) !important; }

/* THEME TOGGLE BUTTON STYLES */
.theme-btn .t-sun { display: none; }
.theme-btn .t-moon { display: inline-block; }
[data-theme="dark"] .theme-btn .t-sun { display: inline-block !important; color: #facc15; }
[data-theme="dark"] .theme-btn .t-moon { display: none !important; }

.hero { display: flex !important; flex-direction: column !important; justify-content: space-between !important; align-items: center !important; text-align: center !important; min-height: 88vh !important; }
.hwrap { margin: auto auto !important; max-width: 960px !important; text-align: center !important; display: flex !important; flex-direction: column !important; align-items: center !important; padding: 7.5rem 5vw 2.5rem !important; }
.hero h1, .hwrap h1 { max-width: 24ch !important; margin: 0 auto .6em !important; text-align: center !important; color: #ffffff !important; }
.hero .lead, .hwrap .lead { max-width: 65ch !important; margin: 0 auto 2rem !important; text-align: center !important; color: #ffffff !important; }
.hero-btns { display: flex !important; gap: 1rem !important; justify-content: center !important; align-items: center !important; flex-wrap: wrap !important; margin: 0 auto !important; }
.ticker { width: 100% !important; margin-top: auto !important; }
.btn, button.btn { background: #dc2626 !important; color: #ffffff !important; border: 2px solid #dc2626 !important; font-weight: 700 !important; }
.btn:hover { background: #b91c1c !important; border-color: #b91c1c !important; color: #ffffff !important; }
.btn.dark { background: var(--ac) !important; color: #ffffff !important; border: 2px solid #ffffff !important; }
.btn.dark:hover { background: #dc2626 !important; border-color: #dc2626 !important; color: #ffffff !important; }
.btn.alt { background: transparent !important; color: #ffffff !important; border: 2px solid #ffffff !important; }
.btn.alt:hover { background: #ffffff !important; color: #0b3d1c !important; }
.tagmark { background: #dc2626 !important; }
.tagmark:after { background: #ffffff !important; }
.dnav a { color: var(--tx) !important; font-weight: 600 !important; }
.dnav a:hover { background: var(--ln-soft) !important; color: var(--tx) !important; }
.dnav a[aria-current], .side a[aria-current], .bnav a[aria-current] { background: #dc2626 !important; color: #ffffff !important; font-weight: 700 !important; }
.top { background: var(--gl) !important; border: 2px solid var(--ac) !important; }
.top .logo { color: var(--tx) !important; }
.top .logo small { color: var(--mu) !important; font-weight: 700 !important; }
.cta { background: var(--ac) !important; color: #ffffff !important; border-top: 4px solid #dc2626 !important; border-bottom: 4px solid #dc2626 !important; }
.cta h2 { color: #ffffff !important; }
.cta .btn.dark { background: #dc2626 !important; border: 2px solid #ffffff !important; color: #ffffff !important; }
.ticker { background: var(--ac) !important; color: #ffffff !important; border-top: 2px solid #ffffff !important; border-bottom: 2px solid #ffffff !important; }
.ticker i, .ticker em, .ticker span { color: #ffffff !important; font-weight: 800 !important; }
.stats b { color: #dc2626 !important; }
.stats i { color: var(--ac) !important; }
.stats span { color: var(--tx) !important; font-weight: 600 !important; }
.foot { background: var(--dk) !important; color: #ffffff !important; border-top: 4px solid #dc2626 !important; }
.foot b, .foot p, .foot small, .foot a { color: #ffffff !important; }
.foot a:hover { color: #dc2626 !important; }
.pill { background: var(--sf) !important; border: 2px solid var(--ln-soft) !important; border-top: 6px solid #dc2626 !important; }
.pill h3 { color: var(--tx) !important; }
.pill h3 i { color: #dc2626 !important; }
.pill p { color: var(--tx) !important; }
.pill b, .kind { color: #dc2626 !important; font-weight: 700 !important; }
.svc { background: var(--sf) !important; border: 2px solid var(--ln-soft) !important; border-left: 6px solid #dc2626 !important; }
.svc h2 { color: var(--tx) !important; }
.svc .big { color: var(--ac) !important; }
.svc p { color: var(--tx) !important; }
.ticks i, .ticks li::marker { color: #dc2626 !important; }
.ticks li { color: var(--tx) !important; font-weight: 500 !important; }
.chip { background: #dc2626 !important; color: #ffffff !important; border: 2px solid #ffffff !important; font-weight: 700 !important; }
.flash { background: var(--sf) !important; border: 2px solid #dc2626 !important; border-left: 6px solid #dc2626 !important; color: #dc2626 !important; font-weight: 700 !important; }
.msg { border-left: 4px solid #dc2626 !important; color: var(--tx) !important; }
input, textarea, select { background: var(--sf) !important; border: 2px solid var(--ln) !important; color: var(--tx) !important; font-weight: 500 !important; }
input:focus, textarea:focus, select:focus { border-color: #dc2626 !important; outline: 3px solid #dc2626 !important; }
label { color: var(--tx) !important; font-weight: 600 !important; }
.steps li { background: var(--sf) !important; border: 2px solid var(--ln-soft) !important; }
.steps li:before { background: #dc2626 !important; color: #ffffff !important; border: 2px solid #ffffff !important; font-weight: 800 !important; }
.steps b { color: var(--tx) !important; font-weight: 700 !important; }
.steps span { color: var(--mu) !important; }
.tags span { border: 2px solid var(--ln) !important; color: var(--mu) !important; background: var(--sf) !important; font-weight: 700 !important; }
.side { background: var(--sf) !important; border-left: 3px solid var(--ac) !important; }
.side a { color: var(--tx) !important; font-weight: 600 !important; }
.side a:hover { background: var(--ln-soft) !important; }
.bnav { background: var(--gl) !important; border: 2px solid var(--ac) !important; }
.bnav a { color: var(--tx) !important; font-weight: 600 !important; }
.card { background: var(--sf) !important; border: 2px solid var(--ln-soft) !important; }
.card:hover { border-color: var(--ac) !important; }
.card p { color: var(--tx) !important; }
.ic { background: var(--sf) !important; color: var(--ac) !important; border: 2px solid var(--ac) !important; }
.ic:hover { border-color: #dc2626 !important; background: #dc2626 !important; color: #ffffff !important; }
</style>
<script src="assets/js/main.js" defer></script></head><body>
<header class="top" id="top"><a class="logo" href="<?=u('index')?>"><span class="tagmark"></span><span><?=e(SITE_SHORT)?><small><?=e(SITE_TAG)?></small></span></a>
<nav class="dnav" aria-label="Main"><?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'>'.$n[0].'</a>';?></nav>
<div class="acts">
  <button class="ic theme-btn" id="themeBtn" aria-label="Toggle color theme" title="Toggle theme (Light / Dark)"><i class="fa-solid fa-moon t-moon" aria-hidden="true"></i><i class="fa-solid fa-sun t-sun" aria-hidden="true"></i></button>
  <button class="ic menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="side"><i class="fa-solid fa-bars"></i></button>
</div></header>
<div class="veil" id="veil"></div>
<aside class="side" id="side" aria-label="Menu"><div class="sidehead"><b><?=e(SITE_SHORT)?></b><button class="ic" id="closeBtn" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button></div>
<?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?>
<div class="sidenote" style="margin-top:auto;display:grid;gap:.5rem;padding:.5rem 0">
  <button class="theme-btn" style="display:flex;align-items:center;justify-content:center;gap:.6rem;width:100%;padding:.65rem .9rem;border-radius:999px;border:2px solid var(--ac);background:var(--sf);color:var(--tx);font-weight:700;cursor:pointer;">
    <i class="fa-solid fa-moon t-moon" aria-hidden="true"></i>
    <i class="fa-solid fa-sun t-sun" aria-hidden="true"></i>
    <span>Switch Light / Dark</span>
  </button>
  <a href="tel:<?=e(SITE_PHONE)?>" style="display:flex;align-items:center;gap:.5rem;padding:.2rem 0;color:inherit;text-decoration:none"><i class="fa-solid fa-phone" style="color:var(--ac)"></i> <?=e(SITE_PHONE_DISPLAY)?></a>
  <a href="mailto:<?=e(SITE_EMAIL)?>" style="display:flex;align-items:center;gap:.5rem;padding:.2rem 0;color:inherit;text-decoration:none;word-break:break-all"><i class="fa-solid fa-envelope" style="color:var(--ac)"></i> <?=e(SITE_EMAIL)?></a>
  <small style="color:var(--mu)"><i class="fa-solid fa-location-dot" style="color:var(--ac)"></i> <?=e(SITE_ADDRESS)?></small>
</div></aside><main>
