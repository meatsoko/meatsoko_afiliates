<?php
// === EDIT THESE BEFORE GOING LIVE ===
const SITE_SHORT = 'MSL LOGISTICS';
const SITE_TAG   = 'Meat and livestock logistics company';
const SITE_EMAIL = 'info@meatsokogroup.com';   // quote requests are emailed here
const SITE_PHONE = '0715097128';              // primary contact phone
const SITE_PHONE_DISPLAY = '0715 097 128';    // formatted display
const SITE_PHONE_INTL    = '+254 715 097 128';// international format
const SITE_LOCATION      = 'Kiamaiko, Nairobi'; // primary location / hub
const SITE_ADDRESS       = 'Kiamaiko, Nairobi, Kenya';
const ECO_PILLAR    = 'Logistics';   // this company's place in the MeatSoko ecosystem
const PARTNER_URL   = 'contact';       // page name (e.g. 'contact') or a full link (https://...)
const PARTNER_LABEL = 'Partner with us';
const CLEAN_URLS = true;                 // set false if your host has no mod_rewrite

