(function(){
var d=document;
function toggleTheme(){
  var r=d.documentElement;
  var cur=r.dataset.theme||(window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
  var next=cur==='dark'?'light':'dark';
  r.dataset.theme=next;
  try{localStorage.setItem('theme',next);}catch(e){}
}
d.querySelectorAll('.theme-btn').forEach(function(b){b.onclick=toggleTheme});

var side=d.getElementById('side'),veil=d.getElementById('veil'),mb=d.getElementById('menuBtn');
function menu(o){d.body.classList.toggle('open',o);if(mb)mb.setAttribute('aria-expanded',o);if(o&&side)side.querySelector('a').focus()}
if(mb)mb.onclick=function(){menu(true)};
var cb=d.getElementById('closeBtn');if(cb)cb.onclick=function(){menu(false)};
if(veil)veil.onclick=function(){menu(false)};
d.addEventListener('keydown',function(e){if(e.key==='Escape')menu(false)});
if(side)side.querySelectorAll('a').forEach(function(a){a.onclick=function(){menu(false)}});
var top=d.getElementById('top');function sc(){if(top)top.classList.toggle('scrolled',scrollY>20)}sc();addEventListener('scroll',sc,{passive:true});
var q=d.getElementById('q');if(q)q.oninput=function(){var v=q.value.toLowerCase();d.querySelectorAll('#t tbody tr').forEach(function(x){x.hidden=!x.textContent.toLowerCase().includes(v)})};
var qs=d.getElementById('qs');if(qs)qs.oninput=function(){var v=qs.value.toLowerCase();d.querySelectorAll('#cards .card').forEach(function(c){c.hidden=!c.dataset.s.includes(v)})};
var lb=d.getElementById('lb');if(lb)d.querySelectorAll('.gal img').forEach(function(i){i.onclick=function(){lb.querySelector('img').src=i.src;lb.querySelector('p').textContent=i.alt;lb.showModal()}});
if(lb)lb.onclick=function(e){if(e.target===lb)lb.close()};
var qn=d.getElementById('qn');if(qn){var cat='all';var ap=function(){var v=qn.value.toLowerCase();d.querySelectorAll('#people .card').forEach(function(c){c.hidden=!(c.dataset.s.includes(v)&&(cat==='all'||c.dataset.c===cat))})};qn.oninput=ap;d.querySelectorAll('.chip-btn').forEach(function(b){b.onclick=function(){cat=b.dataset.c;d.querySelectorAll('.chip-btn').forEach(function(x){x.classList.toggle('on',x===b)});ap()}})}
var still=matchMedia('(prefers-reduced-motion:reduce)').matches;
function count(el){var n=+el.dataset.count,s=performance.now();if(still){el.textContent=n;return}
(function f(t){var p=Math.min((t-s)/1200,1);el.textContent=Math.round(n*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)})(s)}
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');var c=e.target.querySelector('[data-count]');if(c)count(c);io.unobserve(e.target)}})},{threshold:.15});
d.querySelectorAll('.rv').forEach(function(el,i){el.style.transitionDelay=(i%4)*80+'ms';io.observe(el)});
})();
