MSL LOGISTICS - PHP website (PHP 7.4+, no database, no login). 6 pages: Home, Services, Coverage, Technology, About, Contact (quote request).
1. Upload everything to public_html.
2. Edit config.php: name, SITE_EMAIL (quote requests are emailed here), CLEAN_URLS.
3. Make data/ writable (755/775) so requests are saved to data/messages.json.
4. Edit content in data/*.json: services, coverage (EDIT to match your real regions and lanes), tech, team, products (fresh meat, organic fertilizer, hoodies, t-shirts, shoes, cups, express and haulage deliveries linked to meatsokogroup.com).
5. Replace images in includes/functions.php (IMG).
Do not publish fleet sizes, volumes or coverage you cannot back up.

UPDATE: MeatSoko ecosystem section (About page) reads data/ecosystem.json. 'Partner with us' button: set PARTNER_URL / PARTNER_LABEL in config.php.
API: api.php returns the site's content as JSON (see comments at the top of api.php). Messages and subscribers are never exposed.
