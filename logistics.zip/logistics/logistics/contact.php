<?php require __DIR__.'/includes/functions.php';
$sv=load('services');$C=['Live cattle','Sheep and goats','Camels','Chilled meat','Frozen meat','Other'];$M=['Road livestock haulier','Cold chain / refrigerated','Air freight','Multimodal / not sure'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 $n=trim($_POST['name']??'');$m=trim($_POST['email']??'');
 if(ok()&&($_POST['website']??'')===''&&$n&&filter_var($m,FILTER_VALIDATE_EMAIL)){
  $d=['date'=>date('Y-m-d H:i'),'name'=>$n,'email'=>$m];foreach(['org','phone','service','cargo','mode','from','to','msg'] as $k)$d[$k]=trim($_POST[$k]??'');
  $a=load('messages');$a[]=$d;save('messages',$a);
  @mail(SITE_EMAIL,"Quote request from $n","Name: $n ($d[org])\nEmail: $m\nPhone: $d[phone]\nService: $d[service]\nCargo: $d[cargo]\nMode: $d[mode]\nRoute: $d[from] to $d[to]\n\n$d[msg]","Reply-To: $m");
  $_SESSION['flash']='Thanks. We have your request and will reply within one working day.';
 }else $_SESSION['flash']='Please enter your name and a valid email.';
 go('contact');}
$sel=$_GET['service']??'';
$prodSlug=$_GET['product']??'';
$prods=load('products');
$selectedProd=null;
if($prodSlug){
 foreach($prods as $p){
  if(($p['slug']??'')===$prodSlug||($p['id']??'')===$prodSlug){
   $selectedProd=$p;
   break;
  }
 }
}
$page='contact';$pageTitle=$selectedProd?'Order: '.$selectedProd['name'].' | Contact':'Contact & Quote';require 'includes/header.php';?>
<section class="wrap page"><h1>Contact Us &amp; Inquiries</h1><p class="lead">Reach out to our operations team in Kiamaiko, Nairobi for logistics services, product orders, and deliveries.</p><?=flash()?>
<div class="two" style="margin-top:2rem">
  <div>
    <div class="pill rv" style="margin-bottom:1.2rem">
      <h3><i class="fa-solid fa-location-dot"></i> Central Hub & Office</h3>
      <p><b><?=e(SITE_ADDRESS)?></b></p>
      <p style="margin-top:.4rem">Strategically located at East Africa's central livestock and meat trade nerve centre in Kiamaiko, Nairobi.</p>
    </div>
    <div class="pill rv" style="margin-bottom:1.2rem">
      <h3><i class="fa-solid fa-phone"></i> Direct Telephone</h3>
      <p><a href="tel:<?=e(SITE_PHONE)?>" style="font-size:1.25rem;font-weight:700;text-decoration:none"><i class="fa-solid fa-phone-volume"></i> <?=e(SITE_PHONE_DISPLAY)?></a></p>
      <p style="margin-top:.4rem">Call or reach us on WhatsApp: <a href="https://wa.me/254715097128" target="_blank" rel="noopener"><?=e(SITE_PHONE_INTL)?></a></p>
    </div>
    <div class="pill rv" style="margin-bottom:1.2rem">
      <h3><i class="fa-solid fa-envelope"></i> Email Inquiries</h3>
      <p><a href="mailto:<?=e(SITE_EMAIL)?>" style="font-size:1.1rem;font-weight:700"><?=e(SITE_EMAIL)?></a></p>
      <p style="margin-top:.4rem">For logistics bookings, corporate partnerships, and ecosystem inquiries.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-clock"></i> Operations & Dispatch</h3>
      <p><b>Livestock Intake:</b> 24/7 round-the-clock clearance</p>
      <p><b>Customer Support:</b> Monday &ndash; Saturday, 7:00 AM &ndash; 7:00 PM</p>
    </div>
  </div>

  <div class="pill rv">
    <?php if($selectedProd): ?>
      <div style="background:#f0fdf4;border:2px solid #15803d;border-radius:8px;padding:.85rem;margin-bottom:1.2rem;">
        <p style="margin:0;font-weight:700;color:#0b3d1c;font-size:1.05rem;"><i class="fa-solid fa-cart-shopping" style="color:#dc2626"></i> Selected Product: <span style="color:#dc2626;"><?=e($selectedProd['name'])?></span></p>
        <small style="color:#15803d;display:block;margin-top:.3rem;font-weight:600;">Fill in your details below to confirm your order and delivery arrangements, or order directly online at <a href="https://meatsokogroup.com" target="_blank" rel="noopener" style="color:#dc2626;text-decoration:underline;font-weight:700;">meatsokogroup.com</a>.</small>
      </div>
    <?php endif; ?>
    <h2 style="font-size:1.4rem;margin-bottom:1rem"><i class="fa-solid fa-<?=($selectedProd?'cart-shopping':'file-invoice-dollar')?>"></i> <?=($selectedProd?'Place Product Order / Inquiry':'Request a Shipping Quote')?></h2>
    <form method="post"><?=csrf()?><label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label><label>Company (optional)<input name="org"></label><label>Phone<input name="phone" placeholder="e.g. 0715097128"></label>
    <label>Service or Product<select name="service"><option value="">Not sure yet</option>
    <?php if(!empty($prods)): ?><optgroup label="Products, Merchandise & Deliveries"><?php foreach($prods as $p)echo '<option value="prod-'.e($p['slug']).'"'.(($prodSlug===$p['slug']||$sel===$p['slug'])?' selected':'').'>'.e($p['name']).'</option>';?></optgroup><?php endif; ?>
    <optgroup label="Logistics Services"><?php foreach($sv as $s)echo '<option value="'.e($s['slug']).'"'.($sel===$s['slug']&&!$selectedProd?' selected':'').'>'.e($s['title']).'</option>';?></optgroup>
    </select></label>
    <label>Cargo / Category<select name="cargo"><?php foreach($C as $c)echo '<option>'.e($c).'</option>';?><option <?=($selectedProd?'selected':'')?>>Meat, Merchandise, Fertilizer & Deliveries (meatsokogroup.com)</option></select></label><label>Transport / Delivery mode<select name="mode"><?php foreach($M as $c)echo '<option>'.e($c).'</option>';?><option <?=($selectedProd?'selected':'')?>>Cold-chain delivery / Courier dispatch</option></select></label>
    <label>Delivery location or route<input name="from" placeholder="e.g. Kiamaiko Nairobi or delivery address" value="<?=(!empty($selectedProd)?'Nairobi Hub / Delivery':'')?>"></label><label>Destination city / county<input name="to" placeholder="e.g. Nairobi / Mombasa / Nakuru / Export"></label>
    <label>Order quantity &amp; details<textarea name="msg" rows="4" placeholder="Number of units, head of livestock, delivery address, questions..."><?=e($selectedProd?'I am placing an order for: '.$selectedProd['name'].'. Please get back to me with delivery and payment details.':'')?></textarea></label><input name="website" value="" style="display:none" tabindex="-1" autocomplete="off"><button class="btn"><i class="fa-solid fa-<?=($selectedProd?'check':'paper-plane')?>"></i> <?=($selectedProd?'Confirm product order':'Request quote')?></button></form>
    <p style="margin-top:.8rem"><small>Quotes and orders are processed promptly by our Kiamaiko operations and dispatch team. Your details are used strictly to reply to you.</small></p>
  </div>
</div>
</section>
<?php require 'includes/footer.php';
