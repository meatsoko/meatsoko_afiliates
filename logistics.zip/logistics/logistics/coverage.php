<?php require __DIR__.'/includes/functions.php';
$page='coverage';$pageTitle='Coverage';$cv=load('coverage');require 'includes/header.php';?>
<section class="wrap page"><h1>Regional & Global Coverage</h1><p class="lead">From pastoral rangelands across East Africa to our central hub in Kiamaiko, Nairobi and destination markets worldwide, we ensure humane, compliant and timely livestock logistics.</p>
<div class="grid three"><?php foreach($cv as $r){echo '<div class="pill rv"><h3><i class="fa-solid fa-'.e($r['icon']).'"></i> '.e($r['region']).'</h3><p>'.e($r['text']).'</p><p class="tags">';foreach($r['modes'] as $m)echo '<span>'.e($m).'</span>';echo '</p></div>';}?></div>

<div class="split" style="margin-top:3.5rem">
  <img class="rv" loading="lazy" alt="Cattle herd grazing in pasture" src="<?=IMG['cows']?>">
  <div class="rv">
    <h2>Cattle & Cow Supply Chains</h2>
    <p>We coordinate dedicated cattle transport from pastoral rangelands and breeding ranches across Kenya, Uganda, Tanzania, and Ethiopia. Each movement prioritizes veterinary compliance, regular hydration stops, and humane animal handling.</p>
    <ul class="ticks">
      <li><i class="fa-solid fa-check"></i> Verified movement permits and county veterinary clearances</li>
      <li><i class="fa-solid fa-check"></i> Specialized multi-deck livestock hauliers engineered for animal comfort</li>
      <li><i class="fa-solid fa-check"></i> Direct delivery to feedlots, abattoirs, and processing plants</li>
    </ul>
    <a class="btn" href="<?=u('contact')?>"><i class="fa-solid fa-paper-plane"></i> Book cattle transit</a>
  </div>
</div>

<div class="split" style="margin-top:3.5rem">
  <div class="rv">
    <h2>Goat & Sheep Logistics Hub &mdash; Kiamaiko, Nairobi</h2>
    <p>Centred in Kiamaiko, Nairobi &mdash; East Africa's largest and most vibrant goat livestock trade hub &mdash; we provide unrivaled local expertise and seamless logistics for live goats, sheep, and fresh carcasses.</p>
    <ul class="ticks">
      <li><i class="fa-solid fa-check"></i> Daily intake and dispatch routes through the Kiamaiko, Nairobi market</li>
      <li><i class="fa-solid fa-check"></i> High-care transport for indigenous and dairy/meat goat breeds</li>
      <li><i class="fa-solid fa-check"></i> Same-day distribution to butcheries, hotels, institutions, and cold storage</li>
    </ul>
    <a class="btn" href="<?=u('contact')?>"><i class="fa-solid fa-phone"></i> Contact Kiamaiko Hub</a>
  </div>
  <img class="rv" loading="lazy" alt="Healthy herd of goats in pasture" src="<?=IMG['goats']?>">
</div>

<div class="split" style="margin-top:3.5rem">
  <img class="rv" loading="lazy" alt="Cattle herd in open pasture" src="<?=IMG['herd']?>">
  <div class="rv">
    <h2>Why Local Expertise in Kiamaiko & Beyond Matters</h2>
    <p>Livestock logistics requires ground-level mastery. Our roots in Kiamaiko, Nairobi give us direct access to livestock traders, local market associations, and veterinary authorities.</p>
    <ul class="ticks">
      <li><i class="fa-solid fa-check"></i> On-the-ground agents at border posts, pastoral markets, and auction rings</li>
      <li><i class="fa-solid fa-check"></i> Strict adherence to animal welfare standards and sanitary protocols</li>
      <li><i class="fa-solid fa-check"></i> Transparent tracking from source to Kiamaiko and final buyer</li>
    </ul>
    <a class="btn" href="<?=u('contact')?>"><i class="fa-solid fa-paper-plane"></i> Plan your shipment</a>
  </div>
</div>
</section>
<?php require 'includes/footer.php';
