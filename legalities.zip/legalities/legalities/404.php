<?php require __DIR__.'/includes/functions.php';
http_response_code(404);$page='';$pageTitle='Page Not Found';require 'includes/header.php';?>
<section class="wrap page narrow" style="text-align:center;padding-top:10rem">
  <div style="font-size:4rem;color:var(--red);margin-bottom:1rem"><i class="fa-solid fa-triangle-exclamation"></i></div>
  <h1>404 - Page Not Found</h1>
  <p class="lead" style="margin:auto auto 2rem">The page you are looking for does not exist or may have been moved.</p>
  <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
    <a class="btn" href="<?=u('index')?>"><i class="fa-solid fa-house"></i> Return Home</a>
    <a class="btn green" href="<?=u('services')?>"><i class="fa-solid fa-scale-balanced"></i> View Services</a>
    <a class="btn alt" style="color:var(--tx);box-shadow:inset 0 0 0 2px var(--ln)" href="<?=u('contact')?>"><i class="fa-solid fa-envelope"></i> Contact Us</a>
  </div>
</section>
<?php require 'includes/footer.php';
