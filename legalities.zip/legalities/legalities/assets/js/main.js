(function(){
var d=document,r=d.documentElement;
function theme(){var t=r.dataset.theme==='dark'?'light':'dark';r.dataset.theme=t;try{localStorage.theme=t}catch(e){}}
d.querySelectorAll('.theme-btn').forEach(function(b){b.onclick=theme});
var side=d.getElementById('side'),veil=d.getElementById('veil'),mb=d.getElementById('menuBtn');
function menu(o){d.body.classList.toggle('open',o);mb.setAttribute('aria-expanded',o);if(o)side.querySelector('a').focus()}
mb.onclick=function(){menu(true)};d.getElementById('closeBtn').onclick=function(){menu(false)};veil.onclick=function(){menu(false)};
d.addEventListener('keydown',function(e){if(e.key==='Escape')menu(false)});
side.querySelectorAll('a').forEach(function(a){a.onclick=function(){menu(false)}});
var top=d.getElementById('top');function sc(){top.classList.toggle('scrolled',scrollY>20)}sc();addEventListener('scroll',sc,{passive:true});
var q=d.getElementById('q');if(q)q.oninput=function(){var v=q.value.toLowerCase();d.querySelectorAll('#t tbody tr').forEach(function(x){x.hidden=!x.textContent.toLowerCase().includes(v)})};
var qs=d.getElementById('qs');if(qs)qs.oninput=function(){var v=qs.value.toLowerCase();d.querySelectorAll('#cards .card').forEach(function(c){c.hidden=!c.dataset.s.includes(v)})};
var lq=d.getElementById('lq'),curCat='all';
function filterLawyers(){
  var v=(lq?lq.value.toLowerCase().trim():'');
  d.querySelectorAll('.lawyer-card').forEach(function(c){
    var s=(c.dataset.s||'').toLowerCase();
    var cat=(c.dataset.cat||'').toLowerCase();
    var matchText=!v||s.indexOf(v)!==-1;
    var matchCat=(curCat==='all')||cat.indexOf(curCat)!==-1;
    c.hidden=!(matchText&&matchCat);
  });
}
if(lq)lq.oninput=filterLawyers;
d.querySelectorAll('.cat-chip').forEach(function(btn){
  btn.onclick=function(){
    d.querySelectorAll('.cat-chip').forEach(function(b){b.classList.remove('active')});
    btn.classList.add('active');
    curCat=(btn.dataset.cat||'all').toLowerCase();
    filterLawyers();
  };
});
var lb=d.getElementById('lb');if(lb)d.querySelectorAll('.gal img').forEach(function(i){i.onclick=function(){lb.querySelector('img').src=i.src;lb.querySelector('p').textContent=i.alt;lb.showModal()}});
if(lb)lb.onclick=function(e){if(e.target===lb)lb.close()};

var hm=d.getElementById('hireModal'),hmClose=d.getElementById('hmClose'),hmSec=d.getElementById('hmSectionText'),hmDirect=d.getElementById('hmDirect'),hmSubmit=d.getElementById('hmSubmit'),hmName=d.getElementById('hmName'),hmLocation=d.getElementById('hmLocation'),hmDetails=d.getElementById('hmDetails');
function openHire(section,title,fallbackUrl){
  if(!hm)return;
  var sText=section||title||'General Livestock Legalities';
  if(hmSec)hmSec.textContent=sText;
  if(hmDirect)hmDirect.href=fallbackUrl||('https://wa.me/254715097128?text='+encodeURIComponent('Hello Meat Soko Legal, I would like to hire a lawyer for '+sText+'.'));
  if(typeof hm.showModal==='function')hm.showModal();
}
d.addEventListener('click',function(e){
  var btn=e.target.closest('.open-hire-modal');
  if(btn){
    e.preventDefault();
    openHire(btn.dataset.section,btn.dataset.title,btn.dataset.url);
  }
});
if(hmClose)hmClose.onclick=function(){if(hm)hm.close()};
if(hm)hm.onclick=function(e){if(e.target===hm)hm.close()};
if(hmSubmit)hmSubmit.onclick=function(){
  var section=(hmSec?hmSec.textContent:'Livestock Legalities');
  var qEl=d.querySelector('input[name="hmQuality"]:checked');
  var quality=qEl?qEl.value:'Standard';
  var name=(hmName&&hmName.value.trim())?hmName.value.trim():'';
  var loc=(hmLocation&&hmLocation.value.trim())?hmLocation.value.trim():'';
  var details=(hmDetails&&hmDetails.value.trim())?hmDetails.value.trim():'';
  var msg='Hello Meat Soko Legal, I would like to hire a lawyer.\n'
    +'*Section:* '+section+'\n'
    +'*Quality Tier:* '+quality+'\n';
  if(name)msg+='*Name/Enterprise:* '+name+'\n';
  if(loc)msg+='*Location:* '+loc+'\n';
  if(details)msg+='*Case Summary:* '+details+'\n';
  var url='https://wa.me/254715097128?text='+encodeURIComponent(msg);
  window.open(url,'_blank','noopener,noreferrer');
  if(hm)hm.close();
};

var still=matchMedia('(prefers-reduced-motion:reduce)').matches;
function count(el){var n=+el.dataset.count,s=performance.now();if(still){el.textContent=n;return}
(function f(t){var p=Math.min((t-s)/1200,1);el.textContent=Math.round(n*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)})(s)}
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');var c=e.target.querySelector('[data-count]');if(c)count(c);io.unobserve(e.target)}})},{threshold:.15});
d.querySelectorAll('.rv').forEach(function(el,i){el.style.transitionDelay=(i%4)*80+'ms';io.observe(el)});
})();
