<?php require __DIR__.'/includes/functions.php';
$page='services';$pageTitle='Livestock Legal Services, LawSys & Regulatory Advisory';$sv=load('services');require 'includes/header.php';?>
<section class="wrap page">
  <h1>Our Livestock Legal Services &amp; LawSys</h1>
  <p class="lead">From LawSys legal operations and pastoral grazing corridors to high-throughput abattoirs and regional export terminals—our dedicated advocates defend your interests and streamline statutory compliance. Retain counsel directly via WhatsApp with zero public fee disclosure.</p>

  <div class="hotline-bar rv">
    <div>
      <b><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> Need Urgent Legal Representation or LawSys Deployment?</b>
      <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">Speak directly to an agricultural advocate regarding livestock transit impoundment, abattoir audits, or commercial contract execution.</p>
    </div>
    <div class="links">
      <a class="hl" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20need%20urgent%20legal%20counsel%20for%20my%20matter" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> WhatsApp Legal Desk</a>
      <a class="hl" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone" style="color:var(--red)"></i> <?=e(SITE_PHONE)?></a>
      <a class="hl" href="<?=u('hire-lawyer')?>"><i class="fa-solid fa-user-shield" style="color:var(--grn)"></i> Hire by Section</a>
    </div>
  </div>

  <?php foreach($sv as $s): ?>
  <article class="svc rv" id="<?=e($s['slug'])?>">
    <i class="fa-solid fa-<?=e($s['icon'])?> big"></i>
    <div>
      <?php if(!empty($s['badge'])): ?><b class="kind" style="margin-bottom:.3rem"><?=e($s['badge'])?></b><?php endif; ?>
      <h2><?=e($s['title'])?></h2>
      <p><?=e($s['detail'])?></p>
      <p><b class="kind">Target Value Chain Stakeholders:</b> <?=e($s['who'])?></p>
      <div class="quality-tiers" style="margin:.8rem 0 .4rem;border-top:1px dashed var(--ln);padding-top:.6rem">
        <span class="q-tier"><i class="fa-solid fa-check"></i> Standard</span>
        <span class="q-tier"><i class="fa-solid fa-check"></i> Specialized Advocate</span>
        <span class="q-tier"><i class="fa-solid fa-check"></i> Lead Counsel</span>
      </div>
      <div style="display:flex;gap:.8rem;flex-wrap:wrap;margin-top:1rem">
        <button type="button" class="btn green open-hire-modal" data-section="<?=e($s['title'])?>">
          <i class="fa-brands fa-whatsapp"></i> Hire Now
        </button>
        <a class="btn alt" style="color:var(--tx);box-shadow:inset 0 0 0 2px var(--ln)" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call Hotline</a>
      </div>
    </div>
  </article>
  <?php endforeach; ?>
</section>

<section class="wrap">
  <h2>How Our Engagement Process Works</h2>
  <ol class="steps">
    <li class="rv">
      <b>1. Initial Inquiry via WhatsApp or Call</b>
      <span>Click <b>Hire Lawyer for This Section Here</b> or reach our WhatsApp hotline at <b>+254 715 097 128</b>. Describe your livestock species, location, and the nature of the matter.</span>
    </li>
    <li class="rv">
      <b>2. Confidential Case Assessment &amp; Strategy</b>
      <span>Within hours, our specialized agricultural counsel reviews your documents and statutory framework, assesses risks, and confirms tailored engagement terms privately.</span>
    </li>
    <li class="rv">
      <b>3. Active Legal Execution &amp; LawSys Tracking</b>
      <span>We execute the strategy: courtroom injunctions, transit truck releases, contract execution, compliance audits, or ground mediation—monitored seamlessly via LawSys.</span>
    </li>
  </ol>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Ready to Protect Your Livestock Enterprise?</h2>
      <p>Contact Meat Soko Legal today on WhatsApp at <b>+254 715 097 128</b> or call <b><?=e(SITE_PHONE)?></b>.</p>
    </div>
    <div style="display:flex;gap:1rem;flex-wrap:wrap">
      <a class="btn dark" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20would%20like%20to%20hire%20a%20lawyer" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Hire Lawyer on WhatsApp</a>
      <a class="btn alt" href="<?=u('hire-lawyer')?>"><i class="fa-solid fa-user-shield"></i> Hire by Practice Section</a>
    </div>
  </div>
</section>
<?php require 'includes/footer.php';
