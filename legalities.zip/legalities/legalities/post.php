<?php require __DIR__.'/includes/functions.php';
$f=null;foreach(posts() as $x)if($x['id']===($_GET['id']??''))$f=$x;
$page='insights';
if(!$f){
  http_response_code(404);$pageTitle='Not found';require 'includes/header.php';
  echo '<section class="wrap page"><h1>Insight not found</h1><p class="lead">The requested legal brief could not be located.</p><a class="btn" href="'.u('insights').'"><i class="fa-solid fa-arrow-left"></i> Browse all insights</a></section>';
  require 'includes/footer.php';exit;
}
$pageTitle=$f['title'];require 'includes/header.php';?>
<article class="wrap page narrow">
  <div style="margin-bottom:1.5rem">
    <a href="<?=u('insights')?>" style="font-weight:600;display:inline-flex;align-items:center;gap:.4rem"><i class="fa-solid fa-arrow-left"></i> Back to Insights</a>
  </div>
  <img class="banner" src="<?=!empty($f['image'])?e($f['image']):IMG['insights']?>" alt="<?=e($f['title'])?>">
  <b class="kind"><?=e($f['category'])?></b>
  <h1><?=e($f['title'])?></h1>
  <time style="display:block;margin-bottom:1rem"><i class="fa-regular fa-calendar"></i> <?=e($f['date'])?> &bull; Published by Meat Soko Legal Advisory</time>
  <p class="lead"><?=e($f['summary'])?></p>
  <hr style="border:0;border-top:1px solid var(--ln);margin:1.8rem 0">
  <?php foreach(preg_split('/\n\s*\n/',$f['body']) as $p)echo '<p>'.nl2br(e($p)).'</p>';?>
  
  <div class="pill" style="margin-top:2.5rem;background:var(--grn-light);border-top:4px solid var(--red)">
    <h3><i class="fa-solid fa-gavel" style="color:var(--red)"></i> Need Legal Advice on This Topic?</h3>
    <p style="margin:.4rem 0 1rem;color:var(--tx)">Our legal counsel represents cattle &amp; goat enterprises, feedlots, and processing facilities. Contact us directly at <b><?=e(SITE_PHONE)?></b> or <b><?=e(SITE_EMAIL)?></b>.</p>
    <a class="btn" href="<?=u('contact')?>"><i class="fa-solid fa-paper-plane"></i> Book a Consultation</a>
  </div>

  <p style="margin-top:1.5rem"><small style="color:var(--mu)">Disclaimer: This article provides general informational commentary and does not constitute formal legal counsel. For specific litigation, compliance, or regulatory matters, consult a licensed legal advocate.</small></p>
</article>
<?php require 'includes/footer.php';
