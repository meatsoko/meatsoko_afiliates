<?php require __DIR__.'/includes/functions.php';
$sv=load('services');
if($_SERVER['REQUEST_METHOD']==='POST'){
 $n=trim($_POST['name']??'');$m=trim($_POST['email']??'');$b=trim($_POST['msg']??'');$ph=trim($_POST['phone']??'');$sr=trim($_POST['service']??'');
 if(ok()&&($_POST['website']??'')===''&&$n&&filter_var($m,FILTER_VALIDATE_EMAIL)&&$b){
  $a=load('messages');$a[]=['date'=>date('Y-m-d H:i'),'name'=>$n,'email'=>$m,'phone'=>$ph,'service'=>$sr,'msg'=>$b];save('messages',$a);
  @mail(SITE_EMAIL,"New Livestock Legal Enquiry from $n ($sr)","From: $n\nEmail: $m\nPhone: $ph\nService: $sr\n\n$b","Reply-To: $m");
  $_SESSION['flash']='Thank you. We have received your inquiry and our livestock legal team will reply within 24–48 hours.';
 }else $_SESSION['flash']='Please enter your name, a valid email address, and a message description.';
 go('contact');}
$sel=$_GET['service']??'';$page='contact';$pageTitle='Contact Legal Counsel';require 'includes/header.php';?>
<section class="wrap page narrow"><h1>Contact Meat Soko Legal</h1>
<p class="lead">Need legal representation, abattoir compliance support, livestock contract review, or rangeland dispute mediation? Get in touch with our specialist counsel today.</p>
<?=flash()?>

<div class="contact-grid">
  <div class="contact-card">
    <i class="fa-solid fa-phone"></i>
    <h3>Phone Hotline</h3>
    <p>Direct calls &amp; urgent transit assistance:</p>
    <a href="tel:<?=e(SITE_PHONE)?>"><?=e(SITE_PHONE)?></a>
  </div>
  <div class="contact-card">
    <i class="fa-brands fa-whatsapp"></i>
    <h3>WhatsApp Chat</h3>
    <p>Fast messaging &amp; document sharing:</p>
    <a href="https://wa.me/254715097128" target="_blank" rel="noopener">+254 715 097 128</a>
  </div>
  <div class="contact-card">
    <i class="fa-solid fa-envelope"></i>
    <h3>Email Inquiries</h3>
    <p>Official legal briefs &amp; contract reviews:</p>
    <a href="mailto:<?=e(SITE_EMAIL)?>"><?=e(SITE_EMAIL)?></a>
  </div>
  <div class="contact-card">
    <i class="fa-solid fa-clock"></i>
    <h3>Office &amp; Field Hours</h3>
    <p>Mon &ndash; Sat: 8:00 AM &ndash; 6:00 PM EAT</p>
    <small style="color:var(--mu)">24/7 on-call for transit impoundments</small>
  </div>
</div>

<div class="hotline-bar rv" style="margin-bottom:2rem">
  <div>
    <b><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> Fastest Option: Hire an Advocate Directly via WhatsApp</b>
    <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">All lawyers are retained confidentially via our official WhatsApp desk. Connect immediately with counsel for your section.</p>
  </div>
  <div class="links">
    <a class="hl" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20would%20like%20to%20hire%20a%20lawyer%20for%20my%20matter" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> Hire via WhatsApp</a>
    <a class="hl" href="<?=u('hire-lawyer')?>"><i class="fa-solid fa-user-shield" style="color:var(--red)"></i> View Sections</a>
  </div>
</div>

<div class="pill" style="margin-bottom:2rem">
  <h2 style="font-size:1.5rem;margin-bottom:.8rem"><i class="fa-solid fa-paper-plane" style="color:var(--red)"></i> Or send an online enquiry</h2>
  <form method="post"><?=csrf()?>
    <label>Full Name<input name="name" placeholder="e.g. John Kiptoo" required></label>
    <label>Email Address<input type="email" name="email" placeholder="e.g. contact@yourbusiness.com" required></label>
    <label>Phone Number (e.g. 0715097128)<input name="phone" placeholder="07XXXXXXXX" required></label>
    <label>Service / Matter Category
      <select name="service">
        <option value="">Please select a service...</option>
        <?php foreach($sv as $s)echo '<option value="'.e($s['slug']).'"'.($sel===$s['slug']?' selected':'').'>'.e($s['title']).'</option>';?>
        <option value="resource"<?=$sel==='resource'?' selected':''?>>Request a legal resource or contract template</option>
        <option value="urgent-transit"<?=$sel==='urgent-transit'?' selected':''?>>Urgent: Livestock transit permit / impoundment defense</option>
      </select>
    </label>
    <label>Describe Your Issue or Legal Inquiry<textarea name="msg" rows="6" placeholder="Provide details on your livestock species (cattle, goats, sheep), location, county, or contract requirements..." required></textarea></label>
    <input name="website" value="" style="display:none" tabindex="-1" autocomplete="off">
    <button class="btn"><i class="fa-solid fa-paper-plane"></i> Submit legal enquiry</button>
  </form>
</div>

<p><small style="color:var(--mu)">Disclaimer: Information provided on this website constitutes general informational guidance and does not automatically form an attorney-client relationship until formal engagement terms are executed.</small></p>
</section>
<?php require 'includes/footer.php';
