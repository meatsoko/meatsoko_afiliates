<?php require __DIR__.'/includes/functions.php';
$page='gallery';$pageTitle='Livestock & Trade Gallery';$g=load('gallery');require 'includes/header.php';?>
<section class="wrap page"><h1>Livestock &amp; Legal Operations Gallery</h1>
<p class="lead">Documenting our active legal and advisory footprint across cattle rangelands, goat breeding cooperatives, community dispute mediation forums, and high-level meat industry trade conferences.</p>
<div class="gal"><?php foreach($g as $x): ?>
<figure class="rv">
  <?php if(!empty($x['category'])): ?><span class="gcat"><i class="fa-solid fa-tag"></i> <?=e($x['category'])?></span><?php endif; ?>
  <img loading="lazy" src="<?=e($x['src'])?>" alt="<?=e($x['caption'])?>">
  <figcaption><?=e($x['caption'])?></figcaption>
</figure>
<?php endforeach; if(!$g)echo '<p>No photos available.</p>';?></div></section>
<dialog id="lb"><img alt=""><p></p><button class="btn" onclick="lb.close()"><i class="fa-solid fa-xmark"></i> Close</button></dialog>
<?php require 'includes/footer.php';
