</main>
<footer class="foot"><div class="fwrap"><div><b><?=e(SITE_SHORT)?></b><p><?=e(SITE_TAG)?>. Specialized legal counsel, regulatory defense, and sustainability advisory for cattle, goat and commercial livestock enterprises across Kenya and East Africa.</p><small>General legal information only; does not establish an attorney-client relationship until formally retained.</small></div>
<nav aria-label="Footer"><b>Navigation</b><?php foreach($NAV as $f=>$n)echo '<a href="'.u($f).'">'.$n[0].'</a>';?></nav>
<div class="fr"><b>Contact & Hotline</b><a href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> <?=e(SITE_PHONE)?></a><a href="https://wa.me/254715097128" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp: <?=e(SITE_PHONE)?></a><a href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope"></i> <?=e(SITE_EMAIL)?></a><p style="margin:.6rem 0;color:#a7f3d0;font-size:.9rem;"><i class="fa-solid fa-location-dot"></i> Nairobi, Kenya &bull; East Africa Livestock Corridors</p><small>&copy; <?=date('Y')?> <?=e(SITE_SHORT)?>. All rights reserved.</small></div></div></footer>
<nav class="bnav" aria-label="Mobile"><?php foreach($BOT as $f=>$n)echo '<a href="'.u($f).'"'.($page===$f?' aria-current="page"':'').'><span><i class="fa-solid fa-'.$n[1].'"></i></span>'.$n[0].'</a>';?></nav>
<dialog id="hireModal" class="hire-dialog" aria-labelledby="hmTitle">
  <div class="hm-wrap">
    <div class="hm-head">
      <div>
        <span class="kind"><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> Meat Soko Legal Desk</span>
        <h3 id="hmTitle" style="margin:.3rem 0 0;font-size:1.3rem">Hire Legal Counsel</h3>
      </div>
      <button type="button" class="ic" id="hmClose" aria-label="Close dialog"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <form id="hmForm" onsubmit="return false;" style="margin-top:1rem;display:flex;flex-direction:column;gap:.9rem;">
      <div style="background:var(--sf);border:1px solid var(--ln);border-radius:12px;padding:.75rem 1rem;">
        <small style="color:var(--mu);display:block;font-size:.78rem;text-transform:uppercase;letter-spacing:.05em">Selected Practice Section</small>
        <b id="hmSectionText" style="font-size:1rem;color:var(--tx)">General Livestock Legalities</b>
      </div>
      <div>
        <label style="font-size:.85rem;font-weight:700;margin-bottom:.35rem;display:block">Select Quality Tier</label>
        <div class="hm-quality-options">
          <label class="q-opt">
            <input type="radio" name="hmQuality" value="Standard" checked>
            <span><b>Standard</b><small>Routine filings &amp; advice</small></span>
          </label>
          <label class="q-opt">
            <input type="radio" name="hmQuality" value="Specialized Advocate">
            <span><b>Specialized Advocate</b><small>Court litigation &amp; transit bail</small></span>
          </label>
          <label class="q-opt">
            <input type="radio" name="hmQuality" value="Lead Counsel">
            <span><b>Lead Counsel</b><small>Senior partner &amp; complex deals</small></span>
          </label>
        </div>
      </div>
      <div>
        <label for="hmName" style="font-size:.85rem;font-weight:700;margin-bottom:.35rem;display:block">Your Name / Farm Name</label>
        <input id="hmName" type="text" placeholder="e.g. Hassan / Samburu Livestock Co." style="width:100%">
      </div>
      <div>
        <label for="hmLocation" style="font-size:.85rem;font-weight:700;margin-bottom:.35rem;display:block">County / Location</label>
        <input id="hmLocation" type="text" placeholder="e.g. Kajiado / Nakuru / Nairobi" style="width:100%">
      </div>
      <div>
        <label for="hmDetails" style="font-size:.85rem;font-weight:700;margin-bottom:.35rem;display:block">Brief Matter Summary (Optional)</label>
        <textarea id="hmDetails" rows="2" placeholder="e.g. Truck stopped at cess point, off-take agreement review, grazing land dispute..." style="width:100%"></textarea>
      </div>
      <div style="margin-top:.4rem;display:flex;flex-direction:column;gap:.6rem">
        <button type="button" id="hmSubmit" class="btn green" style="width:100%;justify-content:center;font-size:1rem;padding:.75rem">
          <i class="fa-brands fa-whatsapp"></i> Hire Now on WhatsApp
        </button>
        <a id="hmDirect" href="https://wa.me/254715097128" target="_blank" rel="noopener" style="text-align:center;font-size:.84rem;color:var(--mu);text-decoration:underline">
          Or skip details and chat directly on WhatsApp &rarr;
        </a>
      </div>
    </form>
  </div>
</dialog>
</body></html>
