<?php
require_once __DIR__.'/../config.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
const IMG=[
 'hero'=>'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=1800&q=70',
 'about'=>'assets/img/cattle-grazing.jpg',
 'insights'=>'https://images.unsplash.com/photo-1560493676-04071c5f467b?auto=format&fit=crop&w=900&q=70'];
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function load($n){$f=__DIR__."/../data/$n.json";return is_file($f)?(json_decode(file_get_contents($f),true)?:[]):[];}
function save($n,$d){file_put_contents(__DIR__."/../data/$n.json",json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);}
function u($f){if($f==='index')return CLEAN_URLS?'./':'index.php';return CLEAN_URLS?$f:$f.'.php';}
function csrf(){if(empty($_SESSION['t']))$_SESSION['t']=bin2hex(random_bytes(16));return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">';}
function ok(){return isset($_POST['t'],$_SESSION['t'])&&hash_equals($_SESSION['t'],$_POST['t']);}
function go($f){header('Location: '.u($f));exit;}
function flash(){$m=$_SESSION['flash']??'';unset($_SESSION['flash']);return $m?'<p class="flash" role="status">'.e($m).'</p>':'';}
function posts(){$p=load('insights');usort($p,fn($a,$b)=>strcmp($b['date'],$a['date']));return $p;}
function card($x){return '<a class="card rv" data-s="'.e(strtolower($x['title'].' '.$x['summary'])).'" href="'.u('post').'?id='.e($x['id']).'"><img loading="lazy" alt="" src="'.(!empty($x['image'])?e($x['image']):IMG['insights']).'"><div><b>'.e($x['category']).'</b><h3>'.e($x['title']).'</h3><p>'.e($x['summary']).'</p><time><i class="fa-regular fa-calendar"></i> '.e($x['date']).'</time></div></a>';}
function lawyer_card($l){
  $title = !empty($l['name']) ? $l['name'] : 'Legal Counsel';
  $sec = !empty($l['section']) ? $l['section'] : $title;
  $summary = !empty($l['summary']) ? $l['summary'] : '';
  $img = !empty($l['image']) ? e($l['image']) : IMG['insights'];
  $searchTxt = strtolower($title.' '.$sec.' '.($l['category']??'').' '.$summary);

  $qualitiesHtml = '<div class="quality-tiers">'
    .'<span class="q-tier"><i class="fa-solid fa-check"></i> Standard</span>'
    .'<span class="q-tier"><i class="fa-solid fa-check"></i> Specialized Advocate</span>'
    .'<span class="q-tier"><i class="fa-solid fa-check"></i> Lead Counsel</span>'
    .'</div>';

  $waMsg = 'Hello Meat Soko Legal, I would like to hire a lawyer for '.$title.' ('.$sec.').';
  $waUrl = 'https://wa.me/254715097128?text='.rawurlencode($waMsg);

  return '<div class="lawyer-card card rv" data-s="'.e($searchTxt).'" data-cat="'.e(strtolower($l['category']??'all')).'">'
    .'<div class="lawyer-img-wrap"><img loading="lazy" alt="'.e($title).'" src="'.$img.'"></div>'
    .'<div class="lawyer-body">'
    .'<b class="kind">'.e($sec).'</b>'
    .'<h3 class="lawyer-title">'.e($title).'</h3>'
    .'<p class="lawyer-desc">'.e($summary).'</p>'
    .$qualitiesHtml
    .'<div class="lawyer-foot">'
    .'<button type="button" class="btn green lawyer-btn open-hire-modal" data-section="'.e($sec).'" data-title="'.e($title).'" data-url="'.$waUrl.'"><i class="fa-brands fa-whatsapp"></i> Hire Now</button>'
    .'</div>'
    .'</div></div>';
}

