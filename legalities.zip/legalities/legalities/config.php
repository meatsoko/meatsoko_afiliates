<?php
// === Meat Soko Group - Livestock Legalities & Regulatory Arm ===
const SITE_SHORT      = 'Meat Soko Group';
const SITE_TAG        = 'Livestock Legalities, Regulatory & Trade Advisory';
const SITE_EMAIL      = 'info@meatsokogroup.com';   // contact messages are emailed here
const SITE_PHONE      = '0715097128';
const SITE_PHONE_INTL = '+254715097128';
const CLEAN_URLS      = true;                       // set false if your host has no mod_rewrite
