<?php require __DIR__.'/includes/functions.php';
$page='resources';$pageTitle='Legal Resources & Contract Templates';$rs=load('resources');require 'includes/header.php';?>
<section class="wrap page">
  <h1>Livestock Legal Resources &amp; Templates</h1>
  <p class="lead">Practical, plain-language legal contract templates, statutory compliance checklists, and dispute mediation guides designed specifically for cattle and goat producers, traders, and meat processing businesses.</p>

  <div class="hotline-bar rv">
    <div>
      <b><i class="fa-solid fa-file-contract" style="color:var(--red)"></i> Need a Custom Drafted Livestock Agreement?</b>
      <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">Our legal counsel drafts bespoke livestock purchase agreements, feedlot off-take pacts, and rangeland covenants.</p>
    </div>
    <div class="links">
      <a class="hl" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone" style="color:var(--red)"></i> <?=e(SITE_PHONE)?></a>
      <a class="hl" href="<?=u('contact')?>?service=resource"><i class="fa-solid fa-envelope" style="color:var(--grn)"></i> Request Custom Drafting</a>
    </div>
  </div>

  <input id="qs" type="search" placeholder="Search templates, guides & checklists..." aria-label="Search resources">
  <div class="grid" id="cards">
    <?php foreach($rs as $r):
      $l=!empty($r['file'])?e($r['file']):u('contact').'?service=resource';
    ?>
    <div class="card rv" data-s="<?=e(strtolower($r['title'].' '.$r['desc']))?>">
      <div>
        <b class="kind"><?=e($r['category'])?></b>
        <h3><?=e($r['title'])?></h3>
        <p><?=e($r['desc'])?></p>
        <a class="btn" href="<?=$l?>"><i class="fa-solid fa-<?=!empty($r['file'])?'download':'paper-plane'?>"></i> <?=!empty($r['file'])?'Download Document':'Request Template'?></a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>
<?php require 'includes/footer.php';
