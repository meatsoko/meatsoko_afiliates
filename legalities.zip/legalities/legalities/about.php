<?php require __DIR__.'/includes/functions.php';
$page='about';$pageTitle='About Meat Soko Legal';$team=load('team');require 'includes/header.php';?>
<section class="wrap page">
  <h1>About <?=e(SITE_SHORT)?> Legalities</h1>
  <p class="lead"><?=e(SITE_SHORT)?> is the dedicated livestock legal representation, trade compliance, and dispute mediation arm of the Meat Soko ecosystem. We empower livestock keepers, commercial ranchers, feedlot aggregators, abattoir operators, and meat processors with robust legal security and policy advocacy.</p>

  <div class="hotline-bar rv">
    <div>
      <b><i class="fa-solid fa-shield-halved"></i> Dedicated Livestock Legal Hotline</b>
      <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">Immediate assistance for animal movement permits, abattoir inspections &amp; contract disputes</p>
    </div>
    <div class="links">
      <a class="hl" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone" style="color:var(--red)"></i> <?=e(SITE_PHONE)?></a>
      <a class="hl" href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope" style="color:var(--grn)"></i> <?=e(SITE_EMAIL)?></a>
    </div>
  </div>

  <section class="split" style="margin:3rem 0">
    <div class="rv">
      <h2>Securing the Livestock Economy from Pasture to Plate</h2>
      <p>The livestock sector forms the economic backbone of rural arid and semi-arid lands, contributing significantly to regional agricultural GDP. Yet herders, feedlot managers, and abattoirs frequently confront regulatory hurdles—ranging from arbitrary transit restrictions under the Animal Diseases Act to contested grazing boundaries and unpaid commercial off-take balances.</p>
      <p>We combine deep statutory knowledge of agricultural jurisprudence with on-the-ground pastoral experience to deliver swift, practical legal solutions.</p>
      <ul class="ticks">
        <li><i class="fa-solid fa-circle-check"></i> <b>Cattle &amp; Cow Value Chains:</b> Protection for beef cattle ranches, dairy herds, feedlot partnerships, and cross-border cattle trade.</li>
        <li><i class="fa-solid fa-circle-check"></i> <b>Goat Breeding &amp; Chevon Markets:</b> Contract structures for Boer goats, dairy goat cooperatives, and municipal livestock aggregation yards.</li>
        <li><i class="fa-solid fa-circle-check"></i> <b>Statutory Abattoir Compliance:</b> Full defense under the Meat Control Act, NEMA effluent guidelines, and public health directives.</li>
      </ul>
    </div>
    <img class="rv" loading="lazy" alt="Pastoral cattle grazing in open grassland" src="<?=IMG['about']?>">
  </section>

  <h2 style="margin-top:4rem" class="rv">Our Core Operating Values</h2>
  <div class="grid three">
    <div class="pill rv">
      <h3><i class="fa-solid fa-bullseye"></i> Our Mission</h3>
      <p>To provide cattle and goat keepers, cooperatives, and meat enterprises with accessible, high-caliber legal protection, statutory compliance, and dignified dispute resolution.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-eye"></i> Our Vision</h3>
      <p>An equitable, conflict-free livestock sector across East Africa that honors pastoral livelihoods, guarantees meat food safety, and preserves rangeland ecology.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-handshake"></i> Uncompromising Integrity</h3>
      <p>Transparent fee structures, rigorous conflict-of-interest screening, and absolute dedication to the legal rights and financial security of our clients.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-people-group"></i> Pastoral Community Focus</h3>
      <p>We work in close partnership with community elders, group ranch leadership, county trade departments, and regional livestock market associations.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-leaf"></i> Sustainability &amp; ESG</h3>
      <p>Promoting regenerative grazing corridors, animal welfare compliance, Halal certification, and fair carbon benefit-sharing for pastoralists.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-gavel"></i> Mediation Before Conflict</h3>
      <p>Resolving pasture boundaries, livestock damage claims, and commercial payment defaults through binding ADR agreements before protracted litigation.</p>
    </div>
  </div>

  <h2 style="margin-top:4.5rem" class="rv">Legal Counsel &amp; Advocates by Section</h2>
  <p class="lead rv">Dedicated High Court advocates, veterinary regulatory directors, and accredited mediators specializing in livestock legalities. Select and retain the counsel for your specific section directly via WhatsApp.</p>
  <div class="grid three" style="margin-top:1.5rem">
    <?php foreach($team as $t): ?>
    <div class="team-card rv">
      <?php if(!empty($t['image'])): ?><img loading="lazy" src="<?=e($t['image'])?>" alt="<?=e($t['role'])?>"><?php endif; ?>
      <div class="team-body">
        <b class="kind" style="margin-bottom:.3rem"><?=e($t['section'] ?? 'Livestock Practice Area')?></b>
        <h3><?=e($t['role'] ?? $t['section'])?></h3>
        <p><?=e($t['summary'] ?? '')?></p>
        <div class="quality-tiers" style="margin:.6rem 0 .4rem;border-top:1px dashed var(--ln);padding-top:.5rem">
          <span class="q-tier"><i class="fa-solid fa-check"></i> Standard</span>
          <span class="q-tier"><i class="fa-solid fa-check"></i> Specialized Advocate</span>
          <span class="q-tier"><i class="fa-solid fa-check"></i> Lead Counsel</span>
        </div>
        <div style="margin-top:auto;padding-top:.8rem;border-top:1px solid var(--ln)">
          <button type="button" class="btn green open-hire-modal" style="width:100%;justify-content:center;font-size:.88rem;padding:.5rem 1rem" data-section="<?=e($t['section'])?>">
            <i class="fa-brands fa-whatsapp"></i> Hire Now
          </button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Speak with Our Livestock Legal Counsel</h2>
      <p>Call our direct line <b><?=e(SITE_PHONE)?></b> or send your documentation for immediate assessment.</p>
    </div>
    <a class="btn dark" href="<?=u('contact')?>"><i class="fa-solid fa-paper-plane"></i> Request Legal Consultation</a>
  </div>
</section>
<?php require 'includes/footer.php';
