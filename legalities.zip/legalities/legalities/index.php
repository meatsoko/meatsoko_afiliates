<?php require __DIR__.'/includes/functions.php';
$page='index';$pageTitle='Livestock Legal Representation, LawSys & Trade Compliance';
$ps=posts();$sv=load('services');$rs=load('resources');$lawyers=load('lawyers');
require 'includes/header.php';?>
<section class="hero" style="--img:url('<?=IMG['hero']?>')">
  <div class="hwrap">
    <p class="chip"><i class="fa-solid fa-cow"></i> Meat Soko Group &bull; Livestock Legalities &amp; Trade Advisory</p>
    <h1>Justice, Policy &amp; Legal Protection for Livestock</h1>
    <p class="lead">Protecting cattle and goat ranchers, pastoralist communities, feedlot operators, and abattoirs with specialized legal defense, LawSys digital compliance operations, and rapid dispute mediation.</p>
    <div style="display:flex;gap:1rem;flex-wrap:wrap;align-items:center">
      <button type="button" class="btn green open-hire-modal" data-section="General Livestock Legalities"><i class="fa-brands fa-whatsapp"></i> Hire Now</button>
      <a class="btn" href="<?=u('hire-lawyer')?>"><i class="fa-solid fa-user-shield"></i> Hire by Practice Section</a>
      <a class="btn alt" href="<?=u('services')?>"><i class="fa-solid fa-scale-balanced"></i> LawSys &amp; Services</a>
    </div>
  </div>
  <div class="ticker">
    <div class="track">
      <?php for($k=0;$k<2;$k++)foreach($sv as $s)echo '<span><i><i class="fa-solid fa-'.e($s['icon']).'"></i> '.e($s['title']).'</i> <em>&bull;</em></span>';?>
    </div>
  </div>
</section>

<section class="wrap">
  <div class="hotline-bar rv">
    <div>
      <b><i class="fa-solid fa-shield-halved"></i> 24/7 Livestock Transit &amp; Regulatory Emergency Hotline</b>
      <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">Immediate legal intervention for livestock truck impoundments, animal movement permits &amp; county cess disputes</p>
    </div>
    <div class="links">
      <a class="hl" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20need%20urgent%20transit%20legal%20assistance" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> WhatsApp Desk</a>
      <a class="hl" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone" style="color:var(--red)"></i> <?=e(SITE_PHONE)?></a>
      <a class="hl" href="mailto:<?=e(SITE_EMAIL)?>"><i class="fa-solid fa-envelope" style="color:var(--red)"></i> <?=e(SITE_EMAIL)?></a>
    </div>
  </div>

  <div class="stats">
    <div class="rv"><i class="fa-solid fa-scale-balanced"></i><b data-count="<?=count($sv)?>">0</b><span>legal services &amp; LawSys</span></div>
    <div class="rv"><i class="fa-solid fa-user-shield"></i><b data-count="<?=count($lawyers)?>">0</b><span>practice sections</span></div>
    <div class="rv"><i class="fa-solid fa-newspaper"></i><b data-count="<?=count($ps)?>">0</b><span>published briefs</span></div>
    <div class="rv"><i class="fa-solid fa-folder-open"></i><b data-count="<?=count($rs)?>">0</b><span>contract resources</span></div>
  </div>
</section>

<section class="wrap split">
  <img class="rv" loading="lazy" alt="Cattle and cows grazing on rangeland pasture" src="<?=IMG['about']?>">
  <div class="rv">
    <span class="kind">Pasture to Processing</span>
    <h2>Law and Policy That Protect Livestock Livelihoods</h2>
    <p>Livestock keepers face intense challenges: contested migratory corridors, bureaucratic transit permits, unfulfilled supply payments, and regulatory inspections under the Meat Control Act. We turn intricate statutes into clear, enforceable contracts and protect you against unfair penalties.</p>
    <ul class="ticks">
      <li><i class="fa-solid fa-circle-check"></i> <div><b>Specialized in Cattle, Cows &amp; Goats:</b> Tailored legal instruments for pastoral herds, dairy cattle, meat goats, and feedlot investments.</div></li>
      <li><i class="fa-solid fa-circle-check"></i> <div><b>Powered by LawSys Operations:</b> Modern legal tech tracking statutory deadlines, stock movement clearances, and contract execution.</div></li>
      <li><i class="fa-solid fa-circle-check"></i> <div><b>Alternative Dispute Resolution (ADR):</b> Ground-level mediation for community rangeland and grazing rights disputes before expensive litigation.</div></li>
      <li><i class="fa-solid fa-circle-check"></i> <div><b>Meat Regulatory &amp; Abattoir Defense:</b> Full statutory audit and compliance defense under the Meat Control Act and public health bylaws.</div></li>
    </ul>
    <div style="margin-top:1.5rem">
      <a class="btn" href="<?=u('about')?>"><i class="fa-solid fa-circle-info"></i> Learn About Meat Soko Legal</a>
    </div>
  </div>
</section>

<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
    <div>
      <span class="kind">Verified Advocates &amp; Counsel</span>
      <h2 class="rv" style="margin:0">Hire a Lawyer for Your Practice Section</h2>
    </div>
    <a class="btn green" href="<?=u('hire-lawyer')?>"><i class="fa-solid fa-user-shield"></i> View All Sections (<?=count($lawyers)?>)</a>
  </div>
  <p class="rv" style="color:var(--mu);margin-top:-.5rem;margin-bottom:1.5rem">Select your practice area and retain an experienced High Court advocate or agricultural counsel directly via WhatsApp with confidential terms.</p>
  <div class="grid three">
    <?php foreach(array_slice($lawyers,0,3) as $l) echo lawyer_card($l); ?>
  </div>
</section>

<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
    <div>
      <span class="kind">Our Practice Areas &amp; Systems</span>
      <h2 class="rv" style="margin:0">Livestock Legal Services &amp; LawSys</h2>
    </div>
    <a class="btn" href="<?=u('services')?>"><i class="fa-solid fa-arrow-right"></i> View All <?=count($sv)?> Services</a>
  </div>
  <div class="grid three">
    <?php foreach(array_slice($sv,0,6) as $s): ?>
    <a class="pill rv" href="<?=u('services')?>#<?=e($s['slug'])?>">
      <h3><i class="fa-solid fa-<?=e($s['icon'])?>"></i> <?=e($s['title'])?></h3>
      <p><?=e($s['summary'])?></p>
      <span style="display:inline-block;margin-top:.8rem;color:var(--red);font-weight:700;font-size:.88rem">Read more &rarr;</span>
    </a>
    <?php endforeach; ?>
  </div>
</section>

<section class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
    <div>
      <span class="kind">Legal Intelligence</span>
      <h2 class="rv" style="margin:0">Latest Policy Briefs &amp; Legal Updates</h2>
    </div>
    <a class="btn" href="<?=u('insights')?>"><i class="fa-solid fa-newspaper"></i> Browse All Insights</a>
  </div>
  <div class="grid">
    <?php foreach(array_slice($ps,0,4) as $x)echo card($x);?>
  </div>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Need Immediate Legal or Policy Support?</h2>
      <p>Reach out to Meat Soko Group Legalities at <b><?=e(SITE_PHONE)?></b> or WhatsApp at <b>+254 715 097 128</b>. Our team responds within 24 hours.</p>
    </div>
    <div style="display:flex;gap:1rem;flex-wrap:wrap">
      <a class="btn dark" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20would%20like%20to%20hire%20a%20lawyer" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp Legal Desk</a>
      <a class="btn alt" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call <?=e(SITE_PHONE)?></a>
    </div>
  </div>
</section>
<?php require 'includes/footer.php';
