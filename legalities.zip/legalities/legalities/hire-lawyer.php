<?php require __DIR__.'/includes/functions.php';
$page='hire-lawyer';$pageTitle='Hire a Livestock Lawyer & Legal Counsel';
$lawyers=load('lawyers');
$categories=['All'];
foreach($lawyers as $l){
  if(!empty($l['category']) && !in_array($l['category'], $categories)){
    $categories[]=$l['category'];
  }
}
require 'includes/header.php';?>
<section class="wrap page">
  <div style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:1rem;margin-bottom:1rem">
    <div>
      <span class="kind">Specialized Advocates &amp; Legal Counsel</span>
      <h1 style="margin:0">Hire a Lawyer for Your Livestock Matter</h1>
    </div>
    <div style="color:var(--mu);font-size:.95rem">
      <i class="fa-solid fa-user-shield" style="color:var(--grn)"></i> <b><?=count($lawyers)?></b> legal sections available
    </div>
  </div>
  <p class="lead">Retain specialized Advocates of the High Court of Kenya and agricultural legal consultants. Defend your cattle, goats, ranches, abattoirs, and transit consignments. All legal counsel is retained confidentially and directly through our official WhatsApp desk with zero public fee disclosure.</p>

  <div class="hotline-bar rv">
    <div>
      <b><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> Instant Lawyer Retainer &amp; Emergency Dispatch</b>
      <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">Need rapid legal intervention for truck impoundments, livestock seizure, or court representation? Connect directly with our on-call counsel.</p>
    </div>
    <div class="links">
      <a class="hl" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20need%20to%20hire%20a%20lawyer%20for%20an%20urgent%20livestock%20matter" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp" style="color:var(--grn)"></i> WhatsApp Legal Desk</a>
      <a class="hl" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone" style="color:var(--red)"></i> Hotline: <?=e(SITE_PHONE)?></a>
    </div>
  </div>

  <div style="margin:1.8rem 0 1rem">
    <input id="lq" type="search" placeholder="Search lawyer by section, practice area, or case type (e.g. transit, litigation, LawSys, land rights, abattoir, contracts)..." aria-label="Search lawyers">
  </div>

  <div class="prod-filter-bar">
    <?php foreach($categories as $cat): ?>
      <button type="button" class="cat-chip <?=($cat==='All'?'active':'')?>" data-cat="<?=e(strtolower($cat))?>">
        <?=e($cat)?>
      </button>
    <?php endforeach; ?>
  </div>

  <div class="grid three" id="lawyerCards" style="margin-top:1.5rem">
    <?php foreach($lawyers as $l) echo lawyer_card($l); ?>
  </div>
</section>

<section class="wrap">
  <h2 class="rv">Why Retain a Meat Soko Livestock Lawyer?</h2>
  <div class="grid three">
    <div class="pill rv">
      <h3><i class="fa-solid fa-gavel"></i> Sector-Specific Legal Mastery</h3>
      <p>Agricultural law is complex. Our advocates specialize exclusively in the Meat Control Act, Animal Diseases Act, Community Land Act, and cross-border livestock regulations.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-truck-fast"></i> 24/7 Rapid Transit Response</h3>
      <p>When livestock haulage trucks are stopped or impounded at county cess borders, our transit legal counsel acts immediately to secure stock releases and safeguard animal welfare.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-laptop-code"></i> Powered by LawSys Tech</h3>
      <p>All client matters benefit from our LawSys digital compliance system, ensuring automated statutory filing calendars, vetted contract drafting, and seamless case tracking.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-shield-halved"></i> 100% Confidential Retention</h3>
      <p>We do not publish fee tariffs publicly. Every retainer is assessed confidentially based on the specific requirements, scale, and location of your livestock enterprise.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-solid fa-handshake-angle"></i> Ground-Level ADR Mediation</h3>
      <p>Before lengthy litigation, our certified dispute mediators engage community elders and county administrators to resolve grazing disputes and boundary tensions peacefully.</p>
    </div>
    <div class="pill rv">
      <h3><i class="fa-brands fa-whatsapp"></i> Direct WhatsApp Access</h3>
      <p>Skip bureaucratic law firm red tape. Communicate directly with your advocate via WhatsApp for rapid brief submissions, updates, and emergency representation.</p>
    </div>
  </div>
</section>

<section class="wrap">
  <h2 class="rv">How to Hire Your Advocate via WhatsApp in 3 Easy Steps</h2>
  <ol class="steps">
    <li class="rv">
      <b>1. Click "Hire Now" on Your Section</b>
      <span>Choose your practice section above and click <b>Hire Now</b>.</span>
    </li>
    <li class="rv">
      <b>2. Select Quality &amp; Fill Quick Details</b>
      <span>Select your quality tier (Standard, Specialized Advocate, or Lead Counsel) and enter your name and county.</span>
    </li>
    <li class="rv">
      <b>3. Confirm &amp; Launch WhatsApp</b>
      <span>Click <b>Hire Now on WhatsApp</b> to dispatch your formatted brief directly to our legal desk at <b>+254 715 097 128</b>.</span>
    </li>
  </ol>
</section>

<section class="cta">
  <div class="wrap rv">
    <div>
      <h2>Need Immediate Legal Representation?</h2>
      <p>Speak directly with Meat Soko Legal Counsel on WhatsApp at <b>+254 715 097 128</b> or call <b><?=e(SITE_PHONE)?></b>.</p>
    </div>
    <div style="display:flex;gap:1rem;flex-wrap:wrap">
      <a class="btn dark" href="https://wa.me/254715097128?text=Hello%20Meat%20Soko%20Legal%2C%20I%20need%20to%20hire%20a%20lawyer%20for%20my%20matter" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Hire Lawyer on WhatsApp</a>
      <a class="btn alt" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone"></i> Call Hotline: <?=e(SITE_PHONE)?></a>
    </div>
  </div>
</section>
<?php require 'includes/footer.php';
