<?php require __DIR__.'/includes/functions.php';
$page='insights';$pageTitle='Livestock Legal Insights & Policy Briefs';require 'includes/header.php';?>
<section class="wrap page">
  <h1>Livestock Legal Insights &amp; Policy Briefs</h1>
  <p class="lead">In-depth statutory analyses, meat industry regulatory alerts, animal movement permit directives, and practical legal strategies for cattle and goat value chains across Kenya and East Africa.</p>

  <div class="hotline-bar rv">
    <div>
      <b><i class="fa-solid fa-scale-balanced" style="color:var(--red)"></i> Have a Regulatory or Policy Question?</b>
      <p style="margin:.2rem 0 0;color:var(--mu);font-size:.92rem">Consult directly with our livestock policy researchers and agricultural law advocates.</p>
    </div>
    <div class="links">
      <a class="hl" href="tel:<?=e(SITE_PHONE)?>"><i class="fa-solid fa-phone" style="color:var(--red)"></i> <?=e(SITE_PHONE)?></a>
      <a class="hl" href="<?=u('contact')?>"><i class="fa-solid fa-envelope" style="color:var(--grn)"></i> Consult Counsel</a>
    </div>
  </div>

  <input id="qs" type="search" placeholder="Search legal topics, acts & policy briefs..." aria-label="Search insights">
  <div class="grid" id="cards">
    <?php $l=posts();foreach($l as $x)echo card($x);if(!$l)echo '<p>No insights published yet.</p>';?>
  </div>
</section>
<?php require 'includes/footer.php';
