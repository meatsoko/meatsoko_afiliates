MSL AG&L - PHP website (PHP 7.4+, no database, no login)
1. Upload everything to public_html.
2. Edit config.php: SITE_EMAIL (enquiries are emailed here) and CLEAN_URLS.
3. Make data/ writable (755/775) so contact messages can be saved to data/messages.json.
4. Edit content in data/*.json: services (including LawSys), lawyers (section-based advocates hired via WhatsApp, no prices), insights, resources (add "file":"link.pdf" to make a download), team, gallery.
5. Replace the images in includes/functions.php (IMG) and data/gallery.json with your own photos.
Information on the site is general and is not legal advice.
